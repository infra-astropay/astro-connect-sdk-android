package com.astropay.connect.utils

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.provider.Settings
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.astropay.connect.core.AstroLogger
import java.nio.ByteBuffer
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.pow
import androidx.biometric.BiometricManager as AndroidBiometricManager

/**
 * Biometric authentication and secure seed storage manager for Android.
 * Implements the "Bridge-as-Vault" pattern for TOTP 2FA.
 *
 * Supports two authentication methods:
 * 1. BiometricPrompt (preferred) - requires FragmentActivity, shows native biometric dialog
 * 2. KeyguardManager (fallback) - works with any Activity, shows system lock screen
 */
internal object BiometricManager {
    private const val PREFS_NAME = "astro_connect_biometric_prefs"
    private const val SEED_KEY = "totp_seed" // Fixed key for single seed storage
    private const val MIN_SEED_LENGTH = 16 // Minimum 128 bits for TOTP security
    private const val TOTP_DIGITS = 6
    private const val TOTP_TIME_STEP = 30L // seconds
    private const val BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    /**
     * Decodes a Base32-encoded string to ByteArray.
     * @param base32 The Base32-encoded string to decode.
     * @return The decoded ByteArray.
     */
    private fun base32Decode(base32: String): ByteArray {
        val cleanInput = base32.uppercase().replace("=", "")
        val output = ByteArray(cleanInput.length * 5 / 8)
        var buffer = 0
        var bitsLeft = 0
        var outputIndex = 0

        for (char in cleanInput) {
            val value = BASE32_ALPHABET.indexOf(char)
            if (value < 0) continue
            buffer = (buffer shl 5) or value
            bitsLeft += 5
            if (bitsLeft >= 8) {
                bitsLeft -= 8
                output[outputIndex++] = (buffer shr bitsLeft).toByte()
            }
        }
        return output
    }

    /**
     * Biometric error codes matching iOS implementation.
     */
    object ErrorCode {
        const val BIOMETRIC_NOT_AVAILABLE = "BIOMETRIC_NOT_AVAILABLE"
        const val BIOMETRIC_NOT_ENROLLED = "BIOMETRIC_NOT_ENROLLED"
        const val USER_CANCELLED = "USER_CANCELLED"
        const val SECURE_HARDWARE_UNAVAILABLE = "SECURE_HARDWARE_UNAVAILABLE"
        const val KEYSTORE_ERROR = "KEYSTORE_ERROR"
        const val DEVICE_NOT_SECURE = "DEVICE_NOT_SECURE"
        const val INVALID_SEED = "INVALID_SEED"
        const val SEED_NOT_FOUND = "SEED_NOT_FOUND"
        const val TOTP_GENERATION_FAILED = "TOTP_GENERATION_FAILED"
        const val UNKNOWN = "UNKNOWN"
    }

    /**
     * Result types for device registration.
     */
    sealed class RegisterDeviceResult {
        data class Success(
            val deviceInfo: String,
            val deviceId: String,
        ) : RegisterDeviceResult()

        data class Error(
            val code: String,
        ) : RegisterDeviceResult()
    }

    /**
     * Result types for TOTP generation.
     */
    sealed class GenerateTOTPResult {
        data class Success(
            val code: String,
            val remainingSeconds: Int,
        ) : GenerateTOTPResult()

        data class Error(
            val code: String,
        ) : GenerateTOTPResult()
    }

    /**
     * Data class to hold pending registration info during KeyguardManager authentication.
     */
    data class PendingRegistration(
        val seed: String,
    )

    /**
     * Validates a Base32-encoded seed.
     * @param seed The Base32-encoded seed to validate.
     * @return null if valid, error code if invalid.
     */
    fun validateSeed(seed: String): String? =
        try {
            val seedData = base32Decode(seed)
            if (seedData.size < MIN_SEED_LENGTH) {
                AstroLogger.logDebug("Invalid seed: too short (${seedData.size} bytes, minimum $MIN_SEED_LENGTH)")
                ErrorCode.INVALID_SEED
            } else {
                null
            }
        } catch (e: Exception) {
            AstroLogger.logDebug("Invalid seed: failed to decode base32 - ${e.message}")
            ErrorCode.INVALID_SEED
        }

    /**
     * Checks if device has biometric capability (fingerprint, face, etc.).
     * @param context The Android context.
     * @return true if biometrics are available and enrolled.
     */
    fun deviceHaveBiometrics(context: Context): Boolean {
        val biometricManager = AndroidBiometricManager.from(context)
        // Check for strong biometrics (fingerprint, face unlock with hardware)
        val strongResult = biometricManager.canAuthenticate(AndroidBiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (strongResult == AndroidBiometricManager.BIOMETRIC_SUCCESS) {
            AstroLogger.logDebug("Strong biometrics available")
            return true
        }
        // Also check for weak biometrics (face unlock on some devices)
        val weakResult = biometricManager.canAuthenticate(AndroidBiometricManager.Authenticators.BIOMETRIC_WEAK)
        val available = weakResult == AndroidBiometricManager.BIOMETRIC_SUCCESS
        AstroLogger.logDebug("Biometric available: $available (strong: $strongResult, weak: $weakResult)")
        return available
    }

    /**
     * Gets detailed biometric status.
     * @param context The Android context.
     * @return Error code if biometrics not available, null otherwise.
     */
    fun getBiometricErrorCode(context: Context): String? {
        val biometricManager = AndroidBiometricManager.from(context)
        return when (biometricManager.canAuthenticate(AndroidBiometricManager.Authenticators.BIOMETRIC_STRONG)) {
            AndroidBiometricManager.BIOMETRIC_SUCCESS -> null
            AndroidBiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> ErrorCode.BIOMETRIC_NOT_AVAILABLE
            AndroidBiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> ErrorCode.SECURE_HARDWARE_UNAVAILABLE
            AndroidBiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> ErrorCode.BIOMETRIC_NOT_ENROLLED
            else -> ErrorCode.UNKNOWN
        }
    }

    /**
     * Registers the device as a "Trusted Device" for biometric 2FA.
     * Stores the provided TOTP seed securely using EncryptedSharedPreferences.
     *
     * Note: This method does NOT require biometric authentication to store the seed.
     * Biometric authentication is only required when generating TOTP codes (generateTOTP).
     *
     * @param context The Android context.
     * @param seed Base32-encoded TOTP seed from backend.
     * @return RegisterDeviceResult with success or error.
     */
    fun registerDevice(
        context: Context,
        seed: String,
    ): RegisterDeviceResult {
        AstroLogger.logDebug("Starting device registration with provided seed")

        // Step 1: Validate the Base32 seed
        val validationError = validateSeed(seed)
        if (validationError != null) {
            return RegisterDeviceResult.Error(validationError)
        }

        // Step 2: Check biometric availability (required for later TOTP generation)
        val errorCode = getBiometricErrorCode(context)
        if (errorCode != null) {
            AstroLogger.logDebug("Biometric not available: $errorCode")
            return RegisterDeviceResult.Error(errorCode)
        }

        // Step 3: Store seed securely as Base32 (no biometric prompt needed)
        val stored = storeSeed(context, seed)
        if (!stored) {
            AstroLogger.logDebug("Failed to store seed")
            return RegisterDeviceResult.Error(ErrorCode.KEYSTORE_ERROR)
        }

        val deviceInfo = getDeviceInfo()
        val deviceId = getDeviceId(context)

        AstroLogger.logDebug("Device registration successful")
        return RegisterDeviceResult.Success(
            deviceInfo = deviceInfo,
            deviceId = deviceId,
        )
    }

    /**
     * Gets or creates EncryptedSharedPreferences for secure seed storage.
     * Uses AES256 encryption with a MasterKey stored in Android Keystore.
     *
     * @param context The Android context.
     * @return EncryptedSharedPreferences instance, or null if creation fails.
     */
    private fun getEncryptedPrefs(context: Context): SharedPreferences? =
        try {
            val masterKey =
                MasterKey
                    .Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()

            EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to create EncryptedSharedPreferences: ${e.message}")
            null
        }

    /**
     * Stores the TOTP seed securely using EncryptedSharedPreferences.
     * The seed is stored as Base32 string and encrypted with AES256-GCM.
     */
    private fun storeSeed(
        context: Context,
        seed: String,
    ): Boolean {
        return try {
            val prefs = getEncryptedPrefs(context) ?: return false
            prefs.edit().putString(SEED_KEY, seed).apply()
            AstroLogger.logDebug("Seed stored successfully")
            true
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to store seed: ${e.message}")
            false
        }
    }

    /**
     * Checks if a seed exists.
     * @param context The Android context.
     * @return true if a seed exists.
     */
    fun hasSeed(context: Context): Boolean {
        return try {
            val prefs = getEncryptedPrefs(context) ?: return false
            prefs.contains(SEED_KEY)
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to check seed existence: ${e.message}")
            false
        }
    }

    /**
     * Deletes the stored seed.
     * @param context The Android context.
     * @return true if deletion was successful.
     */
    fun deleteSeed(context: Context): Boolean {
        return try {
            val prefs = getEncryptedPrefs(context) ?: return false
            prefs.edit().remove(SEED_KEY).apply()
            AstroLogger.logDebug("Seed deleted")
            true
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to delete seed: ${e.message}")
            false
        }
    }

    /**
     * Retrieves the stored seed from EncryptedSharedPreferences.
     * @param context The Android context.
     * @return The seed as Base32 string, or null if not found.
     */
    private fun retrieveSeed(context: Context): String? {
        return try {
            val prefs = getEncryptedPrefs(context) ?: return null
            val seed = prefs.getString(SEED_KEY, null)
            seed
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to retrieve seed: ${e.message}")
            null
        }
    }

    // ==================== TOTP Generation Methods ====================

    /**
     * Generates a TOTP code using the stored seed.
     * Requires biometric authentication to generate the code.
     *
     * @param activity The FragmentActivity required for BiometricPrompt.
     * @param callback Callback with TOTP result.
     */
    fun generateTOTP(
        activity: FragmentActivity,
        callback: (GenerateTOTPResult) -> Unit,
    ) {
        AstroLogger.logDebug("Generating TOTP")

        // Step 1: Check if seed exists
        if (!hasSeed(activity)) {
            AstroLogger.logDebug("No seed found")
            callback(GenerateTOTPResult.Error(ErrorCode.SEED_NOT_FOUND))
            return
        }

        // Step 2: Check biometric availability
        val errorCode = getBiometricErrorCode(activity)
        if (errorCode != null) {
            AstroLogger.logDebug("Biometric not available: $errorCode")
            callback(GenerateTOTPResult.Error(errorCode))
            return
        }

        // Step 3: Show biometric prompt
        val executor = ContextCompat.getMainExecutor(activity)

        val promptInfo =
            BiometricPrompt.PromptInfo
                .Builder()
                .setTitle("Verify Identity")
                .setSubtitle("Authenticate to generate verification code")
                .setNegativeButtonText("Cancel")
                .setAllowedAuthenticators(AndroidBiometricManager.Authenticators.BIOMETRIC_STRONG)
                .build()

        val biometricPrompt =
            BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        AstroLogger.logDebug("Biometric authentication succeeded for TOTP")

                        // Step 4: Retrieve seed (Base32)
                        val seedBase32 = retrieveSeed(activity)
                        if (seedBase32 == null) {
                            AstroLogger.logDebug("Failed to retrieve seed")
                            callback(GenerateTOTPResult.Error(ErrorCode.SEED_NOT_FOUND))
                            return
                        }

                        // Step 5: Decode Base32 to bytes
                        val seedBytes =
                            try {
                                base32Decode(seedBase32)
                            } catch (e: Exception) {
                                AstroLogger.logDebug("Failed to decode seed: ${e.message}")
                                callback(GenerateTOTPResult.Error(ErrorCode.TOTP_GENERATION_FAILED))
                                return
                            }

                        // Step 6: Calculate TOTP
                        val currentTime = System.currentTimeMillis()
                        val code = calculateTOTP(seedBytes, currentTime)
                        if (code == null) {
                            AstroLogger.logDebug("Failed to calculate TOTP")
                            callback(GenerateTOTPResult.Error(ErrorCode.TOTP_GENERATION_FAILED))
                            return
                        }

                        // Step 7: Calculate remaining seconds
                        val currentStep = currentTime / 1000 / TOTP_TIME_STEP
                        val nextStepTime = (currentStep + 1) * TOTP_TIME_STEP * 1000
                        val remainingSeconds = ((nextStepTime - currentTime) / 1000).toInt()

                        AstroLogger.logDebug("TOTP generated successfully, remaining: ${remainingSeconds}s")
                        callback(GenerateTOTPResult.Success(code, remainingSeconds))
                    }

                    override fun onAuthenticationError(
                        errorCode: Int,
                        errString: CharSequence,
                    ) {
                        super.onAuthenticationError(errorCode, errString)
                        AstroLogger.logDebug("Biometric authentication error for TOTP: $errString (code: $errorCode)")
                        val code = mapBiometricError(errorCode)
                        callback(GenerateTOTPResult.Error(code))
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        AstroLogger.logDebug("Biometric authentication failed for TOTP - user can retry")
                        // Don't call callback - user can retry
                    }
                },
            )

        biometricPrompt.authenticate(promptInfo)
    }

    /**
     * Generates TOTP without biometric prompt (for KeyguardManager fallback flow).
     * Call this after successful KeyguardManager authentication.
     *
     * @param context The Android context.
     * @return GenerateTOTPResult with success or error.
     */
    fun generateTOTPAfterAuth(context: Context): GenerateTOTPResult {
        AstroLogger.logDebug("Generating TOTP (post-auth)")

        // Retrieve seed (Base32)
        val seedBase32 = retrieveSeed(context)
        if (seedBase32 == null) {
            AstroLogger.logDebug("Failed to retrieve seed")
            return GenerateTOTPResult.Error(ErrorCode.SEED_NOT_FOUND)
        }

        // Decode Base32 to bytes
        val seedBytes =
            try {
                base32Decode(seedBase32)
            } catch (e: Exception) {
                AstroLogger.logDebug("Failed to decode seed: ${e.message}")
                return GenerateTOTPResult.Error(ErrorCode.TOTP_GENERATION_FAILED)
            }

        // Calculate TOTP
        val currentTime = System.currentTimeMillis()
        val code = calculateTOTP(seedBytes, currentTime)
        if (code == null) {
            AstroLogger.logDebug("Failed to calculate TOTP")
            return GenerateTOTPResult.Error(ErrorCode.TOTP_GENERATION_FAILED)
        }

        // Calculate remaining seconds
        val currentStep = currentTime / 1000 / TOTP_TIME_STEP
        val nextStepTime = (currentStep + 1) * TOTP_TIME_STEP * 1000
        val remainingSeconds = ((nextStepTime - currentTime) / 1000).toInt()

        AstroLogger.logDebug("TOTP generated successfully (post-auth), remaining: ${remainingSeconds}s")
        return GenerateTOTPResult.Success(code, remainingSeconds)
    }

    /**
     * Calculates TOTP code using RFC 6238 algorithm with HMAC-SHA1.
     * @param seed The secret key (seed).
     * @param timeMillis Current time in milliseconds.
     * @return The TOTP code as a string, or null if generation fails.
     */
    private fun calculateTOTP(
        seed: ByteArray,
        timeMillis: Long,
    ): String? =
        try {
            AstroLogger.logDebug("TOTP calculation - Seed size: ${seed.size} bytes")

            // Calculate time step counter (T)
            val counter = timeMillis / 1000 / TOTP_TIME_STEP

            // Convert counter to big-endian byte array (8 bytes)
            val counterBytes = ByteBuffer.allocate(8).putLong(counter).array()

            // Calculate HMAC-SHA1
            val mac = Mac.getInstance("HmacSHA1")
            val keySpec = SecretKeySpec(seed, "HmacSHA1")
            mac.init(keySpec)
            val hmac = mac.doFinal(counterBytes)

            // Dynamic truncation (RFC 4226)
            val offset = (hmac[hmac.size - 1].toInt() and 0x0f)
            val truncatedHash = (
                (hmac[offset].toInt() and 0x7f) shl 24
                    or ((hmac[offset + 1].toInt() and 0xff) shl 16)
                    or ((hmac[offset + 2].toInt() and 0xff) shl 8)
                    or (hmac[offset + 3].toInt() and 0xff)
            )

            // Generate code with specified number of digits
            val modulo = 10.0.pow(TOTP_DIGITS.toDouble()).toInt()
            val code = truncatedHash % modulo

            // Pad with leading zeros if necessary
            String.format("%0${TOTP_DIGITS}d", code)
        } catch (e: Exception) {
            AstroLogger.logDebug("Failed to calculate TOTP: ${e.message}")
            null
        }

    /**
     * Prepares TOTP generation for KeyguardManager flow.
     * @param context The Android context.
     * @return true if seed exists and device is secure.
     */
    fun prepareTOTPGeneration(context: Context): Boolean {
        if (!hasSeed(context)) {
            AstroLogger.logDebug("Cannot prepare TOTP: no seed found")
            return false
        }
        if (!deviceHasSecureLock(context)) {
            AstroLogger.logDebug("Cannot prepare TOTP: device not secure")
            return false
        }
        return true
    }

    /**
     * Gets device information string.
     */
    private fun getDeviceInfo(): String = "${Build.MANUFACTURER} ${Build.MODEL} - Android ${Build.VERSION.RELEASE}"

    /**
     * Gets unique device identifier.
     */
    private fun getDeviceId(context: Context): String =
        Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID,
        ) ?: java.util.UUID
            .randomUUID()
            .toString()

    /**
     * Maps BiometricPrompt error codes to our error codes.
     */
    private fun mapBiometricError(errorCode: Int): String =
        when (errorCode) {
            BiometricPrompt.ERROR_USER_CANCELED,
            BiometricPrompt.ERROR_NEGATIVE_BUTTON,
            BiometricPrompt.ERROR_CANCELED,
            -> ErrorCode.USER_CANCELLED

            BiometricPrompt.ERROR_HW_NOT_PRESENT,
            BiometricPrompt.ERROR_HW_UNAVAILABLE,
            -> ErrorCode.SECURE_HARDWARE_UNAVAILABLE

            BiometricPrompt.ERROR_NO_BIOMETRICS -> ErrorCode.BIOMETRIC_NOT_ENROLLED

            else -> ErrorCode.UNKNOWN
        }

    // ==================== KeyguardManager Fallback Methods ====================

    /**
     * Checks if device has a secure lock screen configured (PIN, pattern, password, or biometrics).
     * Used as fallback when BiometricPrompt is not available.
     *
     * @param context The Android context.
     * @return true if the device is secure.
     */
    fun deviceHasSecureLock(context: Context): Boolean {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val isSecure = keyguardManager.isDeviceSecure
        AstroLogger.logDebug("Device secure lock: $isSecure")
        return isSecure
    }

    /**
     * Creates an Intent to show the device's secure lock screen for authentication.
     * This is the fallback method when BiometricPrompt cannot be used.
     *
     * @param context The Android context.
     * @param title Title for the authentication dialog.
     * @param description Description for the authentication dialog.
     * @return Intent to launch, or null if device is not secure.
     */
    fun createKeyguardIntent(
        context: Context,
        title: String = "Register Device",
        description: String = "Authenticate to register this device for 2FA",
    ): Intent? {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

        if (!keyguardManager.isDeviceSecure) {
            AstroLogger.logDebug("Cannot create keyguard intent: device not secure")
            return null
        }

        @Suppress("DEPRECATION")
        return keyguardManager.createConfirmDeviceCredentialIntent(title, description)
    }

    /**
     * Prepares registration with a provided seed (for KeyguardManager flow).
     * Call this before launching the keyguard intent.
     *
     * @param context The Android context.
     * @param seed Base32-encoded TOTP seed from backend.
     * @return PendingRegistration with the decoded seed, or null if preparation fails.
     */
    fun prepareRegistration(
        context: Context,
        seed: String,
    ): PendingRegistration? {
        AstroLogger.logDebug("Preparing device registration (keyguard) with provided seed: $seed")

        // Check if device has secure lock
        if (!deviceHasSecureLock(context)) {
            AstroLogger.logDebug("Device not secure - no lock screen configured")
            return null
        }

        // Validate the Base32 seed
        val validationError = validateSeed(seed)
        if (validationError != null) {
            AstroLogger.logDebug("Invalid seed: $validationError")
            return null
        }

        return PendingRegistration(seed)
    }

    /**
     * Completes registration after successful KeyguardManager authentication.
     * Call this when the authentication result is RESULT_OK.
     *
     * @param context The Android context.
     * @param pendingRegistration The pending registration data from prepareRegistration.
     * @return RegisterDeviceResult with success or error.
     */
    fun completeRegistration(
        context: Context,
        pendingRegistration: PendingRegistration,
    ): RegisterDeviceResult {
        AstroLogger.logDebug("Completing device registration (keyguard)")

        // Store seed securely
        val stored = storeSeed(context, pendingRegistration.seed)
        if (!stored) {
            AstroLogger.logDebug("Failed to store seed")
            return RegisterDeviceResult.Error(ErrorCode.KEYSTORE_ERROR)
        }

        val deviceInfo = getDeviceInfo()
        val deviceId = getDeviceId(context)

        AstroLogger.logDebug("Device registration (keyguard) successful")
        return RegisterDeviceResult.Success(
            deviceInfo = deviceInfo,
            deviceId = deviceId,
        )
    }
}
