package com.astropay.connect.core

/**
 * Represents the available environments for AstroPay Connect SDK.
 * This is internal - use String values ("sandbox", "production") in configuration.
 */
internal enum class AstroEnvironment(val value: String) {
    PRODUCTION("production"),
    SANDBOX("sandbox"),
    TESTING("testing"),
    LOCAL("local"),
    UNKNOWN("unknown");

    /**
     * Returns the base URL for the current environment.
     * Uses centralized URLs from AstroConstants for consistency with iOS.
     */
    fun getBaseURL(localIP: String? = null): String? {
        return when (this) {
            PRODUCTION -> AstroConstants.Network.URLs.PRODUCTION
            SANDBOX -> AstroConstants.Network.URLs.SANDBOX
            TESTING -> AstroConstants.Network.URLs.TESTING
            LOCAL -> localIP?.let { "https://$it:${AstroConstants.Network.URLs.LOCAL_PORT}/" }
            UNKNOWN -> null
        }
    }

    /**
     * Checks if the environment is production.
     */
    val isProduction: Boolean
        get() = this == PRODUCTION

    /**
     * Checks if the environment is local.
     */
    val isLocal: Boolean
        get() = this == LOCAL

    /**
     * Checks if the environment is unknown.
     */
    val isUnknown: Boolean
        get() = this == UNKNOWN

    companion object {
        /**
         * Creates an AstroEnvironment from a string value.
         */
        fun fromString(value: String): AstroEnvironment {
            return entries.find { it.value.equals(value, ignoreCase = true) } ?: UNKNOWN
        }
    }
}
