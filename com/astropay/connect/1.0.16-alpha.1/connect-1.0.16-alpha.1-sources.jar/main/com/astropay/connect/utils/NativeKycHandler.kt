package com.astropay.connect.utils

import android.content.Context

/**
 * Possible terminal statuses for a native KYC session.
 */
internal enum class NativeKycStatus(val value: String) {
    OK("OK"),
    CANCELLED("CANCELLED"),
    ERROR("ERROR")
}

/**
 * Error codes returned in the KYC result payload when status is ERROR.
 */
internal enum class NativeKycErrorCode(val value: String) {
    INVALID_TOKEN("INVALID_TOKEN"),
    PERMISSION_DENIED("PERMISSION_DENIED"),
    SDK_ERROR("SDK_ERROR"),
    // Terminal error returned when the web requests a native KYC provider this SDK does not support.
    // Cross-platform contract: the web can fall back deterministically to the iframe flow on old
    // SDKs. Wire value MUST match iOS exactly.
    UNSUPPORTED_PROVIDER("UNSUPPORTED_PROVIDER"),
    UNKNOWN("UNKNOWN")
}

/**
 * Value type representing the result of a native KYC session.
 * [jsonString] serialises the result to the JSON format expected by the web layer.
 *
 * Serialisation uses [org.json.JSONObject] so user-controlled token values are properly
 * escaped (guards against JSON injection in the values passed to evaluateJavascript).
 */
internal data class NativeKycResult(
    val status: NativeKycStatus,
    val errorCode: NativeKycErrorCode? = null,
    val livenessToken: String? = null,
    val documentToken: String? = null,
) {
    val jsonString: String
        get() {
            val map = when (status) {
                NativeKycStatus.OK -> buildMap {
                    put("status", NativeKycStatus.OK.value)
                    livenessToken?.let { put("livenessToken", it) }
                    documentToken?.let { put("documentToken", it) }
                }
                NativeKycStatus.CANCELLED -> mapOf("status" to NativeKycStatus.CANCELLED.value)
                NativeKycStatus.ERROR -> mapOf(
                    "status" to NativeKycStatus.ERROR.value,
                    "code" to (errorCode?.value ?: NativeKycErrorCode.UNKNOWN.value),
                )
            }
            return JSONConverter.mapToJsonString(map)
        }
}

/**
 * Resolved, CAF-ready colors handed to the native KYC engine.
 *
 * Each non-null field is a `#RRGGBB` string already resolved at the call site to either the
 * partner color (via the native style resolvers) or today's theme fallback constant, and
 * normalized so the value is always a valid opaque 6-digit hex. This type carries only Strings and
 * lives in the CAF-free `src/main` path so both flavors compile against it; the CAF layer never
 * sees the [com.astropay.connect.core.AstroStyle] model or the resolvers.
 *
 * [secondaryColor] (primary-button text + spinner) and [mediumColor] (card stroke / borders /
 * dividers) are NULLABLE pass-through: the resolver sets them only when a real partner token
 * resolves and leaves them `null` otherwise, so the mapper omits them and CAF keeps its own
 * default. The SDK owns no fallback for these two, to avoid regressing no-style partners away from
 * CAF's defaults. [contentColor] stays non-null (titles/body text is safety-critical, so it keeps
 * a guaranteed-legible theme fallback).
 */
internal data class NativeKycColors(
    val primaryColor: String,
    val backgroundColor: String,
    val contentColor: String,
    val dialogBackgroundColor: String,
    val dialogBorderColor: String,
    val secondaryColor: String? = null,
    val mediumColor: String? = null,
)

/**
 * Non-terminal progress steps a native KYC session can report while it runs.
 *
 * These identify a CAF-free progress signal derived inside the engine layer and mapped to an
 * [com.astropay.connect.core.AstroEvent] at the call site (see `NativeKycEventMapper`). They are
 * additive analytics signals, never terminal — a session always ends through [NativeKycResult],
 * not through one of these steps.
 */
internal enum class NativeKycEventStep {
    /** The engine has begun initializing (before any capture UI). Fired at most once. */
    LOADING,

    /** The flow produced a document-detector result. Fired once at the terminal success. */
    DOCUMENT_CAPTURED,

    /** The flow produced a face-liveness result. Fired once at the terminal success. */
    LIVENESS_CAPTURED,
}

/**
 * CAF-free progress event emitted by the native KYC engine layer.
 *
 * A plain data holder (no CAF types, no [com.astropay.connect.core.AstroEvent]) so it lives in the
 * always-compiled `src/main` path and both flavors compile against it. The engine (`CAFManager`,
 * `nativeKyc` flavor only) produces it; the call site maps it to an
 * [com.astropay.connect.core.AstroEvent] via `NativeKycEventMapper` and fires the same `onEvent`
 * sink the web uses. The core stub never emits any.
 *
 * @param step Which progress step this event represents.
 * @param properties Optional wire properties (e.g. `{ "module": "documentDetector" }`); null for
 *   [NativeKycEventStep.LOADING]. The engine places the shared wire values here so the call-site
 *   mapper stays a dumb enum→name lookup.
 */
internal data class NativeKycEvent(
    val step: NativeKycEventStep,
    val properties: Map<String, String>? = null,
)

/**
 * Deployment environment handed to the native KYC engine, derived from
 * [com.astropay.connect.core.AstroConfiguration]'s environment at the call site.
 *
 * CAF-free (a plain enum in `src/main`) so both flavors compile against it and the CAF layer stays
 * decoupled from the SDK's environment model. The engine maps it to its own environment/security
 * switches:
 * - [PRODUCTION] → CAF production environment; security module ON, developer/debug switches OFF.
 * - [SANDBOX] → CAF's non-production/staging environment; developer/debug switches ON so QA can
 *   exercise the flow without a release build.
 *
 * The web sends `environment: 'sandbox' | 'production'` over the bridge; the call site maps any
 * non-production environment (sandbox/testing/local) to [SANDBOX].
 */
internal enum class NativeKycEnvironment {
    PRODUCTION,
    SANDBOX,
}

/**
 * Handle returned by [NativeKycHandler.startKyc] that lets the caller abort the in-flight
 * KYC session without going through the engine's own callbacks.
 *
 * Used by the lifecycle-resume back-out detection in the view layer: when the host Activity
 * resumes while a KYC session is still pending (CAF popped its Activities without firing a
 * terminal event), the view delivers a synthetic `CANCELLED` result and calls [cancel] so the
 * engine's watchdog and any late engine callback are suppressed (no double delivery).
 *
 * Implementations must be idempotent and safe to call on the main thread.
 */
internal interface NativeKycSession {
    /**
     * Suppresses any future result from this session: the engine's watchdog is removed and a
     * single-shot guard is flipped so a late engine callback delivers nothing.
     */
    fun cancel()
}

/**
 * Build-time abstraction over the native KYC engine. The real CAF-backed implementation
 * exists only in the `nativeKyc` source set; the `core` source set provides a stub that reports
 * KYC as unavailable. Resolved per build flavor, never registered at runtime.
 */
internal interface NativeKycHandler {
    /**
     * Starts the native KYC flow. [onResult] is invoked exactly once on the main thread.
     *
     * @param context Application or Activity context.
     * @param token KYC mobile token from the bridge payload.
     * @param userId The user identifier passed to the KYC engine.
     * @param docTypes Document type strings from the bridge payload.
     * @param theme Resolved theme string ("light" or "dark"); still the fallback key already
     *   applied upstream when resolving [colors].
     * @param colors Pre-resolved, CAF-ready colors ([NativeKycColors]); the engine passes them
     *   straight through to its color configuration with no further style-model coupling.
     * @param forceTheme True only when the integrator explicitly forced LIGHT/DARK (not SYSTEM);
     *   drives the engine's base-appearance pinning. When false the engine follows the device.
     * @param environment The deployment environment ([NativeKycEnvironment]). Does NOT select the
     *   CAF environment (CAF always runs against PROD now); it only drives the CAF debug/security
     *   switches (SANDBOX relaxes them for QA). Derived from the SDK configuration's environment at
     *   the call site.
     * @param onEvent Called 0..N times on the main thread with non-terminal progress
     *   ([NativeKycEvent]), always BEFORE the terminal [onResult]. The `core` stub never invokes it
     *   (no engine → no progress).
     * @param onResult Called exactly once on the main thread with the terminal result.
     * @return A [NativeKycSession] handle the caller can use to abort the session (e.g. on
     *   host-Activity resume after a silent CAF back-out). The `core` stub returns a no-op handle.
     */
    fun startKyc(
        context: Context,
        token: String,
        userId: String,
        docTypes: List<String>,
        theme: String,
        colors: NativeKycColors,
        forceTheme: Boolean,
        environment: NativeKycEnvironment,
        onEvent: (NativeKycEvent) -> Unit,
        onResult: (NativeKycResult) -> Unit,
    ): NativeKycSession
}
