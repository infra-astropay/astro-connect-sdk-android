package com.astropay.connect.utils

import android.net.Uri
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.core.isValidHexColor
import com.astropay.connect.core.resolveNativeBackgroundColor
import com.astropay.connect.core.resolveNativePrimaryColor
import com.astropay.connect.core.toAstroHex

/**
 * Utility class for building URLs for AstroPay Connect SDK.
 */
internal object URLBuilder {

    /**
     * Builds the complete URL for the SDK based on the configuration.
     *
     * @param configuration The SDK configuration.
     * @param themeParameter The resolved theme parameter ("light" or "dark").
     * @return The complete URL string, or null if the base URL cannot be determined or is invalid.
     */
    fun buildURL(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String? {
        val baseURL = configuration.environment.getBaseURL(configuration.localIP)

        if (baseURL == null) {
            val error =
                AstroError(
                    ErrorCode.INITIALIZATION_ERROR,
                    null,
                    "Invalid base URL for environment: ${configuration.environment}",
                )
            AstroLogger.logError(error)
            return null
        }

        // Validate URL before proceeding (matching iOS behavior)
        if (!NetworkUtils.isValidURL(baseURL)) {
            val error =
                AstroError(
                    ErrorCode.INITIALIZATION_ERROR,
                    null,
                    "Base URL failed validation: $baseURL",
                )
            AstroLogger.logError(error)
            return null
        }

        val uriBuilder = Uri.parse(baseURL).buildUpon()

        // Add cache buster
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.VERSION,
            System.currentTimeMillis().toString(),
        )

        // Add theme
        val issuerPrefix = configuration.appIssuer.lowercase()
        val prefixedTheme = if (issuerPrefix.isBlank() || issuerPrefix == "default") {
            themeParameter
        } else {
            "${issuerPrefix}_$themeParameter"
        }
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.THEME,
            prefixedTheme,
        )

        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.ACCESS_TOKEN,
            configuration.accessToken,
        )

        // Add language
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.LANGUAGE,
            configuration.language,
        )

        // Add color overrides from style. Each must be a 6- or 8-digit hex
        // (`#RRGGBB` or `#RRGGBBAA`, with optional leading '#') to match the
        // format the web side accepts; the alpha suffix is forwarded as-is
        // for parity with the native chrome path. Invalid values are dropped
        // with a logged error rather than producing a bad URL.
        val style = configuration.style
        val styleOverrides = configuration.styleOverrides
        appendHexColorParam(
            uriBuilder, AstroConstants.QueryParams.BACKGROUND_COLOR,
            "resolved bg_color",
            resolveNativeBackgroundColor(style, styleOverrides)?.toAstroHex(),
        )
        appendHexColorParam(
            uriBuilder, AstroConstants.QueryParams.PRIMARY_COLOR,
            "resolved primary_color",
            resolveNativePrimaryColor(style, styleOverrides)?.toAstroHex(),
        )

        return uriBuilder.build().toString()
    }

    private fun appendHexColorParam(
        uriBuilder: Uri.Builder,
        paramName: String,
        fieldLabel: String,
        value: String?,
    ) {
        val trimmed = value?.takeIf { it.isNotBlank() } ?: return
        if (isValidHexColor(trimmed)) {
            uriBuilder.appendQueryParameter(paramName, trimmed)
        } else {
            AstroLogger.logError(
                AstroError(
                    ErrorCode.INITIALIZATION_ERROR,
                    null,
                    "Invalid $fieldLabel '$trimmed': expected 6- or 8-digit hex (e.g. '#1a2b3c' or '#1a2b3cff'). Parameter omitted.",
                ),
            )
        }
    }

    /**
     * Builds a URL with custom query parameters.
     *
     * @param baseURL The base URL.
     * @param params The query parameters to add.
     * @return The complete URL string.
     */
    fun buildURL(
        baseURL: String,
        params: Map<String, String>,
    ): String {
        val uriBuilder = Uri.parse(baseURL).buildUpon()

        params.forEach { (key, value) ->
            uriBuilder.appendQueryParameter(key, value)
        }

        return uriBuilder.build().toString()
    }
}
