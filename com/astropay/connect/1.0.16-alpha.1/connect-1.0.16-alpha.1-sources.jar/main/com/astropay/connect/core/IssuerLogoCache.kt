package com.astropay.connect.core

import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * In-memory cache for issuer logo bitmaps.
 *
 * Populated by [com.astropay.connect.AstroPreloader] during pre-warm so that when
 * [com.astropay.connect.views.AstroConnectView] mounts, the logo is already available
 * without a network round-trip.
 */
internal object IssuerLogoCache {

    private const val TIMEOUT_MS = 5_000
    private const val MAX_BYTES = 5 * 1024 * 1024

    private val cache = ConcurrentHashMap<String, ImageBitmap>()

    fun get(url: String): ImageBitmap? = cache[url]

    fun put(url: String, bitmap: ImageBitmap) {
        cache[url] = bitmap
    }

    /** Downloads [url] and stores the result in the cache. Safe to call from any thread. */
    fun prefetch(url: String) {
        if (cache.containsKey(url)) return
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                connect()
            }
            if (connection.contentLength > MAX_BYTES) return
            val bytes = connection.inputStream.use { it.readBoundedBytes(MAX_BYTES) } ?: return
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            if (bitmap != null) {
                cache[url] = bitmap
            }
        } catch (_: Exception) {
            // Silently ignore — logo will be fetched on-demand at render time.
        } finally {
            connection?.disconnect()
        }
    }

    private fun InputStream.readBoundedBytes(max: Int): ByteArray? {
        val buffer = ByteArrayOutputStream()
        val chunk = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val read = read(chunk)
            if (read == -1) break
            total += read
            if (total > max) return null
            buffer.write(chunk, 0, read)
        }
        return buffer.toByteArray()
    }
}
