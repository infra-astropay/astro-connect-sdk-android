package com.astropay.connect

import android.os.Handler
import android.os.Looper
import com.astropay.connect.core.AstroLogger

/**
 * Public controller that lets integrators imperatively dismiss an active [com.astropay.connect.views.AstroConnectView].
 *
 * Intended for custom-header integrations (`showHeader = false`) where the host app provides its
 * own close affordance and must funnel into the same close path that the built-in header button
 * uses. The controller is created by the integrator, passed into `AstroConnectView`, and `close()`
 * is invoked from the host's custom UI.
 *
 * Close payload:
 * - Integrators do not provide a `code` / `message`. When [close] fires from the controller, the
 *   SDK emits a fixed payload: `code = "CLOSED_BY_HOST_APP"`, `message = "Closed by host integrator"`.
 *   These values are documented and stable; they identify the close source on the receiving
 *   `AstroResult.Closed` and are not configurable.
 *
 * Lifetime:
 * - The view attaches itself by setting [onCloseRequest] when it mounts (composes) and clears it
 *   when it disposes. Calling [close] outside of that window is a safe no-op.
 *
 * Idempotency:
 * - Idempotency is provided by `AstroConnectView`'s own internal state — calling [close] twice in
 *   the same presentation is safe (the second call is collapsed into a no-op by the view). The
 *   controller does not carry state across presentations.
 *
 * Threading:
 * - [close] is safe to call from any thread; it posts to the main looper before invoking the
 *   attached close request, matching the threading model used elsewhere in the SDK.
 */
public class AstroConnectController {
    /**
     * Closure installed by `AstroConnectView` while the view is mounted. The view's
     * `handleClose` lambda owns the idempotency guard and emits `AstroResult.Closed`.
     */
    @Volatile
    internal var onCloseRequest: ((String, String) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Requests dismissal of the attached `AstroConnectView`.
     *
     * Posts to the main looper, then invokes the view-installed close request with the
     * SDK-fixed developer payload (`"CLOSED_BY_HOST_APP"`, `"Closed by host integrator"`).
     * If no view is currently attached the call is a logged no-op. Repeated calls within the
     * same presentation are collapsed by the view's own idempotency guard.
     */
    public fun close() {
        mainHandler.post {
            val request = onCloseRequest
            if (request == null) {
                AstroLogger.logDebug("AstroConnectController.close: no attached view — no-op")
                return@post
            }
            request.invoke(DEFAULT_CODE, DEFAULT_MESSAGE)
        }
    }

    private companion object {
        const val DEFAULT_CODE = "CLOSED_BY_HOST_APP"
        const val DEFAULT_MESSAGE = "Closed by host integrator"
    }
}
