package com.astropay.connect

import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import com.astropay.connect.core.AppContext
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogSetting
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode

/**
 * Entry point for the AstroPay Connect SDK static API.
 *
 * To display the SDK, use the [com.astropay.connect.views.AstroConnectView] composable.
 *
 * Usage (pre-warm, call as early as possible — e.g. Application.onCreate):
 * ```kotlin
 * AstroConnect.preWarm(environment = "sandbox")
 * ```
 *
 * Usage (preload, call before showing the SDK to skip loaders entirely):
 * ```kotlin
 * AstroConnect.preload(configuration = configuration)
 * ```
 */
object AstroConnect {

    /**
     * Pre-loads the SDK web page in a hidden WebView using the full [configuration].
     *
     * Call this before presenting the SDK (e.g. when the user lands on a screen that
     * will open the SDK shortly). When [com.astropay.connect.views.AstroConnectView] is later composed with the
     * same configuration the preloaded WebView is shown instantly — no loader is displayed.
     *
     * If the SDK is opened while the preload is still in progress the same WebView is
     * used and will render progressively (faster than a cold start).
     *
     * If the configuration passed to [com.astropay.connect.views.AstroConnectView] differs from the preloaded one the
     * preload is discarded and a fresh WebView is created instead.
     *
     * The [logSetting] from [configuration] is used automatically — no separate parameter
     * is needed.
     *
     * `onPreloadEnded` fires exactly once with one of:
     * - [AstroPreloadEndReason.Loaded]: the page completed loading during preload.
     * - [AstroPreloadEndReason.Deferred]: the preload ended before the page fully
     *   loaded — either because a biometric prompt was deferred until the SDK becomes
     *   visible, or because [com.astropay.connect.views.AstroConnectView] was displayed
     *   before loading finished. The remaining work continues on the live view.
     * - [AstroPreloadEndReason.Failed]: the preload failed (network error, timeout,
     *   invalid configuration, …).
     *
     * @param configuration The full SDK configuration (same one that will be passed to [com.astropay.connect.views.AstroConnectView]).
     * @param onPreloadEnded Called once with the reason the preload phase ended.
     */
    @JvmStatic
    fun preload(
        configuration: AstroConfiguration,
        onPreloadEnded: ((AstroPreloadEndReason) -> Unit)? = null,
    ) {
        Handler(Looper.getMainLooper()).post {
            AstroPreloadSession.start(configuration = configuration, onPreloadEnded = onPreloadEnded)
        }
    }

    /**
     * Deprecated. Use [preload] with `onPreloadEnded` instead.
     *
     * The new callback delivers a single terminal result that distinguishes a
     * fully loaded page from a deferred handoff (biometric prompt or early view
     * display). For backward compatibility this overload still invokes
     * [onSuccess] in the deferred case so existing integrators are not left
     * waiting indefinitely.
     */
    @Deprecated(
        message = "Use preload(configuration, onPreloadEnded) to receive a single terminal result that distinguishes a loaded page from a deferred handoff.",
        replaceWith = ReplaceWith("preload(configuration, onPreloadEnded = { /* handle reason */ })"),
    )
    @JvmStatic
    fun preload(
        configuration: AstroConfiguration,
        onSuccess: (() -> Unit)? = null,
        onError: ((AstroError) -> Unit)? = null,
    ) {
        Handler(Looper.getMainLooper()).post {
            AstroPreloadSession.start(configuration, onSuccess, onError)
        }
    }

    /**
     * Clears all web data (cookies, localStorage, IndexedDB, HTTP cache) for the SDK.
     * On Android clearing is performed globally — it affects all domains used by the
     * app's WebView, as Android provides no per-domain clearing API.
     *
     * Also discards any active preload session.
     *
     * Call this to simulate a fresh app install or to force the SDK to start with
     * a clean state (e.g. after user logout).
     *
     * @param environment Target environment ("production", "sandbox", "testing", "local").
     *   Accepted for API consistency with iOS; not used for filtering on Android.
     * @param localIP Accepted for API consistency with iOS; not used on Android.
     * @param onSuccess Called when clearing completes.
     * @param onError Called if clearing fails unexpectedly.
     */
    @JvmStatic
    fun clear(
        environment: String,
        localIP: String? = null,
        onSuccess: (() -> Unit)? = null,
        onError: ((AstroError) -> Unit)? = null,
    ) {
        Handler(Looper.getMainLooper()).post {
            AstroPreloadSession.discard()
            val context = AppContext.get()
            try {
                CookieManager.getInstance().apply {
                    removeAllCookies(null)
                    flush()
                }
                WebStorage.getInstance().deleteAllData()
                WebView(context).clearCache(true)
                AstroLogger.logInfo("AstroConnect.clear: cleared all web data")
                onSuccess?.invoke()
            } catch (e: Exception) {
                val error = AstroError(ErrorCode.INITIALIZATION_ERROR, null, "AstroConnect.clear: failed — ${e.message}")
                AstroLogger.logError(error)
                onError?.invoke(error)
            }
        }
    }

    /**
     * Pre-warms the WebView renderer and registers the Service Worker in the background.
     *
     * Call as early as possible (e.g. Application.onCreate or MainActivity.onCreate).
     * The renderer stays warm permanently so subsequent SDK opens have no cold-start.
     *
     * @param environment Target environment ("production", "sandbox", "testing").
     * @param logSetting Optional logging configuration.
     * @param onSuccess Called when the Service Worker has been registered.
     * @param onError Called if pre-warming fails (e.g. timeout or invalid environment).
     */
    @JvmStatic
    fun preWarm(
        environment: String,
        localIP: String? = null,
        appIssuer: String? = null,
        logSetting: AstroLogSetting? = null,
        force: Boolean = false,
        onSuccess: (() -> Unit)? = null,
        onError: ((AstroError) -> Unit)? = null,
    ) {
        Handler(Looper.getMainLooper()).post {
            AstroPreloader.preWarm(environment, localIP, appIssuer, logSetting, force, onSuccess, onError)
        }
    }
}
