package com.astropay.connect

import android.annotation.SuppressLint
import android.net.Uri
import android.net.http.SslError
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.MainThread
import com.astropay.connect.core.AppContext
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroEnvironment
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogSetting
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.core.IssuerLogoCache
import kotlin.concurrent.thread

/**
 * Pre-warms the Chromium renderer and registers the Service Worker in the background.
 *
 * After the SW finishes (preload-done signal), the WebView is navigated to about:blank
 * and kept alive permanently so the renderer stays warm for future SDK opens.
 */
internal object AstroPreloader {
    private val mainHandler = Handler(Looper.getMainLooper())

    // All state below is only accessed on the main thread via mainHandler.post {}
    private var isLoading = false
    private var didFinish = false
    private var currentEnvironment: String? = null
    private val pendingSuccess = mutableListOf<() -> Unit>()
    private val pendingError = mutableListOf<(AstroError) -> Unit>()

    /** Holds the preload WebView after completion — keep-alive for the Chromium renderer. */
    @Suppress("unused")
    private var keepAliveWebView: WebView? = null

    // -----------------------------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------------------------

    @MainThread
    fun preWarm(
        environment: String,
        localIP: String?,
        appIssuer: String?,
        logSetting: AstroLogSetting?,
        force: Boolean,
        onSuccess: (() -> Unit)?,
        onError: ((AstroError) -> Unit)?,
    ) {
        if (force) {
            didFinish = false
        }

        if (didFinish && currentEnvironment == environment) {
            onSuccess?.invoke()
            return
        }

        if (isLoading) {
            onSuccess?.let { pendingSuccess.add(it) }
            onError?.let { pendingError.add(it) }
            return
        }

        currentEnvironment = environment
        isLoading = true
        onSuccess?.let { pendingSuccess.add(it) }
        onError?.let { pendingError.add(it) }

        if (logSetting != null) {
            AstroLogger.configure(logSetting, AstroEnvironment.fromString(environment))
        }

        warmRenderer()
        startWebViewPreload(environment, localIP)
        if (!appIssuer.isNullOrBlank()) {
            prefetchIssuerLogos(environment, appIssuer)
        }
    }

    /**
     * Kicks off background downloads of the issuer logos (and astropay fallback) for both
     * light and dark themes, storing them in [IssuerLogoCache] so [AstroConnectView] can
     * show them without a network round-trip on first mount.
     */
    private fun prefetchIssuerLogos(
        environment: String,
        appIssuer: String,
    ) {
        val env = AstroEnvironment.fromString(environment)
        val base =
            when (env) {
                AstroEnvironment.PRODUCTION, AstroEnvironment.SANDBOX -> {
                    AstroConstants.Assets.ISSUER_LOGO_BASE_PROD
                }

                else -> {
                    AstroConstants.Assets.ISSUER_LOGO_BASE_TESTING
                }
            }
        val issuerSlug = appIssuer.lowercase()
        val urls =
            listOf(
                "$base/${issuerSlug}_light.webp",
                "$base/${issuerSlug}_dark.webp",
                "$base/astropay_light.webp",
                "$base/astropay_dark.webp",
            )
        AstroLogger.logDebug("AstroPreloader: prefetching logo")
        urls.forEach { url ->
            thread(isDaemon = true, name = "AstroPreloader-logo") {
                IssuerLogoCache.prefetch(url)
            }
        }
    }

    // -----------------------------------------------------------------------------------------
    // Internal
    // -----------------------------------------------------------------------------------------

    /** Instantiates an empty WebView to warm up the Chromium renderer process. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun warmRenderer() {
        val wv = WebView(AppContext.get())
        wv.settings.javaScriptEnabled = true
        // Fire and forget — the renderer process persists even if this instance is GC'd.
        AstroLogger.logDebug("AstroPreloader: renderer warm-up initiated")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun startWebViewPreload(
        environment: String,
        localIP: String?,
    ) {
        val baseURL = AstroEnvironment.fromString(environment).getBaseURL(localIP)
        if (baseURL == null) {
            handleCompletion(
                success = false,
                error = AstroError(ErrorCode.INITIALIZATION_ERROR, null, "AstroPreloader: invalid environment '$environment'"),
            )
            return
        }

        val preloadURL =
            Uri
                .parse(baseURL)
                .buildUpon()
                .appendQueryParameter(AstroConstants.QueryParams.PRELOAD, "true")
                .build()
                .toString()

        val wv = WebView(AppContext.get())
        keepAliveWebView = wv

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }

        // Primary signal: JS Interface called by the web page
        wv.addJavascriptInterface(
            object : Any() {
                @JavascriptInterface
                fun onPreloadDone() {
                    mainHandler.post {
                        handleCompletion(success = true, error = null)
                    }
                }
            },
            AstroConstants.Bridge.PRELOADER_OBJECT_NAME,
        )

        val isLocal = AstroEnvironment.fromString(environment).isLocal

        // Fallback signal: detect location.hash = "preload-done" via URL changes
        wv.webViewClient =
            object : WebViewClient() {
                override fun onPageFinished(
                    view: WebView?,
                    url: String?,
                ) {
                    // no-op — rely on JS Interface + hash fallback
                }

                override fun doUpdateVisitedHistory(
                    view: WebView?,
                    url: String?,
                    isReload: Boolean,
                ) {
                    if (url != null && Uri.parse(url).fragment == AstroConstants.Preload.DONE_HASH) {
                        mainHandler.post {
                            handleCompletion(success = true, error = null)
                        }
                    }
                }

                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler?,
                    error: SslError?,
                ) {
                    if (isLocal) {
                        handler?.proceed()
                    } else {
                        handler?.cancel()
                    }
                }
            }

        // Timeout safety net
        mainHandler.postDelayed(
            {
                handleCompletion(
                    success = false,
                    error =
                        AstroError(
                            ErrorCode.TIMEOUT,
                            null,
                            "AstroPreloader: timed out after ${AstroConstants.Preload.TIMEOUT_MS / 1000}s",
                        ),
                )
            },
            AstroConstants.Preload.TIMEOUT_MS,
        )

        AstroLogger.logDebug("AstroPreloader: loading")
        wv.loadUrl(preloadURL)
    }

    @MainThread
    private fun handleCompletion(
        success: Boolean,
        error: AstroError?,
    ) {
        if (!isLoading) return
        isLoading = false
        didFinish = success

        // Navigate to about:blank to release page resources while keeping the renderer alive.
        keepAliveWebView?.loadUrl("about:blank")

        val successes = pendingSuccess.toList()
        val errors = pendingError.toList()
        pendingSuccess.clear()
        pendingError.clear()

        if (success) {
            AstroLogger.logInfo("AstroPreloader: Service Worker registered")
            successes.forEach { it() }
        } else {
            AstroLogger.logDebug("AstroPreloader: failed — ${error?.errorDetail}")
            errors.forEach { it(error!!) }
        }
    }
}
