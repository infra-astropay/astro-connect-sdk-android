package com.astropay.connect.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.astropay.connect.core.AstroLogger

/**
 * Utility class for managing camera permissions.
 */
internal object CameraManager {

    /**
     * Camera permission status values.
     */
    object PermissionStatus {
        const val AUTHORIZED = "authorized"
        const val DENIED = "denied"
        const val NOT_DETERMINED = "notDetermined"
        const val RESTRICTED = "restricted"
        const val UNKNOWN = "unknown"
    }

    /**
     * Checks if camera permission is granted.
     *
     * @param context The Android context.
     * @return true if permission is granted, false otherwise.
     */
    fun hasCameraPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Gets the current camera permission status as a string.
     * Matches iOS SDK behavior with proper status detection.
     *
     * @param context The Android context.
     * @param activity Optional activity to check shouldShowRequestPermissionRationale.
     * @return The permission status string.
     */
    fun getCameraPermissionStatus(context: Context, activity: android.app.Activity? = null): String {
        val status = when {
            hasCameraPermission(context) -> PermissionStatus.AUTHORIZED
            activity != null && !androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(
                activity,
                Manifest.permission.CAMERA
            ) && hasRequestedPermissionBefore(context) -> PermissionStatus.DENIED
            else -> PermissionStatus.NOT_DETERMINED
        }
        AstroLogger.logDebug("Camera permission status: $status")
        return status
    }

    /**
     * Checks if the camera permission has been requested before.
     * Uses SharedPreferences to track permission request history.
     */
    private fun hasRequestedPermissionBefore(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_CAMERA_PERMISSION_REQUESTED, false)
    }

    /**
     * Marks that camera permission has been requested.
     * Should be called when requesting the permission.
     */
    fun markPermissionRequested(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_CAMERA_PERMISSION_REQUESTED, true).apply()
    }

    private const val PREFS_NAME = "astro_connect_prefs"
    private const val KEY_CAMERA_PERMISSION_REQUESTED = "camera_permission_requested"

    /**
     * Converts a permission grant result to a status string.
     *
     * @param granted Whether the permission was granted.
     * @return The permission status string.
     */
    fun getStatusFromResult(granted: Boolean): String {
        val status = if (granted) {
            PermissionStatus.AUTHORIZED
        } else {
            PermissionStatus.DENIED
        }
        AstroLogger.logDebug("Camera permission request result: $status")
        return status
    }

    /**
     * The camera permission constant for use in permission requests.
     */
    const val CAMERA_PERMISSION = Manifest.permission.CAMERA

    /**
     * The media permissions requested together at the start of any camera/KYC flow.
     *
     * CAMERA is required by every WebView camera flow and by the native CAF KYC document/liveness
     * steps; RECORD_AUDIO is additionally required by the CAF face-liveness step. Both are requested
     * in a single prompt so the native KYC path never needs a second, separate mic prompt.
     *
     * NOTE: this set is only about what is *requested*. The permission status reported to the web
     * bridge is camera-only (see [getStatusFromResult] callers), and a combined WebView
     * `PermissionRequest` is granted per-resource against the OS permission actually held — a mic
     * denial never downgrades the camera result to `denied`.
     */
    val REQUIRED_MEDIA_PERMISSIONS = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
    )

    /**
     * Request code for camera permission.
     */
    const val CAMERA_PERMISSION_REQUEST_CODE = 1001
}
