
package com.astropay.connect.core

import android.util.Log

/**
 * Log level for AstroPay Connect SDK logging.
 */
enum class AstroLogLevel(
    val level: Int,
) {
    ERROR(0),
    INFO(1),
    DEBUG(2),
}

/**
 * Configuration for SDK logging behavior.
 */
data class AstroLogSetting(
    val enabled: Boolean,
    val verbose: Boolean = false,
    val logLevel: AstroLogLevel = AstroLogLevel.ERROR,
) {
    constructor(enabled: Boolean) : this(enabled, false, AstroLogLevel.ERROR)
}

/**
 * Logger utility for AstroPay Connect SDK.
 * Provides structured logging with configurable levels and verbosity.
 *
 * Note: Logging is automatically disabled in production environment for security.
 */
internal object AstroLogger {
    var logSettings: AstroLogSetting = AstroLogSetting(enabled = false, verbose = false)
        private set

    var environment: AstroEnvironment = AstroEnvironment.PRODUCTION
        private set

    private val tag = AstroConstants.Logging.TAG

    fun logInfo(
        message: String,
        details: String? = null,
    ) {
        if (!shouldLog(AstroLogLevel.INFO)) return
        val formattedMessage = "${AstroConstants.Logging.PREFIX} $message"
        Log.i(tag, formattedMessage)
        if (logSettings.verbose && details != null) {
            Log.i(tag, details)
        }
    }

    fun logDebug(
        message: String,
        details: String? = null,
    ) {
        if (!shouldLog(AstroLogLevel.DEBUG)) return
        val formattedMessage = "${AstroConstants.Logging.PREFIX} $message"
        Log.d(tag, formattedMessage)
        if (logSettings.verbose && details != null) {
            Log.d(tag, details)
        }
    }

    fun logError(error: AstroError) {
        if (!shouldLog(AstroLogLevel.ERROR)) return

        var logMessage =
            """
            ${AstroConstants.Logging.PREFIX} ERROR
            Code: ${error.errorCode}
            """.trimIndent()

        error.errorSubCode?.let { subCode ->
            logMessage += "\nSubCode: $subCode"
        }

        logMessage += "\nDescription: ${error.errorDescription}"

        Log.e(tag, logMessage)
    }

    // MARK: - Private Helpers

    private fun shouldLog(level: AstroLogLevel): Boolean {
        if (environment.isProduction) {
            return false
        }

        if (!logSettings.enabled) return false

        return when (level) {
            AstroLogLevel.ERROR -> logSettings.logLevel.level >= AstroLogLevel.ERROR.level
            AstroLogLevel.INFO -> logSettings.logLevel.level >= AstroLogLevel.INFO.level
            AstroLogLevel.DEBUG -> logSettings.logLevel.level >= AstroLogLevel.DEBUG.level
        }
    }

    fun configure(
        logSetting: AstroLogSetting? = null,
        environment: AstroEnvironment,
    ) {
        this.environment = environment

        logSettings =
            if (environment.isProduction) {
                AstroLogSetting(enabled = false, verbose = false)
            } else {
                logSetting ?: AstroLogSetting(enabled = false, verbose = false)
            }
    }
}
