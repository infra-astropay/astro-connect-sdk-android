package com.astropay.connect

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.annotation.MainThread
import com.astropay.connect.core.AppContext
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.utils.BiometricManager
import com.astropay.connect.utils.ThemeManager
import com.astropay.connect.views.AstroBridgeInterface
import com.astropay.connect.views.AstroWebViewClient
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reason the preload phase ended.
 *
 * Delivered through [AstroConnect.preload]'s `onPreloadEnded` callback exactly
 * once per preload.
 */
sealed class AstroPreloadEndReason {
    /**
     * The page completed loading during preload. The next [com.astropay.connect.views.AstroConnectView]
     * presentation with the same configuration opens instantly.
     */
    object Loaded : AstroPreloadEndReason()

    /**
     * The preload phase ended before the page finished loading because the
     * flow required user interaction the SDK chose to defer (e.g. a pending
     * biometric prompt that will be shown when the SDK becomes visible) or
     * because the integrator displayed [com.astropay.connect.views.AstroConnectView] before the page
     * finished loading. The remaining work continues on the live view.
     */
    object Deferred : AstroPreloadEndReason()

    /** The preload phase ended with an error (network failure, timeout, etc.). */
    data class Failed(
        val error: AstroError,
    ) : AstroPreloadEndReason()
}

/**
 * Manages a pre-loaded SDK WebView so subsequent [com.astropay.connect.views.AstroConnectView] invocations render
 * without visible loaders.
 *
 * Call [start] as early as possible (e.g. just after the user logs in or just before
 * opening a flow). When [com.astropay.connect.views.AstroConnectView] mounts it calls [claim]: if the stored
 * session matches the current configuration the preloaded [WebView] is handed off and
 * shown immediately; otherwise a fresh WebView is created as usual.
 */
internal object AstroPreloadSession {
    data class Session(
        val webView: WebView,
        val bridge: AstroBridgeInterface,
        val matchKey: String,
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var session: Session? = null

    /**
     * Test seam: when non-null, this value is used instead of
     * `AstroConstants.Timeouts.LOAD_TIMEOUT_MS`.
     */
    internal var loadTimeoutMsOverride: Long? = null

    /**
     * Test seam: builds the [WebView] used by the preloaded session. Defaults to the
     * production implementation. Tests may replace this with a stub to avoid network
     * loads. Reset via [resetWebViewBuilder].
     */
    internal var webViewBuilder: (AstroConfiguration, String, AstroBridgeInterface) -> WebView = ::defaultBuildWebView

    internal fun resetWebViewBuilder() {
        webViewBuilder = ::defaultBuildWebView
    }

    /** Test seam exposing the stored session for assertions and event simulation. */
    internal val sessionForTesting: Session?
        get() = session

    internal val hasDeliveredResultForTesting: Boolean
        get() = hasDeliveredResult

    // Legacy callbacks (kept for backward compatibility with the deprecated overload).
    private var pendingSuccess: (() -> Unit)? = null
    private var pendingError: ((AstroError) -> Unit)? = null

    // New unified terminal callback.
    private var pendingOnPreloadEnded: ((AstroPreloadEndReason) -> Unit)? = null

    private var hasDeliveredResult: Boolean = false

    private val timeoutRunnable: Runnable =
        Runnable {
            if (hasDeliveredResult) return@Runnable
            val timeoutMs = loadTimeoutMsOverride ?: AstroConstants.Timeouts.LOAD_TIMEOUT_MS
            val error =
                AstroError(
                    ErrorCode.TIMEOUT,
                    null,
                    "Preload failed to complete within ${timeoutMs / 1000} seconds",
                )
            AstroLogger.logError(error)
            deliver(AstroPreloadEndReason.Failed(error))
        }

    // -----------------------------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    @MainThread
    fun start(
        configuration: AstroConfiguration,
        onSuccess: (() -> Unit)? = null,
        onError: ((AstroError) -> Unit)? = null,
        onPreloadEnded: ((AstroPreloadEndReason) -> Unit)? = null,
    ) {
        // Configure the biometric grace period using the integrator-supplied value so any
        // generateTOTP request that arrives during preload uses the right grace window.
        BiometricManager.configure(configuration.biometricGracePeriodMs)

        val themeParameter = ThemeManager.getThemeParameter(AppContext.get(), configuration.theme)
        val matchKey = buildMatchKey(configuration, themeParameter)

        session?.let { existing ->
            if (existing.matchKey == matchKey && existing.bridge.isLoaded) {
                AstroLogger.logDebug("AstroPreloadSession: already loaded — firing success immediately")
                onSuccess?.invoke()
                onPreloadEnded?.invoke(AstroPreloadEndReason.Loaded)
                return
            }
        }

        discard()

        val url = buildPreloadURL(configuration, themeParameter)
        if (url == null) {
            val error = AstroError(ErrorCode.INITIALIZATION_ERROR, null, "AstroPreloadSession: invalid configuration")
            onError?.invoke(error)
            onPreloadEnded?.invoke(AstroPreloadEndReason.Failed(error))
            return
        }

        pendingSuccess = onSuccess
        pendingError = onError
        pendingOnPreloadEnded = onPreloadEnded
        hasDeliveredResult = false

        val bridge = AstroBridgeInterface()
        bridge.onLoaded = {
            mainHandler.post {
                AstroLogger.logInfo("AstroPreloadSession: page loaded")
                deliver(AstroPreloadEndReason.Loaded)
            }
        }
        bridge.onError = { error ->
            mainHandler.post {
                AstroLogger.logDebug("AstroPreloadSession: page error — ${error.errorDetail}")
                deliver(AstroPreloadEndReason.Failed(error))
            }
        }

        val wv = webViewBuilder(configuration, themeParameter, bridge)

        session = Session(webView = wv, bridge = bridge, matchKey = matchKey)

        // Start the preload load timeout. If the page neither loads nor errors
        // within LOAD_TIMEOUT_MS the result is delivered as Failed(.timeout)
        // so the integrator is not left waiting forever.
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.postDelayed(timeoutRunnable, loadTimeoutMsOverride ?: AstroConstants.Timeouts.LOAD_TIMEOUT_MS)

        AstroLogger.logDebug("AstroPreloadSession: loading")
        wv.loadUrl(url, mapOf(AstroConstants.Bridge.SDK_HEADER_NAME to AstroConstants.Bridge.SDK_HEADER_VALUE))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun defaultBuildWebView(
        configuration: AstroConfiguration,
        themeParameter: String,
        bridge: AstroBridgeInterface,
    ): WebView {
        val wv = WebView(AppContext.get())
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        wv.addJavascriptInterface(bridge, AstroConstants.Bridge.OBJECT_NAME)
        wv.webViewClient =
            AstroWebViewClient(
                configuration = configuration,
                themeParameter = themeParameter,
                onPageStarted = {},
                onPageFinished = {},
                onError = { error ->
                    mainHandler.post { deliver(AstroPreloadEndReason.Failed(error)) }
                },
            )
        return wv
    }

    /**
     * Claims the preloaded session if it matches [configuration] and [themeParameter].
     * Returns `null` if there is no session or the configuration does not match (in
     * which case the existing session is discarded).
     *
     * If the preload had not yet reached a terminal state, this triggers a
     * [AstroPreloadEndReason.Deferred] result — from the preload caller's perspective
     * the preload phase ends the moment the live view takes over.
     */
    @MainThread
    fun claim(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): Session? {
        val matchKey = buildMatchKey(configuration, themeParameter)
        val existing = session ?: return null
        return if (existing.matchKey == matchKey) {
            session = null
            AstroLogger.logDebug("AstroPreloadSession: claimed (isLoaded=${existing.bridge.isLoaded})")
            if (!hasDeliveredResult) {
                deliver(AstroPreloadEndReason.Deferred)
            }
            existing
        } else {
            AstroLogger.logDebug("AstroPreloadSession: config mismatch — discarding preload")
            // Notify the original preload caller that their preload is being thrown
            // away so they are not left waiting on `onPreloadEnded` forever.
            if (!hasDeliveredResult) {
                val error = AstroError(
                    ErrorCode.INVALID_CONFIGURATION,
                    null,
                    "Preload discarded: configuration mismatch with view that claimed the session",
                )
                deliver(AstroPreloadEndReason.Failed(error))
            }
            discard()
            null
        }
    }

    /**
     * Notifies the session that a request from the web side has been deferred
     * (e.g. biometric prompt) and the page is parked waiting for the live view
     * to take over. Delivers [AstroPreloadEndReason.Deferred] if no terminal
     * result has fired yet.
     */
    @MainThread
    fun notifyDeferred() {
        if (session == null || hasDeliveredResult) return
        deliver(AstroPreloadEndReason.Deferred)
    }

    @MainThread
    fun discard() {
        mainHandler.removeCallbacks(timeoutRunnable)
        session?.webView?.apply {
            stopLoading()
            destroy()
        }
        session = null
        pendingSuccess = null
        pendingError = null
        pendingOnPreloadEnded = null
        hasDeliveredResult = false
    }

    // -----------------------------------------------------------------------------------------
    // Internal
    // -----------------------------------------------------------------------------------------

    /**
     * Delivers the terminal result exactly once. Fires both the legacy callbacks
     * (for the deprecated API surface) and the new [AstroPreloadEndReason] callback.
     *
     * For backward compatibility legacy `onSuccess` also fires on [AstroPreloadEndReason.Deferred]
     * so integrators using the deprecated overload are not left "stuck in preloading"
     * when a biometric prompt is deferred or the view is opened before the page
     * finishes loading.
     */
    private fun deliver(result: AstroPreloadEndReason) {
        if (hasDeliveredResult) return
        hasDeliveredResult = true
        mainHandler.removeCallbacks(timeoutRunnable)

        val onSuccess = pendingSuccess
        val onError = pendingError
        val onEnded = pendingOnPreloadEnded
        pendingSuccess = null
        pendingError = null
        pendingOnPreloadEnded = null

        when (result) {
            is AstroPreloadEndReason.Loaded -> onSuccess?.invoke()

            // Legacy callers only know "success/error" — surface a success so they
            // exit their preloading state. The new callback carries the more
            // accurate reason.
            is AstroPreloadEndReason.Deferred -> onSuccess?.invoke()

            is AstroPreloadEndReason.Failed -> onError?.invoke(result.error)
        }
        onEnded?.invoke(result)
    }

    /** Internal so unit tests can verify the matching contract directly. */
    internal fun buildMatchKey(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String {
        // Kotlin's default LinkedHashMap preserves insertion order, but Maps coming
        // from JSON or other sources may not. Serialise recursively with sorted keys
        // so the same logical flowParams always produces the same match string.
        val flowParamsStr = stableSerialize(configuration.flowParams)
        return listOf(
            configuration.environment.value,
            configuration.accessToken,
            configuration.language,
            themeParameter,
            configuration.appIssuer,
            configuration.clientId,
            configuration.partnerUserId,
            configuration.flow ?: "",
            flowParamsStr,
            configuration.phoneCode ?: "",
            configuration.phoneNumber ?: "",
            "${configuration.embedded}",
        ).joinToString("|")
    }

    /** Recursively serialises a value with sorted keys for any nested Map. */
    private fun stableSerialize(value: Any?): String =
        when (value) {
            null -> ""
            is Map<*, *> -> {
                val obj = JSONObject()
                value.entries
                    .map { it.key.toString() to it.value }
                    .sortedBy { it.first }
                    .forEach { (k, v) -> obj.put(k, toJsonCompatible(v)) }
                obj.toString()
            }
            is List<*> -> JSONArray(value.map { toJsonCompatible(it) }).toString()
            else -> value.toString()
        }

    private fun toJsonCompatible(value: Any?): Any =
        when (value) {
            null -> JSONObject.NULL
            is Map<*, *> -> {
                val obj = JSONObject()
                value.entries
                    .map { it.key.toString() to it.value }
                    .sortedBy { it.first }
                    .forEach { (k, v) -> obj.put(k, toJsonCompatible(v)) }
                obj
            }
            is List<*> -> JSONArray(value.map { toJsonCompatible(it) })
            else -> value
        }

    private fun buildPreloadURL(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String? {
        val baseURL = configuration.environment.getBaseURL(configuration.localIP) ?: return null
        return Uri
            .parse(baseURL)
            .buildUpon()
            .appendQueryParameter(AstroConstants.QueryParams.THEME, themeParameter)
            .appendQueryParameter(AstroConstants.QueryParams.ACCESS_TOKEN, configuration.accessToken)
            .appendQueryParameter(AstroConstants.QueryParams.LANGUAGE, configuration.language)
            .build()
            .toString()
    }
}
