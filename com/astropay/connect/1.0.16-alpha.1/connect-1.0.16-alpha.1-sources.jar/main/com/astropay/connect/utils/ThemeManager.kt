package com.astropay.connect.utils

import android.content.Context
import android.content.res.Configuration
import com.astropay.connect.core.AstroTheme

/**
 * Utility class for managing theme detection and resolution.
 */
internal object ThemeManager {

    /**
     * Resolves the theme to a parameter string for the WebView.
     *
     * @param context The Android context.
     * @param theme The configured theme option.
     * @return The theme parameter string ("light" or "dark").
     */
    fun getThemeParameter(context: Context, theme: AstroTheme?): String {
        return when (theme) {
            AstroTheme.LIGHT -> "light"
            AstroTheme.DARK -> "dark"
            AstroTheme.SYSTEM, null -> getSystemTheme(context)
        }
    }

    /**
     * Detects the current system theme.
     *
     * @param context The Android context.
     * @return "dark" if the system is in dark mode, "light" otherwise.
     */
    fun getSystemTheme(context: Context): String {
        val nightModeFlags = context.resources.configuration.uiMode and
                Configuration.UI_MODE_NIGHT_MASK

        return when (nightModeFlags) {
            Configuration.UI_MODE_NIGHT_YES -> "dark"
            Configuration.UI_MODE_NIGHT_NO -> "light"
            else -> "light"
        }
    }

    /**
     * Checks if the system is currently in dark mode.
     *
     * @param context The Android context.
     * @return true if in dark mode, false otherwise.
     */
    fun isSystemDarkMode(context: Context): Boolean {
        return getSystemTheme(context) == "dark"
    }
}
