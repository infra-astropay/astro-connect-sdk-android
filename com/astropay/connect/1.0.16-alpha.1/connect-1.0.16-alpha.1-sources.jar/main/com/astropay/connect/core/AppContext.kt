package com.astropay.connect.core

import android.content.Context

internal object AppContext {
    private lateinit var context: Context

    fun init(context: Context) {
        this.context = context.applicationContext
    }

    fun get(): Context = context
}
