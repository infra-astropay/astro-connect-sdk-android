package com.astropay.connect.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri

/**
 * Utility class for network-related operations.
 */
internal object NetworkUtils {

    /**
     * Validates if a URL has a valid scheme and host.
     *
     * @param url The URL string to validate.
     * @return true if the URL is valid, false otherwise.
     */
    fun isValidURL(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            val scheme = uri.scheme?.lowercase()
            val host = uri.host

            // Validate scheme
            if (scheme != "http" && scheme != "https") {
                return false
            }

            // Validate host
            !host.isNullOrBlank()
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Checks if the URL uses HTTPS.
     *
     * @param url The URL string to check.
     * @return true if the URL uses HTTPS, false otherwise.
     */
    fun isSecureURL(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            uri.scheme?.lowercase() == "https"
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Checks if the device has an active network connection.
     *
     * @param context The Android context.
     * @return true if connected to a network, false otherwise.
     */
    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false

        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /**
     * Extracts the host from a URL.
     *
     * @param url The URL string.
     * @return The host, or null if extraction fails.
     */
    fun getHost(url: String): String? {
        return try {
            Uri.parse(url).host
        } catch (e: Exception) {
            null
        }
    }
}
