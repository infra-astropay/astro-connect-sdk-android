package com.astropay.connect.core

/**
 * Configuration class for AstroPay Connect SDK.
 * Contains all the parameters needed to initialize and configure the SDK.
 */
class AstroConfiguration(
    environment: String,
    val appIssuer: String,
    val clientId: String,
    val partnerUserId: String,
    val phoneCode: String? = null,
    val phoneNumber: String? = null,
    val accessToken: String,
    val theme: AstroTheme = AstroTheme.SYSTEM,
    val language: String = "en",
    val flow: String? = null,
    val flowParams: Map<String, Any>? = null,
    val showHeader: Boolean? = true,
    val showHeaderLogo: Boolean? = true,
    val embedded: Boolean = true,
    val biometricGracePeriod: Long? = null,
    val style: AstroStyle? = null,
    /**
     * Free-form style overrides forwarded to the web alongside [style].
     *
     * Acts as an escape hatch for tokens that are not yet exposed on the
     * typed [AstroStyle]. The SDK does not merge or interpret these values:
     * they are sent as a separate `styleOverrides` field on the bridge and
     * the web side is responsible for applying them (snake/camel mapping,
     * placement, and precedence — overrides win over the typed style).
     *
     * Keys are not validated; leaf String values must be valid 6- or 8-digit hex (#RRGGBB or #RRGGBBAA).
     * Nested maps and non-string values (numbers, booleans) are allowed.
     */
    val styleOverrides: Map<String, Any>? = null,
    val logSetting: AstroLogSetting = AstroLogSetting(enabled = false),
    val localIP: String? = null,
) {
    /**
     * Biometric grace period in milliseconds (converted from seconds input).
     * Used internally by BiometricManager.
     * Default: 120s (2 minutes). Range: 0 to 600s (10 minutes).
     */
    val biometricGracePeriodMs: Long = ((biometricGracePeriod ?: AstroConstants.BiometricGracePeriod.DEFAULT_SECONDS)
        .coerceIn(AstroConstants.BiometricGracePeriod.MIN_SECONDS, AstroConstants.BiometricGracePeriod.MAX_SECONDS)) * 1000L

    /**
     * Internal environment enum for SDK use.
     */
    internal val environment: AstroEnvironment = AstroEnvironment.fromString(environment)

    /**
     * Resolves header visibility, defaulting to true when not set.
     */
    internal val effectiveShowHeader: Boolean
        get() = showHeader ?: true

    /**
     * Returns the S3 base URL for issuer logos based on environment.
     */
    internal val issuerLogoBaseUrl: String
        get() = when (environment) {
            AstroEnvironment.PRODUCTION, AstroEnvironment.SANDBOX -> AstroConstants.Assets.ISSUER_LOGO_BASE_PROD
            else -> AstroConstants.Assets.ISSUER_LOGO_BASE_TESTING
        }

    /**
     * Validates the configuration and throws an exception if invalid.
     */
    @Throws(AstroConfigurationException::class)
    fun validate() {
        if (appIssuer.isBlank()) {
            throw AstroConfigurationException("appIssuer is required")
        }
        if (clientId.isBlank()) {
            throw AstroConfigurationException("clientId is required")
        }
        if (partnerUserId.isBlank()) {
            throw AstroConfigurationException("partnerUserId is required")
        }

        if (environment.isUnknown) {
            throw AstroConfigurationException("Environment is not supported")
        }
        if (environment.isLocal && localIP.isNullOrBlank()) {
            throw AstroConfigurationException("localIP is required for local environment")
        }
        if (biometricGracePeriod != null &&
            biometricGracePeriod !in AstroConstants.BiometricGracePeriod.MIN_SECONDS..AstroConstants.BiometricGracePeriod.MAX_SECONDS
        ) {
            throw AstroConfigurationException(
                "biometricGracePeriod must be between ${AstroConstants.BiometricGracePeriod.MIN_SECONDS} and ${AstroConstants.BiometricGracePeriod.MAX_SECONDS} seconds"
            )
        }

        style?.validate()
        validateStyleOverrides(styleOverrides)
    }

    /**
     * Builder class for creating AstroConfiguration instances.
     */
    class Builder {
        private var environment: String = "sandbox"
        private var appIssuer: String = ""
        private var clientId: String = ""
        private var partnerUserId: String = ""
        private var phoneCode: String? = null
        private var phoneNumber: String? = null
        private var accessToken: String = ""
        private var theme: AstroTheme = AstroTheme.SYSTEM
        private var language: String = "en"
        private var flow: String? = null
        private var flowParams: Map<String, Any>? = null
        private var showHeader: Boolean? = true
        private var showHeaderLogo: Boolean? = true
        private var embedded: Boolean = true
        private var biometricGracePeriod: Long? = null
        private var style: AstroStyle? = null
        private var styleOverrides: Map<String, Any>? = null
        private var logSetting: AstroLogSetting = AstroLogSetting(enabled = false)
        private var localIP: String? = null

        fun setEnvironment(environment: String): Builder {
            this.environment = environment
            return this
        }

        fun setAppIssuer(appIssuer: String): Builder {
            this.appIssuer = appIssuer
            return this
        }

        fun setClientId(clientId: String): Builder {
            this.clientId = clientId
            return this
        }

        fun setPartnerUserId(partnerUserId: String): Builder {
            this.partnerUserId = partnerUserId
            return this
        }

        fun setPhoneCode(phoneCode: String?): Builder {
            this.phoneCode = phoneCode
            return this
        }

        fun setPhoneNumber(phoneNumber: String?): Builder {
            this.phoneNumber = phoneNumber
            return this
        }

        fun setAccessToken(accessToken: String): Builder {
            this.accessToken = accessToken
            return this
        }

        fun setTheme(theme: AstroTheme): Builder {
            this.theme = theme
            return this
        }

        fun setLanguage(language: String): Builder {
            this.language = language
            return this
        }

        fun setFlow(flow: String?): Builder {
            this.flow = flow
            return this
        }

        fun setFlowParams(flowParams: Map<String, Any>?): Builder {
            this.flowParams = flowParams
            return this
        }

        fun setEmbedded(embedded: Boolean): Builder {
            this.embedded = embedded
            return this
        }

        fun setBiometricGracePeriod(biometricGracePeriod: Long?): Builder {
            this.biometricGracePeriod = biometricGracePeriod
            return this
        }

        fun setLogSetting(logSetting: AstroLogSetting): Builder {
            this.logSetting = logSetting
            return this
        }

        fun setLocalIP(localIP: String?): Builder {
            this.localIP = localIP
            return this
        }

        fun setShowHeader(showHeader: Boolean?): Builder {
            this.showHeader = showHeader
            return this
        }

        fun setShowHeaderLogo(showHeaderLogo: Boolean?): Builder {
            this.showHeaderLogo = showHeaderLogo
            return this
        }

        fun setStyle(style: AstroStyle?): Builder {
            this.style = style
            return this
        }

        fun setStyleOverrides(styleOverrides: Map<String, Any>?): Builder {
            this.styleOverrides = styleOverrides
            return this
        }

        /**
         * Builds the configuration without validation.
         * Validation is performed internally by the SDK when starting.
         */
        fun build(): AstroConfiguration =
            AstroConfiguration(
                environment = environment,
                appIssuer = appIssuer,
                clientId = clientId,
                partnerUserId = partnerUserId,
                phoneCode = phoneCode,
                phoneNumber = phoneNumber,
                accessToken = accessToken,
                theme = theme,
                language = language,
                flow = flow,
                flowParams = flowParams,
                showHeader = showHeader,
                showHeaderLogo = showHeaderLogo,
                embedded = embedded,
                biometricGracePeriod = biometricGracePeriod,
                style = style,
                styleOverrides = styleOverrides,
                logSetting = logSetting,
                localIP = localIP,
            )
    }

    companion object {
        /**
         * Creates a new Builder instance.
         */
        fun builder(): Builder = Builder()
    }

    override fun toString(): String {
        val result =
            """
            AstroConfiguration(
              environment: $environment,
              appIssuer: $appIssuer,
              clientId: $clientId,
              partnerUserId: $partnerUserId,
              phoneCode: $phoneCode,
              phoneNumber: $phoneNumber,
              accessToken: ${if (accessToken.isBlank()) "nil" else "****"},
              theme: $theme,
              language: $language,
              flow: $flow,
              flowParams: $flowParams,
              showHeader: $showHeader,
              showHeaderLogo: $showHeaderLogo,
              embedded: $embedded,
            """.trimIndent()

        return if (environment.isLocal) {
            "$result\n  localIP: $localIP\n)"
        } else {
            "$result\n)"
        }
    }
}

/**
 * Exception thrown when configuration validation fails.
 */
class AstroConfigurationException(
    message: String,
) : Exception(message)
