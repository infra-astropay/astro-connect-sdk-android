package com.astropay.connect.core

/**
 * Error codes for AstroPay Connect SDK.
 */
enum class ErrorCode(
    val rawValue: String,
) {
    INITIALIZATION_ERROR("INITIALIZATION_ERROR"),
    INVALID_CONFIGURATION("INVALID_CONFIG"),
    NETWORK_ERROR("NETWORK_ERROR"),
    BRIDGE_ERROR("BRIDGE_ERROR"),
    TIMEOUT("TIMEOUT"),
    CAMERA_PERMISSION("CAMERA_PERMISSION"),
    ;

    val numericCode: String
        get() =
            when (this) {
                INITIALIZATION_ERROR -> "1001"
                INVALID_CONFIGURATION -> "1002"
                NETWORK_ERROR -> "1003"
                BRIDGE_ERROR -> "1004"
                TIMEOUT -> "1005"
                CAMERA_PERMISSION -> "1006"
            }
}

/**
 * Represents an error from the AstroPay Connect SDK.
 */
class AstroError(
    private val code: ErrorCode,
    private val subCode: String? = null,
    private val msg: String? = null,
) : Exception(msg ?: code.rawValue) {
    val errorDescription: String?
        get() {
            if (msg != null) {
                return msg
            }
            if (subCode != null) {
                return "${code.numericCode}-$subCode"
            }
            return code.rawValue
        }

    val errorMessage: String
        get() =
            if (msg != null) {
                msg
            } else {
                "[${code.numericCode}${if (subCode != null) "-$subCode]" else "]"}"
            }

    val errorDetail: String
        get() = "[${code.numericCode}${if (subCode != null) "-$subCode]" else "]"} ${msg ?: "No additional information"}"

    val errorCode: String
        get() = code.numericCode

    val errorSubCode: String?
        get() = subCode
}
