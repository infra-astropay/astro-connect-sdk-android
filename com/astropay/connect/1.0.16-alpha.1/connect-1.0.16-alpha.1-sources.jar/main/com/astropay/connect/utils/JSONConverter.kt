package com.astropay.connect.utils

import org.json.JSONArray
import org.json.JSONObject

/**
 * Utility class for JSON serialization operations.
 */
internal object JSONConverter {
    /**
     * Converts a Map to a JSON string.
     *
     * @param map The map to convert.
     * @return The JSON string representation.
     */
    fun mapToJsonString(map: Map<String, Any>?): String {
        if (map == null) return "{}"
        return mapToJsonObject(map).toString()
    }

    /**
     * Converts a Map to a JSONObject.
     *
     * @param map The map to convert.
     * @return The JSONObject.
     */
    fun mapToJsonObject(map: Map<String, Any>): JSONObject {
        val jsonObject = JSONObject()

        map.forEach { (key, value) ->
            jsonObject.put(key, convertValue(value))
        }

        return jsonObject
    }

    /**
     * Converts a value to its JSON-compatible representation.
     */
    private fun convertValue(value: Any): Any =
        when (value) {
            is Map<*, *> -> {
                @Suppress("UNCHECKED_CAST")
                mapToJsonObject(value as Map<String, Any>)
            }

            is List<*> -> {
                val jsonArray = JSONArray()
                value.forEach { item ->
                    if (item != null) {
                        jsonArray.put(convertValue(item))
                    }
                }
                jsonArray
            }

            is Array<*> -> {
                val jsonArray = JSONArray()
                value.forEach { item ->
                    if (item != null) {
                        jsonArray.put(convertValue(item))
                    }
                }
                jsonArray
            }

            else -> {
                value
            }
        }

    /**
     * Parses a JSON string to a Map.
     * Handles escaped JSON strings that may come from JavaScript JSON.stringify().
     *
     * @param jsonString The JSON string to parse.
     * @return The Map representation, or null if parsing fails.
     */
    fun jsonStringToMap(jsonString: String): Map<String, Any>? =
        try {
            val cleanedJson = cleanJsonString(jsonString)
            val jsonObject = JSONObject(cleanedJson)
            jsonObjectToMap(jsonObject)
        } catch (e: Exception) {
            null
        }

    /**
     * Cleans a JSON string that may have been double-escaped or wrapped in quotes.
     * This handles cases where JavaScript JSON.stringify() produces escaped strings.
     *
     * @param jsonString The potentially escaped JSON string.
     * @return The cleaned JSON string ready for parsing.
     */
    private fun cleanJsonString(jsonString: String): String {
        var result = jsonString.trim()

        // If string is wrapped in quotes and contains escaped quotes, it's double-stringified
        if (result.startsWith("\"") && result.endsWith("\"") && result.contains("\\\"")) {
            // Remove outer quotes
            result = result.substring(1, result.length - 1)
            // Unescape inner quotes
            result = result.replace("\\\"", "\"")
            // Unescape backslashes
            result = result.replace("\\\\", "\\")
        }

        return result
    }

    /**
     * Converts a JSONObject to a Map.
     *
     * @param jsonObject The JSONObject to convert.
     * @return The Map representation.
     */
    fun jsonObjectToMap(jsonObject: JSONObject): Map<String, Any> {
        val map = mutableMapOf<String, Any>()

        jsonObject.keys().forEach { key ->
            val value = jsonObject.get(key)
            map[key] = convertJsonValue(value)
        }

        return map
    }

    /**
     * Converts a JSON value to its Kotlin representation.
     */
    private fun convertJsonValue(value: Any): Any =
        when (value) {
            is JSONObject -> {
                jsonObjectToMap(value)
            }

            is JSONArray -> {
                val list = mutableListOf<Any>()
                for (i in 0 until value.length()) {
                    list.add(convertJsonValue(value.get(i)))
                }
                list
            }

            JSONObject.NULL -> {
                ""
            }

            else -> {
                value
            }
        }
}
