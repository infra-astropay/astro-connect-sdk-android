package com.astropay.connect.views

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import com.astropay.connect.AstroPreloadSession
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroEvent
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.utils.JSONConverter
import org.json.JSONObject

/**
 * JavaScript interface for AstroPay Connect bridge.
 * Provides native methods that can be called from JavaScript.
 *
 * Note: @JavascriptInterface methods run on a background thread and cannot
 * return values synchronously to JavaScript. All results must be sent via
 * evaluateJavascript callbacks.
 *
 * Callbacks are @Volatile mutable properties so they can be updated when the
 * view remounts without re-registering the JS interface (which only takes
 * effect on the next page load).
 */
internal class AstroBridgeInterface {

    @Volatile var onLoaded: () -> Unit = {}
    @Volatile var onClose: (code: String, message: String) -> Unit = { _, _ -> }
    @Volatile var onError: (AstroError) -> Unit = {}
    @Volatile var onEvent: (AstroEvent) -> Unit = {}
    @Volatile var onCheckCameraPermission: () -> Unit = {}
    @Volatile var onRequestCameraPermission: () -> Unit = {}
    @Volatile var onCheckBiometricAvailability: () -> Unit = {}
    @Volatile var onDeleteSeed: () -> Unit = {}
    @Volatile var onGetSeed: () -> Unit = {}
    @Volatile var onRegisterDevice: (String) -> Unit = { _ -> }
    @Volatile var onGenerateTOTP: () -> Unit = {}
    @Volatile var onStartNativeKyc: (provider: String, token: String, userId: String, docTypes: List<String>) -> Unit = { _, _, _, _ -> }

    @Volatile private var hasNotifiedLoaded = false

    private val pendingTOTPLock = Any()

    /**
     * True once this bridge is attached to a visible AstroConnectView. While false
     * (preload mode) a generateTOTP call that would trigger a biometric prompt is
     * queued instead of dispatched, so the user is never prompted before the SDK
     * is on screen. Guarded by [pendingTOTPLock] so the visibility check and the
     * enqueue/flush are mutually exclusive.
     */
    private var isVisible: Boolean = false
    private var pendingTOTPCount = 0
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Test seam exposing the current queue size for assertions. */
    internal val pendingTOTPCountForTesting: Int
        get() = synchronized(pendingTOTPLock) { pendingTOTPCount }

    /** Test seam exposing the current visibility flag for assertions. */
    internal val isVisibleForTesting: Boolean
        get() = synchronized(pendingTOTPLock) { isVisible }

    val isLoaded: Boolean get() = hasNotifiedLoaded

    fun resetLoadState() {
        hasNotifiedLoaded = false
        synchronized(pendingTOTPLock) {
            isVisible = false
            pendingTOTPCount = 0
        }
    }

    /**
     * Marks the bridge as visible and dispatches any generateTOTP requests that
     * were deferred while !isVisible. The visibility transition and the drain
     * happen under the same lock so any concurrent generateTOTP either sees
     * isVisible=true and dispatches directly, or enqueues before the drain and
     * gets flushed here.
     */
    fun markVisibleAndFlush() {
        val count = synchronized(pendingTOTPLock) {
            isVisible = true
            val c = pendingTOTPCount
            pendingTOTPCount = 0
            c
        }
        repeat(count) { onGenerateTOTP() }
    }

    /**
     * Called when the SDK page has finished loading.
     * Uses a flag to ensure this is only processed once, since the bridge
     * may be injected multiple times (onPageStarted and onPageFinished).
     */
    @JavascriptInterface
    fun notifyLoaded() {
        if (hasNotifiedLoaded) {
            return
        }
        hasNotifiedLoaded = true
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.NOTIFY_LOADED}")
        onLoaded()
    }

    /**
     * Called when the embedded web app requests close. This is the ONLY
     * `notifyClose` method exposed to JavaScript — additional overloads MUST
     * NOT be added. Android's `@JavascriptInterface` dispatch is reflection-
     * based and unreliable when multiple methods share the same name: a JS
     * call with arguments can silently route to a zero-arg Java overload
     * (and vice versa), producing wrong values without any error.
     *
     * The bridge contract requires the web bundle to always pass two
     * strings. The defensive sanitiser only handles the empty-`code` case,
     * which falls back to `code = "UNKNOWN"`; `message` is forwarded as-is.
     *
     * The matching JS wrapper in `AstroBridgeManager` must forward the same
     * two arguments to `nativeInterface.notifyClose(code, message)` — editing
     * one side without the other re-introduces the silent-no-op bug where
     * arity mismatch makes the WebView reject the call as "Method not found".
     */
    @JavascriptInterface
    fun notifyClose(code: String, message: String) {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.NOTIFY_CLOSE}")
        val safeCode = if (code.isEmpty()) "UNKNOWN" else code
        onClose(safeCode, message)
    }

    /**
     * Called when an error occurs in the SDK.
     */
    @JavascriptInterface
    fun notifyError(
        code: String,
        error: String,
        severity: String,
    ) {
        val astroError = AstroError(ErrorCode.BRIDGE_ERROR, code, error)
        AstroLogger.logError(astroError)
        onError(astroError)
    }

    /**
     * Called when an analytics event is received from the SDK.
     */
    @JavascriptInterface
    fun notifyEvent(eventJson: String) {
        try {
            val event = parseEventJson(eventJson)
            onEvent(event)
        } catch (e: Exception) {
            val error = AstroError(ErrorCode.BRIDGE_ERROR, "01", "Failed to parse event: ${e.message}")
            AstroLogger.logError(error)
        }
    }

    private fun parseEventJson(json: String): AstroEvent {
        val eventMap =
            JSONConverter.jsonStringToMap(json)
                ?: throw IllegalArgumentException("Invalid JSON: $json")

        @Suppress("UNCHECKED_CAST")
        return AstroEvent(
            screenName = eventMap["screenName"] as? String ?: "",
            eventName = eventMap["eventName"] as? String ?: "",
            eventCategory = eventMap["eventCategory"] as? String ?: "",
            eventProperties = eventMap["eventProperties"] as? Map<String, Any>,
            sessionId = eventMap["sessionId"] as? String ?: "",
            appVersion = eventMap["appVersion"] as? String ?: "",
            platform = eventMap["platform"] as? String ?: "",
        )
    }

    /**
     * Checks if camera permission is granted.
     * The result is sent via cameraPermissionCallback using evaluateJavascript.
     */
    @JavascriptInterface
    fun hasCameraPermission() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.HAS_CAMERA_PERMISSION}")
        onCheckCameraPermission()
    }

    /**
     * Requests camera permission from the user.
     * The result is sent via cameraPermissionCallback.
     */
    @JavascriptInterface
    fun requestCameraPermissions() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.REQUEST_CAMERA_PERMISSIONS}")
        onRequestCameraPermission()
    }

    /**
     * Checks if biometric authentication is available on the device.
     * The result is sent via checkBiometricResultCallback.
     */
    @JavascriptInterface
    fun checkBiometricAvailability() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.CHECK_BIOMETRIC_AVAILABILITY}")
        onCheckBiometricAvailability()
    }

    /**
     * Deletes the stored TOTP seed from the device.
     * The result is sent via deleteSeedResultCallback.
     */
    @JavascriptInterface
    fun deleteSeed() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.DELETE_SEED}")
        onDeleteSeed()
    }

    /**
     * Retrieves the stored TOTP seed from the device.
     * The result is sent via getSeedResultCallback.
     */
    @JavascriptInterface
    fun getSeed() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.GET_SEED}")
        onGetSeed()
    }

    /**
     * Registers the device for biometric 2FA.
     * Stores the provided TOTP seed securely with biometric protection.
     * The result is sent via registerDeviceResultCallback.
     */
    @JavascriptInterface
    fun registerDevice(seed: String) {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.REGISTER_DEVICE}")
        onRegisterDevice(seed)
    }

    /**
     * Starts the native CAF KYC flow.
     * The body is a JSON string: {"provider":"CAF","token":"...","userId":"...","docTypes":["CNH",...]}
     * The result is delivered via nativeKycResultCallback using evaluateJavascript.
     */
    @JavascriptInterface
    fun startNativeKyc(body: String) {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.START_NATIVE_KYC}")
        try {
            val json = JSONObject(body)
            val provider = json.optString("provider")
            val token = json.optString("token")
            val userId = json.optString("userId")
            val docTypesArr = json.optJSONArray("docTypes")
            val docTypes = if (docTypesArr != null) {
                (0 until docTypesArr.length()).map { docTypesArr.getString(it) }
            } else {
                emptyList()
            }
            onStartNativeKyc(provider, token, userId, docTypes)
        } catch (e: Exception) {
            AstroLogger.logDebug("Bridge: startNativeKyc — failed to parse body: ${e.message}")
            onStartNativeKyc("", "", "", emptyList())
        }
    }

    /**
     * Generates a TOTP code using the stored seed.
     * Requires biometric authentication to access the stored seed.
     * The result is sent via generateTOTPResultCallback.
     */
    @JavascriptInterface
    fun generateTOTP() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.GENERATE_TOTP}")
        // When the bridge is not visible (preload phase) it has no wired handler to
        // produce a TOTP result, so any generateTOTP call is queued and processed
        // by the live view once it claims the session — regardless of whether a
        // biometric prompt would have appeared.
        val dispatchNow = synchronized(pendingTOTPLock) {
            if (isVisible) {
                true
            } else {
                pendingTOTPCount++
                false
            }
        }
        if (dispatchNow) {
            onGenerateTOTP()
        } else {
            AstroLogger.logDebug("Deferring generateTOTP until SDK is visible")
            // The preload has reached its terminal state: the page is parked waiting
            // for the live view to take over. Notify the preload session so it can
            // deliver `Deferred` to the integrator. We do NOT mark the bridge as
            // loaded — the page is not actually rendered yet and the loader must
            // stay visible until the real notifyLoaded after the view processes
            // the deferred request.
            mainHandler.post { AstroPreloadSession.notifyDeferred() }
        }
    }
}
