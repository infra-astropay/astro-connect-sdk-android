package com.astropay.connect.core

/**
 * Represents the theme options for AstroPay Connect SDK.
 */
enum class AstroTheme(val value: String) {
    LIGHT("light"),
    DARK("dark"),
    SYSTEM("system");

    companion object {
        /**
         * Creates an AstroTheme from a string value.
         */
        fun fromString(value: String): AstroTheme {
            return entries.find { it.value.equals(value, ignoreCase = true) } ?: SYSTEM
        }
    }
}
