package com.astropay.connect.utils

import com.astropay.connect.core.AstroStyle
import com.astropay.connect.core.isValidHexColor
import com.astropay.connect.core.resolveNativeBackgroundColor
import com.astropay.connect.core.resolveNativeContentColor
import com.astropay.connect.core.resolveNativeHeaderBackgroundColor
import com.astropay.connect.core.resolveNativeHeaderBorderColor
import com.astropay.connect.core.resolveNativeMediumColor
import com.astropay.connect.core.resolveNativePrimaryColor
import com.astropay.connect.core.resolveNativeSecondaryColor
import com.astropay.connect.core.toAstroHex

/**
 * Resolves the integrator's configured colors ([AstroStyle] + `styleOverrides`) into the seven
 * CAF-ready [NativeKycColors] slots. The five always-set slots apply the same per-slot fallback to
 * today's hardcoded light/dark palette so a partner who sets no colors gets pixel-identical native
 * KYC colors to the previous behavior; the two nullable slots are pass-through (no SDK fallback).
 *
 * Pure and CAF-free: it lives in `src/main` (compiled by every flavor), reads only the SDK style
 * model, and emits primitive `#RRGGBB` strings. The CAF layer never sees the resolvers or the style
 * model — it receives the resolved [NativeKycColors].
 *
 * Slot mapping (see the design's canonical color table):
 * - `primaryColor`   ← [resolveNativePrimaryColor], fallback `#00D4AA` (both themes).
 * - `backgroundColor`← [resolveNativeBackgroundColor], fallback `#FFFFFF` light / `#1A1A1A` dark.
 * - `contentColor`   ← [resolveNativeContentColor] (`style.text.base`), else legible fallback
 *   `#1A1A1A` light / `#FFFFFF` dark (non-null; safety-critical text).
 * - `dialogBackgroundColor` ← [resolveNativeHeaderBackgroundColor], fallback `#F5F5F5` light /
 *   `#2A2A2A` dark.
 * - `dialogBorderColor`     ← [resolveNativeHeaderBorderColor], fallback `#F5F5F5` light /
 *   `#2A2A2A` dark.
 * - `secondaryColor` ← [resolveNativeSecondaryColor] (`style.buttons.colors.primaryText`),
 *   NULLABLE pass-through (no fallback → CAF default when unset).
 * - `mediumColor`    ← [resolveNativeMediumColor] (`style.border.base`), NULLABLE pass-through
 *   (no fallback → CAF default when unset).
 */
internal object NativeKycColorResolver {

    // Per-slot fallbacks: the exact hardcoded values in use before this change, keyed by theme.
    private const val FALLBACK_PRIMARY = "#00D4AA"
    private const val FALLBACK_BACKGROUND_LIGHT = "#FFFFFF"
    private const val FALLBACK_BACKGROUND_DARK = "#1A1A1A"
    private const val FALLBACK_CONTENT_LIGHT = "#1A1A1A"
    private const val FALLBACK_CONTENT_DARK = "#FFFFFF"
    private const val FALLBACK_DIALOG_LIGHT = "#F5F5F5"
    private const val FALLBACK_DIALOG_DARK = "#2A2A2A"

    /**
     * Builds the resolved [NativeKycColors] for the given [style] / [styleOverrides] and resolved
     * [theme] string ("dark" selects the dark fallbacks; any other value uses light).
     */
    fun resolve(
        style: AstroStyle?,
        styleOverrides: Map<String, Any>?,
        theme: String,
    ): NativeKycColors {
        val dark = theme == "dark"
        val backgroundFallback = if (dark) FALLBACK_BACKGROUND_DARK else FALLBACK_BACKGROUND_LIGHT
        val contentFallback = if (dark) FALLBACK_CONTENT_DARK else FALLBACK_CONTENT_LIGHT
        val dialogFallback = if (dark) FALLBACK_DIALOG_DARK else FALLBACK_DIALOG_LIGHT

        val primary = resolveNativePrimaryColor(style, styleOverrides)
            .toCafHexOr(FALLBACK_PRIMARY)
        val background = resolveNativeBackgroundColor(style, styleOverrides)
            .toCafHexOr(backgroundFallback)
        // contentColor now resolves from `style.text.base` (else legible fallback — safety-critical
        // text stays legible for no-style partners).
        val content = resolveNativeContentColor(style, styleOverrides)
            .toCafHexOr(contentFallback)
        val dialogBackground = resolveNativeHeaderBackgroundColor(style, styleOverrides)
            .toCafHexOr(dialogFallback)
        val dialogBorder = resolveNativeHeaderBorderColor(style, styleOverrides)
            .toCafHexOr(dialogFallback)
        // secondaryColor / mediumColor are NULLABLE pass-through: no SDK fallback, so when no token
        // resolves the field stays null and the mapper omits the CAF slot (→ CAF's own default).
        val secondary = resolveNativeSecondaryColor(style, styleOverrides)
            .toCafHexOrNull()
        val medium = resolveNativeMediumColor(style, styleOverrides)
            .toCafHexOrNull()

        return NativeKycColors(
            primaryColor = primary,
            backgroundColor = background,
            contentColor = content,
            dialogBackgroundColor = dialogBackground,
            dialogBorderColor = dialogBorder,
            secondaryColor = secondary,
            mediumColor = medium,
        )
    }

    /**
     * Encodes a resolved `@ColorInt` (or null) to a CAF-ready `#RRGGBB` string, falling back to
     * [fallback] when the color is unset or the encoded value is malformed.
     */
    private fun Int?.toCafHexOr(fallback: String): String =
        this?.toAstroHex()?.let { cafHex(it, fallback) } ?: fallback

    /**
     * Nullable sibling of [toCafHexOr] for the pass-through slots ([NativeKycColors.secondaryColor]
     * / [NativeKycColors.mediumColor]) that own no fallback. Encodes a resolved `@ColorInt` to a
     * CAF-ready `#RRGGBB` string, returning `null` when the color is unset or (defensively) the
     * encoded value is malformed — NEVER a fallback and NEVER `""` (CAF degrades a blank slot to
     * black; the mapper must leave the CAF param truly unset so CAF keeps its own default).
     *
     * A `@ColorInt` produced by the resolver from a Compose `Color` / raw `Int` is always
     * well-formed, so in practice this yields a non-null `#RRGGBB` whenever a token resolved and
     * `null` only when nothing did.
     */
    private fun Int?.toCafHexOrNull(): String? {
        val hex = this?.toAstroHex()?.trim() ?: return null
        val sixDigit = when (hex.length) {
            9 -> hex.substring(0, 7) // "#RRGGBBAA" → "#RRGGBB"
            7 -> hex
            else -> return null
        }
        return if (isValidHexColor(sixDigit)) sixDigit else null
    }

    /**
     * Normalizes an SDK hex string to a CAF-ready opaque `#RRGGBB` value.
     *
     * CAF's `CafColorConfiguration` slots take 6-digit hex; its parser is not guaranteed to accept
     * 8-digit `#RRGGBBAA`, and alpha is meaningless over an opaque camera preview. This strips a
     * trailing alpha byte (`#RRGGBBAA` → `#RRGGBB`) so a partly-transparent partner color is
     * composited as its opaque RGB, and degrades any malformed input to [fallback] rather than
     * handing CAF a value it might reject. It is a defensive last-mile normalizer, not a validator —
     * partner hex is already validated at `AstroConfiguration.validate()`.
     */
    internal fun cafHex(hex: String, fallback: String): String {
        val trimmed = hex.trim()
        val sixDigit = when (trimmed.length) {
            9 -> trimmed.substring(0, 7) // "#RRGGBBAA" → "#RRGGBB"
            7 -> trimmed
            else -> return fallback
        }
        // `isValidHexColor` (single source of truth) accepts 6- or 8-digit hex with an optional
        // leading '#'. `sixDigit` is always a 7-char `#RRGGBB` value here, so the behavior is
        // identical to the previous local `#RRGGBB`-only check.
        return if (isValidHexColor(sixDigit)) sixDigit else fallback
    }
}
