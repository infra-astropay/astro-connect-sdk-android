package com.astropay.connect.utils

internal fun sanitizeForJs(value: String): String =
    value.trim()
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", "")
        .replace("\r", "")
        .replace("\u2028", "")
        .replace("\u2029", "")
