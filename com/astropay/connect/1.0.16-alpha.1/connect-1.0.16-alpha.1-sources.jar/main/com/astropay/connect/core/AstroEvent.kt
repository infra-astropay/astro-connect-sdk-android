package com.astropay.connect.core

/**
 * Represents an analytics event received from the web bridge.
 */
data class AstroEvent(
    val screenName: String,
    val eventName: String,
    val eventCategory: String,
    val eventProperties: Map<String, Any>?,
    val sessionId: String,
    val appVersion: String,
    val platform: String,
)
