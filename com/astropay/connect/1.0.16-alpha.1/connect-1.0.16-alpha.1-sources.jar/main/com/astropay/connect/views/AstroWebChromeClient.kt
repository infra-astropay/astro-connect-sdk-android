package com.astropay.connect.views

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Message
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.core.content.ContextCompat
import com.astropay.connect.BuildConfig
import com.astropay.connect.core.AstroLogger

/**
 * Custom WebChromeClient for AstroPay Connect SDK.
 * Handles JavaScript console messages and permission requests.
 */
internal class AstroWebChromeClient(
    private val context: Context,
    private val onCameraPermissionNeeded: (PermissionRequest) -> Unit,
) : WebChromeClient() {
    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
        if (BuildConfig.DEBUG) {
            consoleMessage?.let { msg ->
                val logMessage = "[WebView] ${msg.message()} (${msg.sourceId()}:${msg.lineNumber()})"
                AstroLogger.logDebug(logMessage)
            }
        }
        return true
    }

    override fun onPermissionRequest(request: PermissionRequest?) {
        request?.let { permRequest ->
            val resources = permRequest.resources
            AstroLogger.logDebug("Permission requested: ${resources.joinToString()}, origin: ${permRequest.origin}")

            val hasVideo = resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
            val hasAudio = resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)

            if (hasVideo) {
                // Route to the camera permission handler — it calls request.grant(request.resources)
                // which grants ALL resources in the request (including audio if present).
                onCameraPermissionNeeded(permRequest)
            } else if (hasAudio) {
                // Audio-only request (some KYC flows request mic separately).
                // The grant is contingent on the OS-level RECORD_AUDIO permission
                // actually being held. The app still requests CAMERA + RECORD_AUDIO at
                // the start of any KYC flow; this is the defensive fallback so that a
                // mic stream is never granted-but-silent. If the OS permission is not
                // held we deny for a clean, predictable failure instead.
                val recordAudioGranted =
                    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                if (recordAudioGranted) {
                    permRequest.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    AstroLogger.logDebug("Granted audio-only permission")
                } else {
                    permRequest.deny()
                    AstroLogger.logDebug("Denied audio-only permission: OS RECORD_AUDIO permission not granted")
                }
            } else {
                AstroLogger.logDebug("Denying unknown permission: ${resources.joinToString()}")
                permRequest.deny()
            }
        }
    }

    override fun onProgressChanged(
        view: WebView?,
        newProgress: Int,
    ) {
        super.onProgressChanged(view, newProgress)
    }

    override fun onCreateWindow(
        view: WebView?,
        isDialog: Boolean,
        isUserGesture: Boolean,
        resultMsg: Message?,
    ): Boolean {
        view ?: return false

        val result = view.hitTestResult
        val url = result.extra

        if (url != null) {
            AstroLogger.logDebug("Opening external URL: $url")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            view.context.startActivity(intent)
        } else {
            // Fallback: create a temporary WebView to capture the URL
            val tempWebView = WebView(view.context)
            tempWebView.webViewClient =
                object : android.webkit.WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: android.webkit.WebResourceRequest?,
                    ): Boolean {
                        val targetUrl = request?.url?.toString()
                        if (targetUrl != null) {
                            AstroLogger.logDebug("Opening external URL (fallback): $targetUrl")
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            view?.context?.startActivity(intent)
                        }
                        return true
                    }
                }
            (resultMsg?.obj as? WebView.WebViewTransport)?.webView = tempWebView
            resultMsg?.sendToTarget()
        }

        return true
    }
}
