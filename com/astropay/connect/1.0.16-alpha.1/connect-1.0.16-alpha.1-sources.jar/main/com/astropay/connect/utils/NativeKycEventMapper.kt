package com.astropay.connect.utils

import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroEvent

/**
 * Pure, CAF-free mapper from the engine-layer [NativeKycEvent] POD to the integrator-facing
 * [AstroEvent].
 *
 * Lives in the always-compiled `src/main` path (no CAF types) so both flavors compile it and the
 * CAF-free unit test target can exercise the mapping. The engine (`CAFManager`, `nativeKyc` flavor
 * only) never references [AstroEvent]; the call site converts each emitted [NativeKycEvent] through
 * this object and fires the same `onEvent` sink the web uses.
 *
 * Base fields are synthesized here (the `startNativeKyc` bridge body carries none of them):
 * - `platform`   = [AstroConstants.PLATFORM]
 * - `appVersion` = [AstroConstants.SDK_VERSION] (the native SDK version, NOT the web bundle version)
 * - `sessionId`  = `""` (the web session id is not available natively; empty signals no correlation)
 *
 * All three events share `eventCategory = "page_view"` and `screenName = "kyc_validation"`.
 */
internal object NativeKycEventMapper {

    /** `eventCategory` shared by every native KYC progress event. */
    private const val EVENT_CATEGORY = "page_view"

    /** `screenName` shared by every native KYC progress event (the existing CAF/KYC screen). */
    private const val SCREEN_NAME = "kyc_validation"

    /** Native event name for [NativeKycEventStep.LOADING]. */
    const val EVENT_NAME_LOADING = "kyc_caf_native_loading"

    /** Native event name for [NativeKycEventStep.DOCUMENT_CAPTURED]. */
    const val EVENT_NAME_DOCUMENT_CAPTURED = "kyc_caf_native_document_captured"

    /** Native event name for [NativeKycEventStep.LIVENESS_CAPTURED]. */
    const val EVENT_NAME_LIVENESS_CAPTURED = "kyc_caf_native_liveness_captured"

    /**
     * Maps a CAF-free [NativeKycEvent] to an [AstroEvent], selecting the event name from [step]
     * and synthesizing the base fields. `eventProperties` is widened from the POD's
     * `Map<String, String>?` to `Map<String, Any>?` (null for [NativeKycEventStep.LOADING]).
     */
    fun toAstroEvent(event: NativeKycEvent): AstroEvent =
        AstroEvent(
            screenName = SCREEN_NAME,
            eventName = eventName(event.step),
            eventCategory = EVENT_CATEGORY,
            eventProperties = event.properties,
            sessionId = "",
            appVersion = AstroConstants.SDK_VERSION,
            platform = AstroConstants.PLATFORM,
        )

    private fun eventName(step: NativeKycEventStep): String =
        when (step) {
            NativeKycEventStep.LOADING -> EVENT_NAME_LOADING
            NativeKycEventStep.DOCUMENT_CAPTURED -> EVENT_NAME_DOCUMENT_CAPTURED
            NativeKycEventStep.LIVENESS_CAPTURED -> EVENT_NAME_LIVENESS_CAPTURED
        }
}
