package com.astropay.connect.core

/**
 * Represents the result of an AstroPay Connect SDK operation.
 */
sealed class AstroResult {
    /**
     * Operation completed successfully.
     */
    data object Success : AstroResult()

    /**
     * Operation failed with an error.
     */
    data class Failure(val error: AstroError) : AstroResult()

    /**
     * User closed the SDK.
     */
    data object Closed : AstroResult()

    /**
     * An analytics event was received from the web bridge.
     */
    data class Event(val event: AstroEvent) : AstroResult()

    /**
     * Checks if the result is a success.
     */
    val isSuccess: Boolean
        get() = this is Success

    /**
     * Checks if the result is a failure.
     */
    val isFailure: Boolean
        get() = this is Failure

    /**
     * Checks if the SDK was closed by the user.
     */
    val isClosed: Boolean
        get() = this is Closed

    /**
     * Checks if the result is an event.
     */
    val isEvent: Boolean
        get() = this is Event

    /**
     * Returns the error if this is a Failure, null otherwise.
     */
    fun getErrorOrNull(): AstroError? {
        return when (this) {
            is Failure -> error
            else -> null
        }
    }

    /**
     * Executes the given block if this is a Success.
     */
    inline fun onSuccess(block: () -> Unit): AstroResult {
        if (this is Success) block()
        return this
    }

    /**
     * Executes the given block if this is a Failure.
     */
    inline fun onFailure(block: (AstroError) -> Unit): AstroResult {
        if (this is Failure) block(error)
        return this
    }

    /**
     * Executes the given block if this is Closed.
     */
    inline fun onClosed(block: () -> Unit): AstroResult {
        if (this is Closed) block()
        return this
    }

    /**
     * Executes the given block if this is an Event.
     */
    inline fun onEvent(block: (AstroEvent) -> Unit): AstroResult {
        if (this is Event) block(event)
        return this
    }

    /**
     * Returns the event if this is an Event, null otherwise.
     */
    fun getEventOrNull(): AstroEvent? {
        return when (this) {
            is Event -> event
            else -> null
        }
    }
}
