package com.astropay.connect.views

import android.content.Intent
import android.net.Uri
import android.os.Message
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import com.astropay.connect.core.AstroLogger

/**
 * Custom WebChromeClient for AstroPay Connect SDK.
 * Handles JavaScript console messages and permission requests.
 */
internal class AstroWebChromeClient(
    private val onCameraPermissionNeeded: (PermissionRequest) -> Unit,
) : WebChromeClient() {
    // override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
    //     consoleMessage?.let { message ->
    //         val logMessage = "[WebView Console] ${message.message()} (${message.sourceId()}:${message.lineNumber()})"

    //         when (message.messageLevel()) {
    //             ConsoleMessage.MessageLevel.ERROR -> AstroLogger.error(logMessage)
    //             ConsoleMessage.MessageLevel.WARNING -> AstroLogger.warning(logMessage)
    //             ConsoleMessage.MessageLevel.LOG -> AstroLogger.info(logMessage)
    //             ConsoleMessage.MessageLevel.DEBUG -> AstroLogger.debug(logMessage)
    //             ConsoleMessage.MessageLevel.TIP -> AstroLogger.verbose(logMessage)
    //             else -> AstroLogger.debug(logMessage)
    //         }
    //     }
    //     return true
    // }

    override fun onPermissionRequest(request: PermissionRequest?) {
        request?.let { permRequest ->
            val resources = permRequest.resources
            AstroLogger.logDebug("Permission requested: ${resources.joinToString()}, origin: ${permRequest.origin}")

            if (resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                onCameraPermissionNeeded(permRequest)
            } else {
                AstroLogger.logDebug("Denying non-camera permission")
                permRequest.deny()
            }
        }
    }

    override fun onProgressChanged(
        view: WebView?,
        newProgress: Int,
    ) {
        super.onProgressChanged(view, newProgress)
    }

    override fun onCreateWindow(
        view: WebView?,
        isDialog: Boolean,
        isUserGesture: Boolean,
        resultMsg: Message?,
    ): Boolean {
        view ?: return false

        val result = view.hitTestResult
        val url = result.extra

        if (url != null) {
            AstroLogger.logDebug("Opening external URL: $url")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            view.context.startActivity(intent)
        } else {
            // Fallback: create a temporary WebView to capture the URL
            val tempWebView = WebView(view.context)
            tempWebView.webViewClient =
                object : android.webkit.WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: android.webkit.WebResourceRequest?,
                    ): Boolean {
                        val targetUrl = request?.url?.toString()
                        if (targetUrl != null) {
                            AstroLogger.logDebug("Opening external URL (fallback): $targetUrl")
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            view?.context?.startActivity(intent)
                        }
                        return true
                    }
                }
            (resultMsg?.obj as? WebView.WebViewTransport)?.webView = tempWebView
            resultMsg?.sendToTarget()
        }

        return true
    }
}
