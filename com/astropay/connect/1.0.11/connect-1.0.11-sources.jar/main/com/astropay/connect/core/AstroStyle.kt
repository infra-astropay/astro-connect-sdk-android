package com.astropay.connect.core

import androidx.compose.ui.graphics.Color

data class AstroHeaderStyle(
    val backgroundColor: String? = null,
    val borderColor: String? = null,
    val borderWidth: Float? = null,
    val paddingHorizontal: Float? = null,
    val paddingVertical: Float? = null,
)

data class AstroStyle(
    val backgroundColor: String? = null,
    val header: AstroHeaderStyle? = null,
)

internal fun parseHexColor(hex: String): Color? {
    val sanitized = hex.trimStart('#')
    if (sanitized.length != 6) return null
    val colorLong = sanitized.toLongOrNull(16) ?: return null
    return Color(0xFF000000 or colorLong)
}
