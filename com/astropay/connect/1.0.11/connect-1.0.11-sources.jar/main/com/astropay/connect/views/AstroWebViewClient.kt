package com.astropay.connect.views

import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import java.io.ByteArrayInputStream

/**
 * Custom WebViewClient for AstroPay Connect SDK.
 * Handles page loading events and injects the JavaScript bridge.
 *
 * Note: Bridge injection timing on Android differs from iOS due to platform limitations:
 * - iOS: Uses WKUserScript with .atDocumentStart injection time
 * - Android: Injects via evaluateJavascript in onPageStarted and re-injects in onPageFinished
 *
 * The bridge is also provided via addJavascriptInterface (named AstroPayBridge) which
 * ensures native methods are available even before the script injection completes.
 */
internal class AstroWebViewClient(
    private val configuration: AstroConfiguration,
    private val themeParameter: String,
    private val onPageStarted: () -> Unit,
    private val onPageFinished: () -> Unit,
    private val onError: (AstroError) -> Unit,
) : WebViewClient() {
    private var currentUrl: String? = null
    private var bridgeInjectedForCurrentPage = false

    override fun onPageStarted(
        view: WebView?,
        url: String?,
        favicon: Bitmap?,
    ) {
        super.onPageStarted(view, url, favicon)
        currentUrl = url

        bridgeInjectedForCurrentPage = false

        if (view != null) {
            AstroLogger.logDebug("Bridge: Injecting bridge script for navigation to $url")
            injectBridge(view, "onPageStarted")
            bridgeInjectedForCurrentPage = true
        }

        onPageStarted()
    }

    override fun onPageFinished(
        view: WebView?,
        url: String?,
    ) {
        super.onPageFinished(view, url)
        // AstroLogger.network(url ?: "unknown", null, "finished")

        // Re-inject the bridge to ensure properties are available after page load
        // This handles cases where the page's JavaScript might have overwritten the bridge
        // Only re-inject if we already injected in onPageStarted (safety measure)
        if (view != null && !bridgeInjectedForCurrentPage) {
            AstroLogger.logDebug("Bridge: Re-injecting bridge script in onPageFinished for $url")
            injectBridge(view, "onPageFinished")
        }

        onPageFinished()
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: WebResourceError?,
    ) {
        super.onReceivedError(view, request, error)

        // Only handle main frame errors
        if (request?.isForMainFrame == true) {
            val (subCode, description) = mapErrorCodeToSubCodeAndMessage(error?.errorCode)
            val astroError = AstroError(ErrorCode.NETWORK_ERROR, subCode, description)
            AstroLogger.logError(astroError)
            onError(astroError)
        }
    }

    /**
     * Maps Android WebView error codes to standardized subcodes and messages matching iOS SDK.
     * This ensures consistent error reporting across platforms.
     *
     * @return Pair of (subCode, message)
     */
    private fun mapErrorCodeToSubCodeAndMessage(errorCode: Int?): Pair<String, String> =
        when (errorCode) {
            WebViewClient.ERROR_UNKNOWN -> "01" to "No internet connection"
            WebViewClient.ERROR_HOST_LOOKUP -> "02" to "Server not found"
            WebViewClient.ERROR_TIMEOUT -> "03" to "Connection timed out"
            WebViewClient.ERROR_CONNECT -> "04" to "Unable to connect to server"
            WebViewClient.ERROR_IO -> "05" to "Connection lost"
            else -> "06" to "Unknown network error"
        }

    override fun shouldOverrideUrlLoading(
        view: WebView?,
        request: WebResourceRequest?,
    ): Boolean {
        val url = request?.url?.toString() ?: return false

        AstroLogger.logDebug("URL loading: $url")

        // Allow all URLs within the AstroPay domain
        return false
    }

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?,
    ): WebResourceResponse? {
        val url = request?.url?.toString() ?: return null
        // Intercept favicon.ico to prevent repeated requests that trigger WAF rate limiting and IP blocking.
        // The favicon is never displayed in an embedded WebView, so an empty response is safe.
        if (url.endsWith("/favicon.ico")) {
            return WebResourceResponse("image/x-icon", "utf-8", ByteArrayInputStream(ByteArray(0)))
        }

        return null
    }

    override fun onReceivedSslError(
        view: WebView?,
        handler: SslErrorHandler?,
        error: SslError?,
    ) {
        // Allow SSL errors only in LOCAL environment (self-signed certificates)
        if (configuration.environment.isLocal) {
            // AstroLogger.warning("SSL error ignored in LOCAL environment: ${error?.primaryError}")
            handler?.proceed()
        } else {
            val astroError = AstroError(ErrorCode.NETWORK_ERROR, "SSL", "SSL certificate error: ${error?.primaryError}")
            AstroLogger.logError(astroError)
            handler?.cancel()
            onError(astroError)
        }
    }

    /**
     * Injects the JavaScript bridge into the WebView.
     *
     * @param webView The WebView to inject the bridge into.
     * @param context The context where injection is happening (for logging).
     */
    private fun injectBridge(
        webView: WebView,
        context: String,
    ) {
        val script = AstroBridgeManager.createBridgeScript(configuration, themeParameter)
        AstroLogger.logDebug("Bridge: Script length: ${script.length} characters")

        webView.evaluateJavascript(script) { result ->
            AstroLogger.logDebug("Bridge injected.  Result: $result")
            if (result == "true") {
                bridgeInjectedForCurrentPage = true
            }
        }
    }
}
