package com.astropay.connect

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroResult
import com.astropay.connect.views.AstroConnectView

/**
 * Extension function to display AstroPay Connect SDK.
 * This is equivalent to the iOS `.astroConnect()` View modifier.
 *
 * Usage:
 * ```kotlin
 * Box(modifier = Modifier.fillMaxSize()) {
 *     AstroConnect(
 *         configuration = configuration,
 *         onResult = { result ->
 *             when (result) {
 *                 is AstroResult.Success -> // Handle success
 *                 is AstroResult.Failure -> // Handle error
 *                 is AstroResult.Closed -> // Handle user closed
 *             }
 *         }
 *     )
 * }
 * ```
 *
 * @param configuration The SDK configuration.
 * @param modifier Modifier for the composable.
 * @param loadingContent Optional custom loading content.
 * @param onResult Callback for SDK result.
 */
@Composable
fun AstroConnect(
    configuration: AstroConfiguration,
    modifier: Modifier = Modifier,
    loadingContent: @Composable (() -> Unit)? = null,
    onResult: (AstroResult) -> Unit,
) {
    AstroConnectView(
        configuration = configuration,
        modifier = modifier,
        loadingContent = loadingContent,
        onResult = onResult,
    )
}
