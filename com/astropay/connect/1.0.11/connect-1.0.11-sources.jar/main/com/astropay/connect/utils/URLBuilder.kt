package com.astropay.connect.utils

import android.net.Uri
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode

/**
 * Utility class for building URLs for AstroPay Connect SDK.
 */
internal object URLBuilder {
    /**
     * Builds the complete URL for the SDK based on the configuration.
     *
     * @param configuration The SDK configuration.
     * @param themeParameter The resolved theme parameter ("light" or "dark").
     * @return The complete URL string, or null if the base URL cannot be determined or is invalid.
     */
    fun buildURL(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String? {
        val baseURL = configuration.environment.getBaseURL(configuration.localIP)

        if (baseURL == null) {
            val error =
                AstroError(
                    ErrorCode.INITIALIZATION_ERROR,
                    null,
                    "Invalid base URL for environment: ${configuration.environment}",
                )
            AstroLogger.logError(error)
            return null
        }

        // Validate URL before proceeding (matching iOS behavior)
        if (!NetworkUtils.isValidURL(baseURL)) {
            val error =
                AstroError(
                    ErrorCode.INITIALIZATION_ERROR,
                    null,
                    "Base URL failed validation: $baseURL",
                )
            AstroLogger.logError(error)
            return null
        }

        val uriBuilder = Uri.parse(baseURL).buildUpon()

        // Add cache buster
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.VERSION,
            System.currentTimeMillis().toString(),
        )

        // Add theme
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.THEME,
            themeParameter,
        )

        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.ACCESS_TOKEN,
            configuration.accessToken,
        )

        // Add language
        uriBuilder.appendQueryParameter(
            AstroConstants.QueryParams.LANGUAGE,
            configuration.language,
        )

        return uriBuilder.build().toString()
    }

    /**
     * Builds a URL with custom query parameters.
     *
     * @param baseURL The base URL.
     * @param params The query parameters to add.
     * @return The complete URL string.
     */
    fun buildURL(
        baseURL: String,
        params: Map<String, String>,
    ): String {
        val uriBuilder = Uri.parse(baseURL).buildUpon()

        params.forEach { (key, value) ->
            uriBuilder.appendQueryParameter(key, value)
        }

        return uriBuilder.build().toString()
    }
}
