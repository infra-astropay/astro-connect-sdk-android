package com.astropay.connect.core

import androidx.annotation.ColorInt
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

data class AstroHeaderStyle(
    @ColorInt val backgroundColor: Int? = null,
    @ColorInt val borderColor: Int? = null,
    val borderWidth: Float? = null,
    val paddingHorizontal: Float? = null,
    val paddingVertical: Float? = null,
)

data class AstroSurfaceColors(
    @ColorInt val base: Int? = null,
    @ColorInt val baseHover: Int? = null,
    @ColorInt val baseActive: Int? = null,
    @ColorInt val secondary: Int? = null,
    @ColorInt val secondaryHover: Int? = null,
    @ColorInt val secondaryActive: Int? = null,
    @ColorInt val terciary: Int? = null,
    @ColorInt val terciaryHover: Int? = null,
    @ColorInt val terciaryActive: Int? = null,
    @ColorInt val muted: Int? = null,
    @ColorInt val mutedHover: Int? = null,
    @ColorInt val mutedActive: Int? = null,
    @ColorInt val contrast: Int? = null,
    @ColorInt val contrastHover: Int? = null,
    @ColorInt val contrastActive: Int? = null,
    @ColorInt val invert: Int? = null,
    @ColorInt val invertHover: Int? = null,
    @ColorInt val invertActive: Int? = null,
    @ColorInt val white: Int? = null,
    @ColorInt val whiteHover: Int? = null,
    @ColorInt val whiteActive: Int? = null,
    @ColorInt val highlight: Int? = null,
    @ColorInt val highlightHover: Int? = null,
    @ColorInt val highlightActive: Int? = null,
    @ColorInt val highlightMuted: Int? = null,
    @ColorInt val highlightMutedHover: Int? = null,
    @ColorInt val highlightMutedActive: Int? = null,
    @ColorInt val error: Int? = null,
    @ColorInt val errorHover: Int? = null,
    @ColorInt val errorActive: Int? = null,
    @ColorInt val errorMuted: Int? = null,
    @ColorInt val errorMutedHover: Int? = null,
    @ColorInt val errorMutedActive: Int? = null,
    @ColorInt val errorLight: Int? = null,
    @ColorInt val warning: Int? = null,
    @ColorInt val warningHover: Int? = null,
    @ColorInt val warningActive: Int? = null,
    @ColorInt val warningMuted: Int? = null,
    @ColorInt val warningMutedHover: Int? = null,
    @ColorInt val warningMutedActive: Int? = null,
    @ColorInt val warningLight: Int? = null,
    @ColorInt val success: Int? = null,
    @ColorInt val successHover: Int? = null,
    @ColorInt val successActive: Int? = null,
    @ColorInt val successMuted: Int? = null,
    @ColorInt val successMutedHover: Int? = null,
    @ColorInt val successMutedActive: Int? = null,
    @ColorInt val successLight: Int? = null,
    @ColorInt val accent: Int? = null,
    @ColorInt val accentHover: Int? = null,
    @ColorInt val accentActive: Int? = null,
    @ColorInt val accentMuted: Int? = null,
    @ColorInt val accentMutedHover: Int? = null,
    @ColorInt val accentMutedActive: Int? = null,
    @ColorInt val accentLight: Int? = null,
    @ColorInt val lime: Int? = null,
    @ColorInt val limeMuted: Int? = null,
    @ColorInt val overlay: Int? = null,
    @ColorInt val black: Int? = null,
)

data class AstroTextColors(
    @ColorInt val black: Int? = null,
    @ColorInt val white: Int? = null,
    @ColorInt val base: Int? = null,
    @ColorInt val muted: Int? = null,
    @ColorInt val mutedSecondary: Int? = null,
    @ColorInt val faint: Int? = null,
    @ColorInt val invert: Int? = null,
    @ColorInt val highlight: Int? = null,
    @ColorInt val error: Int? = null,
    @ColorInt val accent: Int? = null,
    @ColorInt val warning: Int? = null,
    @ColorInt val success: Int? = null,
)

data class AstroBorderColors(
    @ColorInt val base: Int? = null,
    @ColorInt val faint: Int? = null,
    @ColorInt val muted: Int? = null,
    @ColorInt val highlight: Int? = null,
    @ColorInt val error: Int? = null,
    @ColorInt val accent: Int? = null,
    @ColorInt val warning: Int? = null,
    @ColorInt val success: Int? = null,
)

data class AstroButtonColors(
    @ColorInt val primaryBackground: Int? = null,
    @ColorInt val primaryBackgroundHover: Int? = null,
    @ColorInt val primaryBackgroundFocus: Int? = null,
    @ColorInt val primaryBackgroundDisabled: Int? = null,
    @ColorInt val primaryText: Int? = null,
    @ColorInt val primaryTextHover: Int? = null,
    @ColorInt val primaryTextFocus: Int? = null,
    @ColorInt val primaryTextDisabled: Int? = null,
    @ColorInt val primaryLoaderColor: Int? = null,
    @ColorInt val primaryLoaderColorDisabled: Int? = null,
    @ColorInt val primaryFocusOutlineColor: Int? = null,
    @ColorInt val secondaryBackground: Int? = null,
    @ColorInt val secondaryBackgroundHover: Int? = null,
    @ColorInt val secondaryBackgroundFocus: Int? = null,
    @ColorInt val secondaryBackgroundDisabled: Int? = null,
    @ColorInt val secondaryText: Int? = null,
    @ColorInt val secondaryTextHover: Int? = null,
    @ColorInt val secondaryTextFocus: Int? = null,
    @ColorInt val secondaryTextDisabled: Int? = null,
    @ColorInt val secondaryLoaderColor: Int? = null,
    @ColorInt val secondaryLoaderColorDisabled: Int? = null,
    @ColorInt val secondaryFocusOutlineColor: Int? = null,
    @ColorInt val tertiaryBackground: Int? = null,
    @ColorInt val tertiaryBackgroundHover: Int? = null,
    @ColorInt val tertiaryBackgroundFocus: Int? = null,
    @ColorInt val tertiaryBackgroundDisabled: Int? = null,
    @ColorInt val tertiaryText: Int? = null,
    @ColorInt val tertiaryTextHover: Int? = null,
    @ColorInt val tertiaryTextFocus: Int? = null,
    @ColorInt val tertiaryTextDisabled: Int? = null,
    @ColorInt val tertiaryLoaderColor: Int? = null,
    @ColorInt val tertiaryLoaderColorDisabled: Int? = null,
    @ColorInt val tertiaryFocusOutlineColor: Int? = null,
    @ColorInt val grayBackground: Int? = null,
    @ColorInt val grayBackgroundHover: Int? = null,
    @ColorInt val grayBackgroundFocus: Int? = null,
    @ColorInt val grayBackgroundDisabled: Int? = null,
    @ColorInt val grayText: Int? = null,
    @ColorInt val grayTextHover: Int? = null,
    @ColorInt val grayTextFocus: Int? = null,
    @ColorInt val grayTextDisabled: Int? = null,
    @ColorInt val grayLoaderColor: Int? = null,
    @ColorInt val grayLoaderColorDisabled: Int? = null,
    @ColorInt val grayFocusOutlineColor: Int? = null,
    @ColorInt val mutedBackground: Int? = null,
    @ColorInt val mutedBackgroundHover: Int? = null,
    @ColorInt val mutedBackgroundFocus: Int? = null,
    @ColorInt val mutedBackgroundDisabled: Int? = null,
    @ColorInt val mutedText: Int? = null,
    @ColorInt val mutedTextHover: Int? = null,
    @ColorInt val mutedTextFocus: Int? = null,
    @ColorInt val mutedTextDisabled: Int? = null,
    @ColorInt val mutedLoaderColor: Int? = null,
    @ColorInt val mutedLoaderColorDisabled: Int? = null,
    @ColorInt val mutedFocusOutlineColor: Int? = null,
    @ColorInt val transparentBackground: Int? = null,
    @ColorInt val transparentBackgroundHover: Int? = null,
    @ColorInt val transparentBackgroundFocus: Int? = null,
    @ColorInt val transparentBackgroundDisabled: Int? = null,
    @ColorInt val transparentText: Int? = null,
    @ColorInt val transparentTextHover: Int? = null,
    @ColorInt val transparentTextFocus: Int? = null,
    @ColorInt val transparentTextDisabled: Int? = null,
    @ColorInt val transparentLoaderColor: Int? = null,
    @ColorInt val transparentLoaderColorDisabled: Int? = null,
    @ColorInt val transparentFocusOutlineColor: Int? = null,
    @ColorInt val transparentWhiteBackground: Int? = null,
    @ColorInt val transparentWhiteBackgroundHover: Int? = null,
    @ColorInt val transparentWhiteBackgroundFocus: Int? = null,
    @ColorInt val transparentWhiteBackgroundDisabled: Int? = null,
    @ColorInt val transparentWhiteText: Int? = null,
    @ColorInt val transparentWhiteTextHover: Int? = null,
    @ColorInt val transparentWhiteTextFocus: Int? = null,
    @ColorInt val transparentWhiteTextDisabled: Int? = null,
    @ColorInt val transparentWhiteLoaderColor: Int? = null,
    @ColorInt val transparentWhiteLoaderColorDisabled: Int? = null,
    @ColorInt val transparentWhiteFocusOutlineColor: Int? = null,
    @ColorInt val errorMutedBackground: Int? = null,
    @ColorInt val errorMutedBackgroundHover: Int? = null,
    @ColorInt val errorMutedBackgroundFocus: Int? = null,
    @ColorInt val errorMutedBackgroundDisabled: Int? = null,
    @ColorInt val errorMutedText: Int? = null,
    @ColorInt val errorMutedTextHover: Int? = null,
    @ColorInt val errorMutedTextFocus: Int? = null,
    @ColorInt val errorMutedTextDisabled: Int? = null,
    @ColorInt val errorMutedLoaderColor: Int? = null,
    @ColorInt val errorMutedLoaderColorDisabled: Int? = null,
    @ColorInt val errorMutedFocusOutlineColor: Int? = null,
    @ColorInt val errorBackground: Int? = null,
    @ColorInt val errorBackgroundHover: Int? = null,
    @ColorInt val errorBackgroundFocus: Int? = null,
    @ColorInt val errorBackgroundDisabled: Int? = null,
    @ColorInt val errorText: Int? = null,
    @ColorInt val errorTextHover: Int? = null,
    @ColorInt val errorTextFocus: Int? = null,
    @ColorInt val errorTextDisabled: Int? = null,
    @ColorInt val errorLoaderColor: Int? = null,
    @ColorInt val errorLoaderColorDisabled: Int? = null,
    @ColorInt val errorFocusOutlineColor: Int? = null,
    @ColorInt val warningMutedBackground: Int? = null,
    @ColorInt val warningMutedBackgroundHover: Int? = null,
    @ColorInt val warningMutedBackgroundFocus: Int? = null,
    @ColorInt val warningMutedBackgroundDisabled: Int? = null,
    @ColorInt val warningMutedText: Int? = null,
    @ColorInt val warningMutedTextHover: Int? = null,
    @ColorInt val warningMutedTextFocus: Int? = null,
    @ColorInt val warningMutedTextDisabled: Int? = null,
    @ColorInt val warningMutedLoaderColor: Int? = null,
    @ColorInt val warningMutedLoaderColorDisabled: Int? = null,
    @ColorInt val warningMutedFocusOutlineColor: Int? = null,
    @ColorInt val warningBackground: Int? = null,
    @ColorInt val warningBackgroundHover: Int? = null,
    @ColorInt val warningBackgroundFocus: Int? = null,
    @ColorInt val warningBackgroundDisabled: Int? = null,
    @ColorInt val warningText: Int? = null,
    @ColorInt val warningTextHover: Int? = null,
    @ColorInt val warningTextFocus: Int? = null,
    @ColorInt val warningTextDisabled: Int? = null,
    @ColorInt val warningLoaderColor: Int? = null,
    @ColorInt val warningLoaderColorDisabled: Int? = null,
    @ColorInt val warningFocusOutlineColor: Int? = null,
    @ColorInt val whiteBackground: Int? = null,
    @ColorInt val whiteBackgroundHover: Int? = null,
    @ColorInt val whiteBackgroundFocus: Int? = null,
    @ColorInt val whiteBackgroundDisabled: Int? = null,
    @ColorInt val whiteText: Int? = null,
    @ColorInt val whiteTextHover: Int? = null,
    @ColorInt val whiteTextFocus: Int? = null,
    @ColorInt val whiteTextDisabled: Int? = null,
    @ColorInt val whiteLoaderColor: Int? = null,
    @ColorInt val whiteLoaderColorDisabled: Int? = null,
    @ColorInt val whiteFocusOutlineColor: Int? = null,
)

data class AstroButtonIconColors(
    @ColorInt val primaryBackground: Int? = null,
    @ColorInt val primaryBackgroundHover: Int? = null,
    @ColorInt val primaryBackgroundFocus: Int? = null,
    @ColorInt val primaryBackgroundDisabled: Int? = null,
    @ColorInt val primaryIconColor: Int? = null,
    @ColorInt val primaryIconColorDisabled: Int? = null,
    @ColorInt val primaryText: Int? = null,
    @ColorInt val primaryTextDisabled: Int? = null,
    @ColorInt val primaryLoaderColor: Int? = null,
    @ColorInt val primaryLoaderColorDisabled: Int? = null,
    @ColorInt val primaryFocusOutlineColor: Int? = null,
    @ColorInt val secondaryBackground: Int? = null,
    @ColorInt val secondaryBackgroundHover: Int? = null,
    @ColorInt val secondaryBackgroundFocus: Int? = null,
    @ColorInt val secondaryBackgroundDisabled: Int? = null,
    @ColorInt val secondaryIconColor: Int? = null,
    @ColorInt val secondaryIconColorDisabled: Int? = null,
    @ColorInt val secondaryText: Int? = null,
    @ColorInt val secondaryTextDisabled: Int? = null,
    @ColorInt val secondaryLoaderColor: Int? = null,
    @ColorInt val secondaryLoaderColorDisabled: Int? = null,
    @ColorInt val secondaryFocusOutlineColor: Int? = null,
    @ColorInt val tertiaryBackground: Int? = null,
    @ColorInt val tertiaryBackgroundHover: Int? = null,
    @ColorInt val tertiaryBackgroundFocus: Int? = null,
    @ColorInt val tertiaryBackgroundDisabled: Int? = null,
    @ColorInt val tertiaryIconColor: Int? = null,
    @ColorInt val tertiaryIconColorDisabled: Int? = null,
    @ColorInt val tertiaryText: Int? = null,
    @ColorInt val tertiaryTextDisabled: Int? = null,
    @ColorInt val tertiaryLoaderColor: Int? = null,
    @ColorInt val tertiaryLoaderColorDisabled: Int? = null,
    @ColorInt val tertiaryFocusOutlineColor: Int? = null,
    @ColorInt val grayBackground: Int? = null,
    @ColorInt val grayBackgroundHover: Int? = null,
    @ColorInt val grayBackgroundFocus: Int? = null,
    @ColorInt val grayBackgroundDisabled: Int? = null,
    @ColorInt val grayIconColor: Int? = null,
    @ColorInt val grayIconColorDisabled: Int? = null,
    @ColorInt val grayText: Int? = null,
    @ColorInt val grayTextDisabled: Int? = null,
    @ColorInt val grayLoaderColor: Int? = null,
    @ColorInt val grayLoaderColorDisabled: Int? = null,
    @ColorInt val grayFocusOutlineColor: Int? = null,
    @ColorInt val mutedBackground: Int? = null,
    @ColorInt val mutedBackgroundHover: Int? = null,
    @ColorInt val mutedBackgroundFocus: Int? = null,
    @ColorInt val mutedBackgroundDisabled: Int? = null,
    @ColorInt val mutedIconColor: Int? = null,
    @ColorInt val mutedIconColorDisabled: Int? = null,
    @ColorInt val mutedText: Int? = null,
    @ColorInt val mutedTextDisabled: Int? = null,
    @ColorInt val mutedLoaderColor: Int? = null,
    @ColorInt val mutedLoaderColorDisabled: Int? = null,
    @ColorInt val mutedFocusOutlineColor: Int? = null,
    @ColorInt val transparentBackground: Int? = null,
    @ColorInt val transparentBackgroundHover: Int? = null,
    @ColorInt val transparentBackgroundFocus: Int? = null,
    @ColorInt val transparentBackgroundDisabled: Int? = null,
    @ColorInt val transparentIconColor: Int? = null,
    @ColorInt val transparentIconColorDisabled: Int? = null,
    @ColorInt val transparentText: Int? = null,
    @ColorInt val transparentTextDisabled: Int? = null,
    @ColorInt val transparentLoaderColor: Int? = null,
    @ColorInt val transparentLoaderColorDisabled: Int? = null,
    @ColorInt val transparentFocusOutlineColor: Int? = null,
    @ColorInt val transparentWhiteBackground: Int? = null,
    @ColorInt val transparentWhiteBackgroundHover: Int? = null,
    @ColorInt val transparentWhiteBackgroundFocus: Int? = null,
    @ColorInt val transparentWhiteBackgroundDisabled: Int? = null,
    @ColorInt val transparentWhiteIconColor: Int? = null,
    @ColorInt val transparentWhiteIconColorDisabled: Int? = null,
    @ColorInt val transparentWhiteText: Int? = null,
    @ColorInt val transparentWhiteTextDisabled: Int? = null,
    @ColorInt val transparentWhiteLoaderColor: Int? = null,
    @ColorInt val transparentWhiteLoaderColorDisabled: Int? = null,
    @ColorInt val transparentWhiteFocusOutlineColor: Int? = null,
    @ColorInt val errorMutedBackground: Int? = null,
    @ColorInt val errorMutedBackgroundHover: Int? = null,
    @ColorInt val errorMutedBackgroundFocus: Int? = null,
    @ColorInt val errorMutedBackgroundDisabled: Int? = null,
    @ColorInt val errorMutedIconColor: Int? = null,
    @ColorInt val errorMutedIconColorDisabled: Int? = null,
    @ColorInt val errorMutedText: Int? = null,
    @ColorInt val errorMutedTextDisabled: Int? = null,
    @ColorInt val errorMutedLoaderColor: Int? = null,
    @ColorInt val errorMutedLoaderColorDisabled: Int? = null,
    @ColorInt val errorMutedFocusOutlineColor: Int? = null,
    @ColorInt val errorBackground: Int? = null,
    @ColorInt val errorBackgroundHover: Int? = null,
    @ColorInt val errorBackgroundFocus: Int? = null,
    @ColorInt val errorBackgroundDisabled: Int? = null,
    @ColorInt val errorIconColor: Int? = null,
    @ColorInt val errorIconColorDisabled: Int? = null,
    @ColorInt val errorText: Int? = null,
    @ColorInt val errorTextDisabled: Int? = null,
    @ColorInt val errorLoaderColor: Int? = null,
    @ColorInt val errorLoaderColorDisabled: Int? = null,
    @ColorInt val errorFocusOutlineColor: Int? = null,
    @ColorInt val warningMutedBackground: Int? = null,
    @ColorInt val warningMutedBackgroundHover: Int? = null,
    @ColorInt val warningMutedBackgroundFocus: Int? = null,
    @ColorInt val warningMutedBackgroundDisabled: Int? = null,
    @ColorInt val warningMutedIconColor: Int? = null,
    @ColorInt val warningMutedIconColorDisabled: Int? = null,
    @ColorInt val warningMutedText: Int? = null,
    @ColorInt val warningMutedTextDisabled: Int? = null,
    @ColorInt val warningMutedLoaderColor: Int? = null,
    @ColorInt val warningMutedLoaderColorDisabled: Int? = null,
    @ColorInt val warningMutedFocusOutlineColor: Int? = null,
    @ColorInt val warningBackground: Int? = null,
    @ColorInt val warningBackgroundHover: Int? = null,
    @ColorInt val warningBackgroundFocus: Int? = null,
    @ColorInt val warningBackgroundDisabled: Int? = null,
    @ColorInt val warningIconColor: Int? = null,
    @ColorInt val warningIconColorDisabled: Int? = null,
    @ColorInt val warningText: Int? = null,
    @ColorInt val warningTextDisabled: Int? = null,
    @ColorInt val warningLoaderColor: Int? = null,
    @ColorInt val warningLoaderColorDisabled: Int? = null,
    @ColorInt val warningFocusOutlineColor: Int? = null,
    @ColorInt val whiteBackground: Int? = null,
    @ColorInt val whiteBackgroundHover: Int? = null,
    @ColorInt val whiteBackgroundFocus: Int? = null,
    @ColorInt val whiteBackgroundDisabled: Int? = null,
    @ColorInt val whiteIconColor: Int? = null,
    @ColorInt val whiteIconColorDisabled: Int? = null,
    @ColorInt val whiteText: Int? = null,
    @ColorInt val whiteTextDisabled: Int? = null,
    @ColorInt val whiteLoaderColor: Int? = null,
    @ColorInt val whiteLoaderColorDisabled: Int? = null,
    @ColorInt val whiteFocusOutlineColor: Int? = null,
)

data class AstroButtonPillColors(
    @ColorInt val infoBackground: Int? = null,
    @ColorInt val infoBackgroundHover: Int? = null,
    @ColorInt val infoBorder: Int? = null,
    @ColorInt val infoText: Int? = null,
    @ColorInt val infoFocusOutlineColor: Int? = null,
    @ColorInt val infoAltBackground: Int? = null,
    @ColorInt val infoAltBackgroundHover: Int? = null,
    @ColorInt val infoAltBorder: Int? = null,
    @ColorInt val infoAltText: Int? = null,
    @ColorInt val infoAltFocusOutlineColor: Int? = null,
    @ColorInt val successBackground: Int? = null,
    @ColorInt val successBackgroundHover: Int? = null,
    @ColorInt val successBorder: Int? = null,
    @ColorInt val successText: Int? = null,
    @ColorInt val successFocusOutlineColor: Int? = null,
    @ColorInt val successMutedBackground: Int? = null,
    @ColorInt val successMutedBackgroundHover: Int? = null,
    @ColorInt val successMutedBorder: Int? = null,
    @ColorInt val successMutedText: Int? = null,
    @ColorInt val successMutedFocusOutlineColor: Int? = null,
    @ColorInt val errorBackground: Int? = null,
    @ColorInt val errorBackgroundHover: Int? = null,
    @ColorInt val errorBorder: Int? = null,
    @ColorInt val errorText: Int? = null,
    @ColorInt val errorFocusOutlineColor: Int? = null,
    @ColorInt val errorMutedBackground: Int? = null,
    @ColorInt val errorMutedBackgroundHover: Int? = null,
    @ColorInt val errorMutedBorder: Int? = null,
    @ColorInt val errorMutedText: Int? = null,
    @ColorInt val errorMutedFocusOutlineColor: Int? = null,
    @ColorInt val warningBackground: Int? = null,
    @ColorInt val warningBackgroundHover: Int? = null,
    @ColorInt val warningBorder: Int? = null,
    @ColorInt val warningText: Int? = null,
    @ColorInt val warningFocusOutlineColor: Int? = null,
    @ColorInt val warningMutedBackground: Int? = null,
    @ColorInt val warningMutedBackgroundHover: Int? = null,
    @ColorInt val warningMutedBorder: Int? = null,
    @ColorInt val warningMutedText: Int? = null,
    @ColorInt val warningMutedFocusOutlineColor: Int? = null,
    @ColorInt val neutralBackground: Int? = null,
    @ColorInt val neutralBackgroundHover: Int? = null,
    @ColorInt val neutralBorder: Int? = null,
    @ColorInt val neutralText: Int? = null,
    @ColorInt val neutralFocusOutlineColor: Int? = null,
    @ColorInt val neutralMutedBackground: Int? = null,
    @ColorInt val neutralMutedBackgroundHover: Int? = null,
    @ColorInt val neutralMutedBorder: Int? = null,
    @ColorInt val neutralMutedText: Int? = null,
    @ColorInt val neutralMutedFocusOutlineColor: Int? = null,
    @ColorInt val pearlBackground: Int? = null,
    @ColorInt val pearlBackgroundHover: Int? = null,
    @ColorInt val pearlBorder: Int? = null,
    @ColorInt val pearlText: Int? = null,
    @ColorInt val pearlFocusOutlineColor: Int? = null,
    @ColorInt val pearlMutedBackground: Int? = null,
    @ColorInt val pearlMutedBackgroundHover: Int? = null,
    @ColorInt val pearlMutedBorder: Int? = null,
    @ColorInt val pearlMutedText: Int? = null,
    @ColorInt val pearlMutedFocusOutlineColor: Int? = null,
    @ColorInt val highlightBackground: Int? = null,
    @ColorInt val highlightBackgroundHover: Int? = null,
    @ColorInt val highlightBorder: Int? = null,
    @ColorInt val highlightText: Int? = null,
    @ColorInt val highlightFocusOutlineColor: Int? = null,
    @ColorInt val highlightMutedBackground: Int? = null,
    @ColorInt val highlightMutedBackgroundHover: Int? = null,
    @ColorInt val highlightMutedBorder: Int? = null,
    @ColorInt val highlightMutedText: Int? = null,
    @ColorInt val highlightMutedFocusOutlineColor: Int? = null,
)

data class AstroInputColors(
    @ColorInt val background: Int? = null,
    @ColorInt val backgroundHover: Int? = null,
    @ColorInt val backgroundFocus: Int? = null,
    @ColorInt val backgroundActive: Int? = null,
    @ColorInt val backgroundFilled: Int? = null,
    @ColorInt val backgroundDisabled: Int? = null,
    @ColorInt val backgroundError: Int? = null,
    @ColorInt val backgroundSuccess: Int? = null,
    @ColorInt val border: Int? = null,
    @ColorInt val borderHover: Int? = null,
    @ColorInt val borderFocus: Int? = null,
    @ColorInt val borderActive: Int? = null,
    @ColorInt val borderFilled: Int? = null,
    @ColorInt val borderDisabled: Int? = null,
    @ColorInt val borderError: Int? = null,
    @ColorInt val borderSuccess: Int? = null,
    @ColorInt val text: Int? = null,
    @ColorInt val textHover: Int? = null,
    @ColorInt val textDisabled: Int? = null,
    @ColorInt val placeholder: Int? = null,
    @ColorInt val placeholderHover: Int? = null,
    @ColorInt val label: Int? = null,
    @ColorInt val helper: Int? = null,
    @ColorInt val errorMessage: Int? = null,
    @ColorInt val successMessage: Int? = null,
    @ColorInt val icon: Int? = null,
    @ColorInt val iconHover: Int? = null,
    @ColorInt val iconFocus: Int? = null,
    @ColorInt val iconDisabled: Int? = null,
    @ColorInt val caret: Int? = null,
    @ColorInt val focusOutlineColor: Int? = null,
    @ColorInt val iconBackground: Int? = null,
    @ColorInt val iconBackgroundHover: Int? = null,
    @ColorInt val iconBackgroundFocus: Int? = null,
    @ColorInt val iconBackgroundDisabled: Int? = null,
    @ColorInt val dropdownBackground: Int? = null,
    @ColorInt val dropdownBorder: Int? = null,
    @ColorInt val dropdownOptionBackground: Int? = null,
    @ColorInt val dropdownOptionBackgroundHover: Int? = null,
    @ColorInt val dropdownOptionBackgroundSelected: Int? = null,
    @ColorInt val dropdownOptionBackgroundDisabled: Int? = null,
    @ColorInt val dropdownOptionText: Int? = null,
    @ColorInt val dropdownOptionTextHover: Int? = null,
    @ColorInt val dropdownOptionTextSelected: Int? = null,
    @ColorInt val dropdownOptionTextDisabled: Int? = null,
    @ColorInt val dropdownOptionIcon: Int? = null,
    @ColorInt val dropdownEmptyMessage: Int? = null,
    @ColorInt val phoneDropdownBackground: Int? = null,
    @ColorInt val phoneDropdownOverlayBackground: Int? = null,
    @ColorInt val phoneDropdownHeaderBackground: Int? = null,
    @ColorInt val phoneDropdownItemBackground: Int? = null,
    @ColorInt val phoneDropdownItemBackgroundHover: Int? = null,
    @ColorInt val phoneDropdownItemBackgroundActive: Int? = null,
    @ColorInt val phoneDropdownItemText: Int? = null,
    @ColorInt val phoneDropdownItemTextSecondary: Int? = null,
)

// MARK: - Typography

/**
 * Leaf typography token. Numeric fields are assumed-px on the native API;
 * the SDK appends `"px"` when serializing them to the wire so the web side
 * reads MUI-ready strings. [fontWeight] stays a JSON integer.
 *
 * - [fontSize] must be `>= 0`.
 * - [fontWeight] integer `100..900`.
 * - [lineHeight] must be `>= 0`.
 * - [letterSpacing] may be negative.
 */
data class AstroFontStyle(
    val fontSize: Float? = null,
    val fontWeight: Int? = null,
    val lineHeight: Float? = null,
    val letterSpacing: Float? = null,
    /**
     * Optional font-family name forwarded to the web as a plain string under
     * the per-token `fontFamily` key. The SDK does not load or validate the
     * font — partners are responsible for registering it on the web side
     * (e.g. via a `@font-face` declaration or font provider). Drop the key
     * when null.
     */
    val fontFamily: String? = null,
)

/**
 * Global typography catalog. The native SDK only exposes a single
 * [fontFamily] knob — partners pick the font-family name and the web
 * applies it to every typography slot through the CSS variable
 * `--ap-t-font-family`.
 *
 * Per-token slots (size / weight / line-height / etc.) are intentionally
 * NOT modelled here: partners that need per-token tweaking can still
 * supply them through [AstroConfiguration.styleOverrides] as a free-form
 * `typography` map (parity with iOS).
 *
 * [fontFamily] serializes as `typography.fontFamily` on the wire. Drop
 * on null or empty string so both platforms emit byte-identical
 * typography blobs.
 */
data class AstroTypography(
    val fontFamily: String? = null,
)

/** Per-component typography slot for primary buttons. */
data class AstroButtonTypography(val label: AstroFontStyle? = null)

/** Per-component typography slot for icon buttons. */
data class AstroButtonIconTypography(val label: AstroFontStyle? = null)

/** Per-component typography slot for pill buttons. */
data class AstroButtonPillTypography(val label: AstroFontStyle? = null)

/** Per-component typography slots for inputs. */
data class AstroInputTypography(
    val input: AstroFontStyle? = null,
    val label: AstroFontStyle? = null,
    val helper: AstroFontStyle? = null,
    val placeholder: AstroFontStyle? = null,
)

// MARK: - Component style wrappers

/** Wraps button colors + typography under one slot. */
data class AstroButtonStyle(
    val colors: AstroButtonColors? = null,
    val typography: AstroButtonTypography? = null,
)

/** Wraps icon-button colors + typography under one slot. */
data class AstroButtonIconStyle(
    val colors: AstroButtonIconColors? = null,
    val typography: AstroButtonIconTypography? = null,
)

/** Wraps pill-button colors + typography under one slot. */
data class AstroButtonPillStyle(
    val colors: AstroButtonPillColors? = null,
    val typography: AstroButtonPillTypography? = null,
)

/** Wraps input colors + typography under one slot. */
data class AstroInputStyle(
    val colors: AstroInputColors? = null,
    val typography: AstroInputTypography? = null,
)

/**
 * Public style payload forwarded to the web through the bridge. Brand-level
 * fields ([backgroundColor], [primaryColor]) and [header] are consumed
 * natively (header layout, splash background, URL params); the grouped
 * color collections ([surface], [text], [border]) and the per-component
 * wrappers ([buttons], [buttonsIcon], [buttonsPill], [inputs]) are
 * flattened into the wire payload (`colors` map for colors, sibling
 * `typography` / `button.typography` / `input.typography` objects for
 * typography). See STYLE-TOKENS.md for the catalog of tokens.
 *
 * Color fields use `@ColorInt Int?` (`0xAARRGGBB`); the SDK converts each
 * non-null value to a hex string at serialization time via [toAstroHex].
 * The wire encodes 6-digit `#RRGGBB` for opaque colors and 8-digit
 * `#RRGGBBAA` when alpha is partial.
 */
data class AstroStyle(
    @ColorInt val backgroundColor: Int? = null,
    @ColorInt val primaryColor: Int? = null,
    val typography: AstroTypography? = null,
    val surface: AstroSurfaceColors? = null,
    val text: AstroTextColors? = null,
    val border: AstroBorderColors? = null,
    val buttons: AstroButtonStyle? = null,
    val buttonsIcon: AstroButtonIconStyle? = null,
    val buttonsPill: AstroButtonPillStyle? = null,
    val inputs: AstroInputStyle? = null,
    val header: AstroHeaderStyle? = null,
)

/**
 * Returns a copy of this [AstroStyle] where the brand-level fields are
 * propagated as defaults for downstream tokens that are conceptually
 * derived from them. Explicit values always win over the cascade.
 *
 * - [backgroundColor] → [AstroSurfaceColors.base]
 * - [primaryColor]    → [AstroSurfaceColors.highlight],
 *                       [AstroTextColors.highlight],
 *                       [AstroBorderColors.highlight]
 *
 * **Platform divergence:** iOS implements the same cascade in
 * `AstroStyle.swift::toBridgeDictionaryWithCascadingDefaults()` but patches
 * the **post-flattened** bridge dictionary (mutating keys like
 * `surfaceHighlight` directly) instead of copying through the typed
 * sub-structs as Android does here. Net wire payload is identical. The
 * divergence is intentional for the 1.0.14/1.0.15 release: typography has
 * no cascade rule so the gap does not grow. Revisit if a future cascade
 * lands on a non-color token. Typography slots ([typography], and the
 * `typography` field on each [AstroButtonStyle] / [AstroInputStyle]
 * wrapper) are intentionally left untouched.
 */
internal fun AstroStyle.withCascadingDefaults(): AstroStyle {
    val bg = backgroundColor
    val primary = primaryColor
    if (bg == null && primary == null) return this

    val newSurface = (surface ?: AstroSurfaceColors()).let { s ->
        s.copy(
            base = s.base ?: bg,
            highlight = s.highlight ?: primary,
        )
    }
    val newText = (text ?: AstroTextColors()).let { t ->
        t.copy(highlight = t.highlight ?: primary)
    }
    val newBorder = (border ?: AstroBorderColors()).let { b ->
        b.copy(highlight = b.highlight ?: primary)
    }
    return copy(surface = newSurface, text = newText, border = newBorder)
}

// MARK: - Color hex conversion

/**
 * Returns the SDK-canonical hex string for this Android color int.
 *
 * Android `Int` colors are `0xAARRGGBB`. Returns uppercase 6 digits
 * (`#RRGGBB`) when alpha is fully opaque (`0xFF`), otherwise 8 digits
 * (`#RRGGBBAA`). Pure value transformation — no nullability path.
 */
public fun @receiver:ColorInt Int.toAstroHex(): String {
    val a = (this ushr 24) and 0xFF
    val r = (this ushr 16) and 0xFF
    val g = (this ushr 8) and 0xFF
    val b = this and 0xFF
    return if (a == 0xFF) {
        "#%02X%02X%02X".format(r, g, b)
    } else {
        "#%02X%02X%02X%02X".format(r, g, b, a)
    }
}

/**
 * Parses an SDK-canonical hex string into an `@ColorInt` Int (`0xAARRGGBB`).
 * Accepts 6 or 8 hex digits, with or without leading `#`. Returns null on
 * any other shape.
 */
@ColorInt
public fun fromAstroHex(hex: String): Int? {
    val s = hex.trim().removePrefix("#")
    if (s.length != 6 && s.length != 8) return null
    val parsed = s.toLongOrNull(16) ?: return null
    return if (s.length == 8) {
        // RRGGBBAA on the wire → AARRGGBB for Android Int.
        val r = ((parsed ushr 24) and 0xFF).toInt()
        val g = ((parsed ushr 16) and 0xFF).toInt()
        val b = ((parsed ushr 8) and 0xFF).toInt()
        val a = (parsed and 0xFF).toInt()
        (a shl 24) or (r shl 16) or (g shl 8) or b
    } else {
        // RRGGBB → 0xFFRRGGBB.
        (0xFF shl 24) or parsed.toInt()
    }
}

// MARK: - Native chrome color resolution (styleOverrides fallback)

/**
 * Aliases for the brand background slot. Order matters — earlier entries win
 * when multiple are present in [AstroConfiguration.styleOverrides]. Mirrors
 * the web alias list so partners that only provide `styleOverrides` (without
 * the typed [AstroStyle.backgroundColor]) still get a tinted native chrome.
 */
private val BG_TOP_LEVEL_ALIASES = listOf("bg_color", "backgroundColor", "background_color")
private val BG_NESTED_COLORS_ALIASES = listOf("surfaceBase")

/**
 * Aliases for the brand primary slot. See [BG_TOP_LEVEL_ALIASES]. The
 * `surface_highlight` / `surfaceHighlight` entries (and the matching nested
 * `colors.surfaceHighlight`) cover the `colors.surfaceHighlight` ≡
 * `primaryColor` parity with the web — partners that only declare the
 * specific surface token (instead of the brand primary) still get a tinted
 * native chrome. They are appended after the brand aliases so an explicit
 * `primary_color` / `primaryColor` continues to win when both are present.
 */
private val PRIMARY_TOP_LEVEL_ALIASES =
    listOf("primary_color", "primaryColor", "surface_highlight", "surfaceHighlight")
private val PRIMARY_NESTED_COLORS_ALIASES = listOf("primaryColor", "surfaceHighlight")

/**
 * Resolves the native chrome background color with the following precedence
 * (highest → lowest):
 *
 * 1. `styleOverrides` top-level aliases ([BG_TOP_LEVEL_ALIASES]), then
 *    `styleOverrides["colors"]` nested aliases ([BG_NESTED_COLORS_ALIASES]).
 * 2. Typed `style.surface.base` — the specific surface token. Wins over
 *    the brand-level typed field when both are set, since the specific
 *    token is closer to what the web actually paints (web parity:
 *    `colors.surfaceBase` ≡ `backgroundColor`).
 * 3. Typed `style.backgroundColor` — brand fallback.
 * 4. `null` — caller falls back to the default theme color.
 *
 * `styleOverrides` wins over the typed fields so the native chrome matches
 * what the web renders: on the web, `applyBridgeStyleOverridesFreeForm`
 * runs AFTER `applyBridgeStyleOverrides`, so free-form overrides effectively
 * supersede the typed brand fields. The native resolver mirrors that order
 * for parity.
 *
 * Each `styleOverrides` leaf may be a 6/8-digit hex [String], a Compose
 * [Color], or a raw `@ColorInt Int`. Invalid hex strings or unsupported
 * value types are skipped — this is a lookup helper, not a validator — and
 * the resolver continues falling back through the remaining steps.
 */
@ColorInt
internal fun resolveNativeBackgroundColor(
    style: AstroStyle?,
    styleOverrides: Map<String, Any>?,
): Int? = resolveNativeColor(
    typedSpecific = style?.surface?.base,
    typedBrand = style?.backgroundColor,
    styleOverrides = styleOverrides,
    topLevelAliases = BG_TOP_LEVEL_ALIASES,
    nestedColorsAliases = BG_NESTED_COLORS_ALIASES,
)

/**
 * Resolves the native chrome primary color with the following precedence
 * (highest → lowest):
 *
 * 1. `styleOverrides` top-level aliases ([PRIMARY_TOP_LEVEL_ALIASES]), then
 *    `styleOverrides["colors"]` nested aliases
 *    ([PRIMARY_NESTED_COLORS_ALIASES]).
 * 2. Typed `style.surface.highlight` — the specific surface token. Wins
 *    over the brand-level typed field when both are set (web parity:
 *    `colors.surfaceHighlight` ≡ `primaryColor`).
 * 3. Typed `style.primaryColor` — brand fallback.
 * 4. `null` — caller falls back to the default theme color.
 *
 * Same value-form rules as [resolveNativeBackgroundColor] (styleOverrides
 * leaves accept hex String, Compose Color, or raw @ColorInt Int; invalid
 * entries are skipped). The styleOverrides-wins ordering mirrors the web's
 * free-form-over-typed cascade.
 */
@ColorInt
internal fun resolveNativePrimaryColor(
    style: AstroStyle?,
    styleOverrides: Map<String, Any>?,
): Int? = resolveNativeColor(
    typedSpecific = style?.surface?.highlight,
    typedBrand = style?.primaryColor,
    styleOverrides = styleOverrides,
    topLevelAliases = PRIMARY_TOP_LEVEL_ALIASES,
    nestedColorsAliases = PRIMARY_NESTED_COLORS_ALIASES,
)

@ColorInt
private fun resolveNativeColor(
    @ColorInt typedSpecific: Int?,
    @ColorInt typedBrand: Int?,
    styleOverrides: Map<String, Any>?,
    topLevelAliases: List<String>,
    nestedColorsAliases: List<String>,
): Int? {
    if (!styleOverrides.isNullOrEmpty()) {
        topLevelAliases.forEach { key ->
            styleOverrides[key]?.let { coerceNativeColor(it) }?.let { return it }
        }
        (styleOverrides["colors"] as? Map<*, *>)?.let { nested ->
            nestedColorsAliases.forEach { key ->
                nested[key]?.let { coerceNativeColor(it) }?.let { return it }
            }
        }
    }
    return typedSpecific ?: typedBrand
}

/**
 * Coerces a free-form `styleOverrides` color leaf into a `@ColorInt Int`.
 * Accepts [String] (parsed via [fromAstroHex]), [Color] (Compose), and raw
 * [Int] (`@ColorInt`). Returns `null` for any other type or for unparsable
 * hex strings. Raw [Int] is unambiguous here because the caller already
 * knows the slot is a color — the same assumption does not hold for the
 * generic `styleOverrides` bag where the typed [Color] is preferred to
 * disambiguate from numeric tokens.
 */
@ColorInt
private fun coerceNativeColor(value: Any): Int? =
    when (value) {
        is Color -> value.toArgb()
        is Int -> value
        is String -> fromAstroHex(value)
        else -> null
    }

/**
 * The nested `styleOverrides` object whose color leaves theme the native
 * header chrome. Mirrors the typed [AstroStyle.header] field name exactly —
 * a single canonical camelCase shape, no top-level or snake_case aliases
 * (the header is native-only, so the web ignores this object key).
 */
private const val HEADER_KEY = "header"

/** Header background color leaf under [HEADER_KEY]. */
private const val HEADER_BG_KEY = "backgroundColor"

/** Header border color leaf under [HEADER_KEY]. */
private const val HEADER_BORDER_KEY = "borderColor"

/**
 * Resolves the native header background color with the following precedence
 * (highest → lowest):
 *
 * 1. `styleOverrides["header"]["backgroundColor"]` — hex [String], Compose
 *    [Color], or raw `@ColorInt Int`.
 * 2. Typed `style.header.backgroundColor`.
 * 3. `null` — caller falls back to the default theme color.
 *
 * `styleOverrides` wins over the typed field for parity with the brand
 * resolvers ([resolveNativeBackgroundColor] / [resolveNativePrimaryColor]),
 * keeping one precedence rule across all native chrome. Invalid hex strings
 * or unsupported value types are skipped — this is a lookup helper, not a
 * validator — and the resolver falls through to the typed field (not to
 * default). Malformed hex is already rejected earlier at
 * [AstroConfiguration.validate].
 */
@ColorInt
internal fun resolveNativeHeaderBackgroundColor(
    style: AstroStyle?,
    styleOverrides: Map<String, Any>?,
): Int? = resolveNativeHeaderColor(
    typed = style?.header?.backgroundColor,
    styleOverrides = styleOverrides,
    leafKey = HEADER_BG_KEY,
)

/**
 * Resolves the native header border color. Same precedence and value-form
 * rules as [resolveNativeHeaderBackgroundColor], reading the
 * `styleOverrides["header"]["borderColor"]` leaf and falling back to the
 * typed `style.header.borderColor`. Independent of the background resolution.
 */
@ColorInt
internal fun resolveNativeHeaderBorderColor(
    style: AstroStyle?,
    styleOverrides: Map<String, Any>?,
): Int? = resolveNativeHeaderColor(
    typed = style?.header?.borderColor,
    styleOverrides = styleOverrides,
    leafKey = HEADER_BORDER_KEY,
)

/**
 * Focused nested-`header`-map lookup. The generic [resolveNativeColor] core
 * is keyed on top-level + `colors`-nested aliases and does not fit a
 * `header`-nested lookup, so this helper reads
 * `(styleOverrides["header"] as? Map)?.get(leafKey)` and coerces it via the
 * shared [coerceNativeColor]; otherwise falls back to [typed].
 */
@ColorInt
private fun resolveNativeHeaderColor(
    @ColorInt typed: Int?,
    styleOverrides: Map<String, Any>?,
    leafKey: String,
): Int? {
    (styleOverrides?.get(HEADER_KEY) as? Map<*, *>)
        ?.get(leafKey)
        ?.let { coerceNativeColor(it) }
        ?.let { return it }
    return typed
}

// MARK: - Bridge serialization

/**
 * Builds a nested Map<String, Any> reflecting the non-null fields of this
 * AstroStyle, suitable for JSON serialization across the bridge. Grouped
 * color collections are flattened into a single `colors` map keyed by the
 * web's camelCase token name (e.g. `surfaceBase`, `textHighlight`,
 * `buttonPrimaryBackground`, `buttonIconPrimaryBackground`,
 * `buttonPillInfoBackground`, `inputBackground`). Returns null when no
 * field is set, so the bridge can emit `style: null` rather than an empty
 * object the web side has to disambiguate.
 */
internal fun AstroStyle.toBridgeMap(): Map<String, Any>? {
    val map = mutableMapOf<String, Any>()
    backgroundColor?.let { map["backgroundColor"] = it.toAstroHex() }
    primaryColor?.let { map["primaryColor"] = it.toAstroHex() }

    val colors = mutableMapOf<String, String>()
    surface?.flattenInto(colors, prefix = "surface")
    text?.flattenInto(colors, prefix = "text")
    border?.flattenInto(colors, prefix = "border")
    buttons?.colors?.flattenInto(colors, prefix = "button")
    buttonsIcon?.colors?.flattenInto(colors, prefix = "buttonIcon")
    buttonsPill?.colors?.flattenInto(colors, prefix = "buttonPill")
    inputs?.colors?.flattenInto(colors, prefix = "input")
    if (colors.isNotEmpty()) map["colors"] = colors.toMap()

    typography?.toBridgeMap()?.let { map["typography"] = it }
    buttons?.typography?.toBridgeMap()?.let { tp ->
        map["button"] = mapOf("typography" to tp)
    }
    buttonsIcon?.typography?.toBridgeMap()?.let { tp ->
        map["buttonIcon"] = mapOf("typography" to tp)
    }
    buttonsPill?.typography?.toBridgeMap()?.let { tp ->
        map["buttonPill"] = mapOf("typography" to tp)
    }
    inputs?.typography?.toBridgeMap()?.let { tp ->
        map["input"] = mapOf("typography" to tp)
    }

    header?.toBridgeMap()?.let { map["header"] = it }
    return map.takeIf { it.isNotEmpty() }
}

/**
 * Serializes a single font style leaf. Numeric size/leading/spacing values
 * are encoded as `"<value>px"` strings; [fontWeight] stays an integer.
 * Returns null when no field is set.
 */
internal fun AstroFontStyle.toBridgeMap(): Map<String, Any>? {
    val m = mutableMapOf<String, Any>()
    fontSize?.let { m["fontSize"] = pxString(it) }
    fontWeight?.let { m["fontWeight"] = it }
    lineHeight?.let { m["lineHeight"] = pxString(it) }
    letterSpacing?.let { m["letterSpacing"] = pxString(it) }
    fontFamily?.takeIf { it.isNotEmpty() }?.let { m["fontFamily"] = it }
    return m.takeIf { it.isNotEmpty() }
}

internal fun pxString(value: Float): String = numberToPxString(value)

/**
 * Number → `"<n>px"` formatter shared by the typed typography serializer
 * ([AstroFontStyle.toBridgeMap]) and the free-form [styleOverrides]
 * normalization path ([normalizeStyleOverridesForWire]).
 *
 * Whole values render without a decimal (`14 → "14px"`); fractional values
 * render with their digits and no trailing zeros (`0.5 → "0.5px"`,
 * `-0.2 → "-0.2px"`).
 *
 * [Boolean] is intentionally not a [Number] in Kotlin, so callers can pass
 * any numeric type (Int, Long, Float, Double) without worrying about a
 * `true → "1px"` foot-gun. Doubles route through their natural string form
 * to preserve precision Float would distort (e.g. `0.2`).
 */
internal fun numberToPxString(value: Number): String {
    val asDouble = value.toDouble()
    val asLong = asDouble.toLong()
    if (asLong.toDouble() == asDouble) {
        return "${asLong}px"
    }
    val raw = value.toString()
    val trimmed = if (raw.contains('.')) raw.trimEnd('0').trimEnd('.') else raw
    return "${trimmed}px"
}

/** Keys whose numeric values must be rewritten as `"<n>px"` on the wire. */
private val PX_TYPOGRAPHY_KEYS = setOf("fontSize", "lineHeight", "letterSpacing")

/**
 * Keys whose numeric values represent typography dimensions/weights, NOT
 * colors. Used to carve out the raw [Int] → `@ColorInt` hex conversion in
 * [normalizeOverridesValue]: a raw [Int] under one of these keys is treated
 * as a typography number (and either falls through to the existing px-key
 * handling or passes through as-is for `fontWeight`), while a raw [Int]
 * under any other key is interpreted as an `@ColorInt`.
 *
 * Superset of [PX_TYPOGRAPHY_KEYS] — adds `fontWeight`, which is a typed
 * integer (`100..900`) and must never be color-coerced.
 */
private val TYPOGRAPHY_NUMERIC_KEYS = PX_TYPOGRAPHY_KEYS + "fontWeight"

/**
 * Walks a free-form `styleOverrides` map and rewrites any [Number] value
 * under a typography px key ([PX_TYPOGRAPHY_KEYS]) as the equivalent
 * `"<n>px"` string, so the wire payload matches what the typed
 * [AstroFontStyle] path emits. Strings pass through unchanged (a partner
 * may already supply `"14px"`); [Boolean]s under a px key are left
 * untouched defensively (Booleans are not [Number] in Kotlin). Nested maps
 * and lists of maps are recursed. Validation runs separately on the
 * original shape via [validateStyleOverrides] — only the wire payload is
 * normalized.
 *
 * @return null when [overrides] is null or empty; otherwise a new map. The
 *   input is never mutated.
 */
internal fun normalizeStyleOverridesForWire(overrides: Map<String, Any>?): Map<String, Any>? {
    if (overrides.isNullOrEmpty()) return null
    return normalizeOverridesMap(overrides)
}

private fun normalizeOverridesMap(map: Map<String, Any>): Map<String, Any> {
    val out = LinkedHashMap<String, Any>(map.size)
    map.forEach { (key, value) ->
        out[key] = normalizeOverridesValue(value, key = key)
    }
    return out
}

private fun normalizeOverridesValue(value: Any, key: String): Any {
    val pxKey = key in PX_TYPOGRAPHY_KEYS
    val typographyNumericKey = key in TYPOGRAPHY_NUMERIC_KEYS
    return when {
        // Compose `Color` is a `@JvmInline value class` over ULong. When
        // stored in `Map<String, Any>` it is boxed to its wrapper, so an
        // `is Color` check discriminates cleanly from raw Number / String.
        // Convert to 8-digit (or 6-digit, when opaque) hex via the same
        // helper the typed color path uses, ensuring symmetric wire output.
        // Placed BEFORE the px-key/Number branch so a Compose Color under a
        // typography px key (defensive, unlikely) becomes a hex string
        // rather than crashing on numberToPxString.
        value is Color -> value.toArgb().toAstroHex()
        // Raw Int under a non-typography key is treated as `@ColorInt`. This
        // accepts the canonical Android idiom `android.graphics.Color.parseColor("#…")`
        // (which returns an Int) so partners don't need to wrap their existing
        // color literals just to pass through `styleOverrides`. Placed AFTER
        // the Compose Color branch (Color is a value class, not Int) and
        // BEFORE the px-key/Number branch so a typography px key still gets
        // the "<n>px" treatment. The typography numeric carve-out covers
        // `fontSize`/`lineHeight`/`letterSpacing` (numeric dimensions →
        // px-string) and `fontWeight` (typed integer 100..900).
        // Note: this also color-coerces raw Ints under partner-extension keys
        // that aren't typography — partners that need a non-color number
        // should wrap it in a String.
        value is Int && !typographyNumericKey -> value.toAstroHex()
        // Booleans are NOT Number in Kotlin, so a `Boolean` under a px key
        // falls through this branch and is preserved as-is.
        pxKey && value is Number -> numberToPxString(value)
        value is Map<*, *> -> {
            @Suppress("UNCHECKED_CAST")
            normalizeOverridesMap(value as Map<String, Any>)
        }
        value is List<*> -> value.mapNotNull { item ->
            when (item) {
                null -> null
                is Map<*, *> -> {
                    @Suppress("UNCHECKED_CAST")
                    normalizeOverridesMap(item as Map<String, Any>)
                }
                else -> item
            }
        }
        else -> value
    }
}

internal fun AstroTypography.toBridgeMap(): Map<String, Any>? {
    // Global font-family fallback at the typography bucket root. The web
    // applies it via the CSS variable `--ap-t-font-family`. Drop on null
    // OR empty string for parity with iOS so both platforms emit
    // byte-identical typography blobs. Per-token typography is no longer
    // exposed on the native API — partners that need per-token control
    // can still supply a free-form `typography` map through
    // `AstroConfiguration.styleOverrides`.
    val ff = fontFamily?.takeIf { it.isNotEmpty() } ?: return null
    return mapOf("fontFamily" to ff)
}

internal fun AstroButtonTypography.toBridgeMap(): Map<String, Any>? {
    val out = mutableMapOf<String, Any>()
    label?.toBridgeMap()?.let { out["label"] = it }
    return out.takeIf { it.isNotEmpty() }
}

internal fun AstroButtonIconTypography.toBridgeMap(): Map<String, Any>? {
    val out = mutableMapOf<String, Any>()
    label?.toBridgeMap()?.let { out["label"] = it }
    return out.takeIf { it.isNotEmpty() }
}

internal fun AstroButtonPillTypography.toBridgeMap(): Map<String, Any>? {
    val out = mutableMapOf<String, Any>()
    label?.toBridgeMap()?.let { out["label"] = it }
    return out.takeIf { it.isNotEmpty() }
}

internal fun AstroInputTypography.toBridgeMap(): Map<String, Any>? {
    val out = mutableMapOf<String, Any>()
    input?.toBridgeMap()?.let { out["input"] = it }
    label?.toBridgeMap()?.let { out["label"] = it }
    helper?.toBridgeMap()?.let { out["helper"] = it }
    placeholder?.toBridgeMap()?.let { out["placeholder"] = it }
    return out.takeIf { it.isNotEmpty() }
}

internal fun AstroHeaderStyle.toBridgeMap(): Map<String, Any>? {
    val map = mutableMapOf<String, Any>()
    backgroundColor?.let { map["backgroundColor"] = it.toAstroHex() }
    borderColor?.let { map["borderColor"] = it.toAstroHex() }
    borderWidth?.let { map["borderWidth"] = it }
    paddingHorizontal?.let { map["paddingHorizontal"] = it }
    paddingVertical?.let { map["paddingVertical"] = it }
    return map.takeIf { it.isNotEmpty() }
}

private fun MutableMap<String, String>.putColor(key: String, @ColorInt value: Int?) {
    val v = value ?: return
    put(key, v.toAstroHex())
}

private fun capitalize(s: String): String =
    if (s.isEmpty()) s else s[0].uppercaseChar() + s.substring(1)

private fun AstroSurfaceColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "base" to base, "baseHover" to baseHover, "baseActive" to baseActive,
        "secondary" to secondary, "secondaryHover" to secondaryHover, "secondaryActive" to secondaryActive,
        "terciary" to terciary, "terciaryHover" to terciaryHover, "terciaryActive" to terciaryActive,
        "muted" to muted, "mutedHover" to mutedHover, "mutedActive" to mutedActive,
        "contrast" to contrast, "contrastHover" to contrastHover, "contrastActive" to contrastActive,
        "invert" to invert, "invertHover" to invertHover, "invertActive" to invertActive,
        "white" to white, "whiteHover" to whiteHover, "whiteActive" to whiteActive,
        "highlight" to highlight, "highlightHover" to highlightHover, "highlightActive" to highlightActive,
        "highlightMuted" to highlightMuted, "highlightMutedHover" to highlightMutedHover,
        "highlightMutedActive" to highlightMutedActive,
        "error" to error, "errorHover" to errorHover, "errorActive" to errorActive,
        "errorMuted" to errorMuted, "errorMutedHover" to errorMutedHover,
        "errorMutedActive" to errorMutedActive, "errorLight" to errorLight,
        "warning" to warning, "warningHover" to warningHover, "warningActive" to warningActive,
        "warningMuted" to warningMuted, "warningMutedHover" to warningMutedHover,
        "warningMutedActive" to warningMutedActive, "warningLight" to warningLight,
        "success" to success, "successHover" to successHover, "successActive" to successActive,
        "successMuted" to successMuted, "successMutedHover" to successMutedHover,
        "successMutedActive" to successMutedActive, "successLight" to successLight,
        "accent" to accent, "accentHover" to accentHover, "accentActive" to accentActive,
        "accentMuted" to accentMuted, "accentMutedHover" to accentMutedHover,
        "accentMutedActive" to accentMutedActive, "accentLight" to accentLight,
        "lime" to lime, "limeMuted" to limeMuted,
        "overlay" to overlay, "black" to black,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroTextColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "black" to black, "white" to white, "base" to base,
        "muted" to muted, "mutedSecondary" to mutedSecondary, "faint" to faint,
        "invert" to invert, "highlight" to highlight,
        "error" to error, "accent" to accent, "warning" to warning, "success" to success,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroBorderColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "base" to base, "faint" to faint, "muted" to muted, "highlight" to highlight,
        "error" to error, "accent" to accent, "warning" to warning, "success" to success,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroButtonColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "primaryBackground" to primaryBackground,
        "primaryBackgroundHover" to primaryBackgroundHover,
        "primaryBackgroundFocus" to primaryBackgroundFocus,
        "primaryBackgroundDisabled" to primaryBackgroundDisabled,
        "primaryText" to primaryText,
        "primaryTextHover" to primaryTextHover,
        "primaryTextFocus" to primaryTextFocus,
        "primaryTextDisabled" to primaryTextDisabled,
        "primaryLoaderColor" to primaryLoaderColor,
        "primaryLoaderColorDisabled" to primaryLoaderColorDisabled,
        "primaryFocusOutlineColor" to primaryFocusOutlineColor,
        "secondaryBackground" to secondaryBackground,
        "secondaryBackgroundHover" to secondaryBackgroundHover,
        "secondaryBackgroundFocus" to secondaryBackgroundFocus,
        "secondaryBackgroundDisabled" to secondaryBackgroundDisabled,
        "secondaryText" to secondaryText,
        "secondaryTextHover" to secondaryTextHover,
        "secondaryTextFocus" to secondaryTextFocus,
        "secondaryTextDisabled" to secondaryTextDisabled,
        "secondaryLoaderColor" to secondaryLoaderColor,
        "secondaryLoaderColorDisabled" to secondaryLoaderColorDisabled,
        "secondaryFocusOutlineColor" to secondaryFocusOutlineColor,
        "tertiaryBackground" to tertiaryBackground,
        "tertiaryBackgroundHover" to tertiaryBackgroundHover,
        "tertiaryBackgroundFocus" to tertiaryBackgroundFocus,
        "tertiaryBackgroundDisabled" to tertiaryBackgroundDisabled,
        "tertiaryText" to tertiaryText,
        "tertiaryTextHover" to tertiaryTextHover,
        "tertiaryTextFocus" to tertiaryTextFocus,
        "tertiaryTextDisabled" to tertiaryTextDisabled,
        "tertiaryLoaderColor" to tertiaryLoaderColor,
        "tertiaryLoaderColorDisabled" to tertiaryLoaderColorDisabled,
        "tertiaryFocusOutlineColor" to tertiaryFocusOutlineColor,
        "grayBackground" to grayBackground,
        "grayBackgroundHover" to grayBackgroundHover,
        "grayBackgroundFocus" to grayBackgroundFocus,
        "grayBackgroundDisabled" to grayBackgroundDisabled,
        "grayText" to grayText,
        "grayTextHover" to grayTextHover,
        "grayTextFocus" to grayTextFocus,
        "grayTextDisabled" to grayTextDisabled,
        "grayLoaderColor" to grayLoaderColor,
        "grayLoaderColorDisabled" to grayLoaderColorDisabled,
        "grayFocusOutlineColor" to grayFocusOutlineColor,
        "mutedBackground" to mutedBackground,
        "mutedBackgroundHover" to mutedBackgroundHover,
        "mutedBackgroundFocus" to mutedBackgroundFocus,
        "mutedBackgroundDisabled" to mutedBackgroundDisabled,
        "mutedText" to mutedText,
        "mutedTextHover" to mutedTextHover,
        "mutedTextFocus" to mutedTextFocus,
        "mutedTextDisabled" to mutedTextDisabled,
        "mutedLoaderColor" to mutedLoaderColor,
        "mutedLoaderColorDisabled" to mutedLoaderColorDisabled,
        "mutedFocusOutlineColor" to mutedFocusOutlineColor,
        "transparentBackground" to transparentBackground,
        "transparentBackgroundHover" to transparentBackgroundHover,
        "transparentBackgroundFocus" to transparentBackgroundFocus,
        "transparentBackgroundDisabled" to transparentBackgroundDisabled,
        "transparentText" to transparentText,
        "transparentTextHover" to transparentTextHover,
        "transparentTextFocus" to transparentTextFocus,
        "transparentTextDisabled" to transparentTextDisabled,
        "transparentLoaderColor" to transparentLoaderColor,
        "transparentLoaderColorDisabled" to transparentLoaderColorDisabled,
        "transparentFocusOutlineColor" to transparentFocusOutlineColor,
        "transparentWhiteBackground" to transparentWhiteBackground,
        "transparentWhiteBackgroundHover" to transparentWhiteBackgroundHover,
        "transparentWhiteBackgroundFocus" to transparentWhiteBackgroundFocus,
        "transparentWhiteBackgroundDisabled" to transparentWhiteBackgroundDisabled,
        "transparentWhiteText" to transparentWhiteText,
        "transparentWhiteTextHover" to transparentWhiteTextHover,
        "transparentWhiteTextFocus" to transparentWhiteTextFocus,
        "transparentWhiteTextDisabled" to transparentWhiteTextDisabled,
        "transparentWhiteLoaderColor" to transparentWhiteLoaderColor,
        "transparentWhiteLoaderColorDisabled" to transparentWhiteLoaderColorDisabled,
        "transparentWhiteFocusOutlineColor" to transparentWhiteFocusOutlineColor,
        "errorMutedBackground" to errorMutedBackground,
        "errorMutedBackgroundHover" to errorMutedBackgroundHover,
        "errorMutedBackgroundFocus" to errorMutedBackgroundFocus,
        "errorMutedBackgroundDisabled" to errorMutedBackgroundDisabled,
        "errorMutedText" to errorMutedText,
        "errorMutedTextHover" to errorMutedTextHover,
        "errorMutedTextFocus" to errorMutedTextFocus,
        "errorMutedTextDisabled" to errorMutedTextDisabled,
        "errorMutedLoaderColor" to errorMutedLoaderColor,
        "errorMutedLoaderColorDisabled" to errorMutedLoaderColorDisabled,
        "errorMutedFocusOutlineColor" to errorMutedFocusOutlineColor,
        "errorBackground" to errorBackground,
        "errorBackgroundHover" to errorBackgroundHover,
        "errorBackgroundFocus" to errorBackgroundFocus,
        "errorBackgroundDisabled" to errorBackgroundDisabled,
        "errorText" to errorText,
        "errorTextHover" to errorTextHover,
        "errorTextFocus" to errorTextFocus,
        "errorTextDisabled" to errorTextDisabled,
        "errorLoaderColor" to errorLoaderColor,
        "errorLoaderColorDisabled" to errorLoaderColorDisabled,
        "errorFocusOutlineColor" to errorFocusOutlineColor,
        "warningMutedBackground" to warningMutedBackground,
        "warningMutedBackgroundHover" to warningMutedBackgroundHover,
        "warningMutedBackgroundFocus" to warningMutedBackgroundFocus,
        "warningMutedBackgroundDisabled" to warningMutedBackgroundDisabled,
        "warningMutedText" to warningMutedText,
        "warningMutedTextHover" to warningMutedTextHover,
        "warningMutedTextFocus" to warningMutedTextFocus,
        "warningMutedTextDisabled" to warningMutedTextDisabled,
        "warningMutedLoaderColor" to warningMutedLoaderColor,
        "warningMutedLoaderColorDisabled" to warningMutedLoaderColorDisabled,
        "warningMutedFocusOutlineColor" to warningMutedFocusOutlineColor,
        "warningBackground" to warningBackground,
        "warningBackgroundHover" to warningBackgroundHover,
        "warningBackgroundFocus" to warningBackgroundFocus,
        "warningBackgroundDisabled" to warningBackgroundDisabled,
        "warningText" to warningText,
        "warningTextHover" to warningTextHover,
        "warningTextFocus" to warningTextFocus,
        "warningTextDisabled" to warningTextDisabled,
        "warningLoaderColor" to warningLoaderColor,
        "warningLoaderColorDisabled" to warningLoaderColorDisabled,
        "warningFocusOutlineColor" to warningFocusOutlineColor,
        "whiteBackground" to whiteBackground,
        "whiteBackgroundHover" to whiteBackgroundHover,
        "whiteBackgroundFocus" to whiteBackgroundFocus,
        "whiteBackgroundDisabled" to whiteBackgroundDisabled,
        "whiteText" to whiteText,
        "whiteTextHover" to whiteTextHover,
        "whiteTextFocus" to whiteTextFocus,
        "whiteTextDisabled" to whiteTextDisabled,
        "whiteLoaderColor" to whiteLoaderColor,
        "whiteLoaderColorDisabled" to whiteLoaderColorDisabled,
        "whiteFocusOutlineColor" to whiteFocusOutlineColor,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroButtonIconColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "primaryBackground" to primaryBackground,
        "primaryBackgroundHover" to primaryBackgroundHover,
        "primaryBackgroundFocus" to primaryBackgroundFocus,
        "primaryBackgroundDisabled" to primaryBackgroundDisabled,
        "primaryIconColor" to primaryIconColor,
        "primaryIconColorDisabled" to primaryIconColorDisabled,
        "primaryText" to primaryText,
        "primaryTextDisabled" to primaryTextDisabled,
        "primaryLoaderColor" to primaryLoaderColor,
        "primaryLoaderColorDisabled" to primaryLoaderColorDisabled,
        "primaryFocusOutlineColor" to primaryFocusOutlineColor,
        "secondaryBackground" to secondaryBackground,
        "secondaryBackgroundHover" to secondaryBackgroundHover,
        "secondaryBackgroundFocus" to secondaryBackgroundFocus,
        "secondaryBackgroundDisabled" to secondaryBackgroundDisabled,
        "secondaryIconColor" to secondaryIconColor,
        "secondaryIconColorDisabled" to secondaryIconColorDisabled,
        "secondaryText" to secondaryText,
        "secondaryTextDisabled" to secondaryTextDisabled,
        "secondaryLoaderColor" to secondaryLoaderColor,
        "secondaryLoaderColorDisabled" to secondaryLoaderColorDisabled,
        "secondaryFocusOutlineColor" to secondaryFocusOutlineColor,
        "tertiaryBackground" to tertiaryBackground,
        "tertiaryBackgroundHover" to tertiaryBackgroundHover,
        "tertiaryBackgroundFocus" to tertiaryBackgroundFocus,
        "tertiaryBackgroundDisabled" to tertiaryBackgroundDisabled,
        "tertiaryIconColor" to tertiaryIconColor,
        "tertiaryIconColorDisabled" to tertiaryIconColorDisabled,
        "tertiaryText" to tertiaryText,
        "tertiaryTextDisabled" to tertiaryTextDisabled,
        "tertiaryLoaderColor" to tertiaryLoaderColor,
        "tertiaryLoaderColorDisabled" to tertiaryLoaderColorDisabled,
        "tertiaryFocusOutlineColor" to tertiaryFocusOutlineColor,
        "grayBackground" to grayBackground,
        "grayBackgroundHover" to grayBackgroundHover,
        "grayBackgroundFocus" to grayBackgroundFocus,
        "grayBackgroundDisabled" to grayBackgroundDisabled,
        "grayIconColor" to grayIconColor,
        "grayIconColorDisabled" to grayIconColorDisabled,
        "grayText" to grayText,
        "grayTextDisabled" to grayTextDisabled,
        "grayLoaderColor" to grayLoaderColor,
        "grayLoaderColorDisabled" to grayLoaderColorDisabled,
        "grayFocusOutlineColor" to grayFocusOutlineColor,
        "mutedBackground" to mutedBackground,
        "mutedBackgroundHover" to mutedBackgroundHover,
        "mutedBackgroundFocus" to mutedBackgroundFocus,
        "mutedBackgroundDisabled" to mutedBackgroundDisabled,
        "mutedIconColor" to mutedIconColor,
        "mutedIconColorDisabled" to mutedIconColorDisabled,
        "mutedText" to mutedText,
        "mutedTextDisabled" to mutedTextDisabled,
        "mutedLoaderColor" to mutedLoaderColor,
        "mutedLoaderColorDisabled" to mutedLoaderColorDisabled,
        "mutedFocusOutlineColor" to mutedFocusOutlineColor,
        "transparentBackground" to transparentBackground,
        "transparentBackgroundHover" to transparentBackgroundHover,
        "transparentBackgroundFocus" to transparentBackgroundFocus,
        "transparentBackgroundDisabled" to transparentBackgroundDisabled,
        "transparentIconColor" to transparentIconColor,
        "transparentIconColorDisabled" to transparentIconColorDisabled,
        "transparentText" to transparentText,
        "transparentTextDisabled" to transparentTextDisabled,
        "transparentLoaderColor" to transparentLoaderColor,
        "transparentLoaderColorDisabled" to transparentLoaderColorDisabled,
        "transparentFocusOutlineColor" to transparentFocusOutlineColor,
        "transparentWhiteBackground" to transparentWhiteBackground,
        "transparentWhiteBackgroundHover" to transparentWhiteBackgroundHover,
        "transparentWhiteBackgroundFocus" to transparentWhiteBackgroundFocus,
        "transparentWhiteBackgroundDisabled" to transparentWhiteBackgroundDisabled,
        "transparentWhiteIconColor" to transparentWhiteIconColor,
        "transparentWhiteIconColorDisabled" to transparentWhiteIconColorDisabled,
        "transparentWhiteText" to transparentWhiteText,
        "transparentWhiteTextDisabled" to transparentWhiteTextDisabled,
        "transparentWhiteLoaderColor" to transparentWhiteLoaderColor,
        "transparentWhiteLoaderColorDisabled" to transparentWhiteLoaderColorDisabled,
        "transparentWhiteFocusOutlineColor" to transparentWhiteFocusOutlineColor,
        "errorMutedBackground" to errorMutedBackground,
        "errorMutedBackgroundHover" to errorMutedBackgroundHover,
        "errorMutedBackgroundFocus" to errorMutedBackgroundFocus,
        "errorMutedBackgroundDisabled" to errorMutedBackgroundDisabled,
        "errorMutedIconColor" to errorMutedIconColor,
        "errorMutedIconColorDisabled" to errorMutedIconColorDisabled,
        "errorMutedText" to errorMutedText,
        "errorMutedTextDisabled" to errorMutedTextDisabled,
        "errorMutedLoaderColor" to errorMutedLoaderColor,
        "errorMutedLoaderColorDisabled" to errorMutedLoaderColorDisabled,
        "errorMutedFocusOutlineColor" to errorMutedFocusOutlineColor,
        "errorBackground" to errorBackground,
        "errorBackgroundHover" to errorBackgroundHover,
        "errorBackgroundFocus" to errorBackgroundFocus,
        "errorBackgroundDisabled" to errorBackgroundDisabled,
        "errorIconColor" to errorIconColor,
        "errorIconColorDisabled" to errorIconColorDisabled,
        "errorText" to errorText,
        "errorTextDisabled" to errorTextDisabled,
        "errorLoaderColor" to errorLoaderColor,
        "errorLoaderColorDisabled" to errorLoaderColorDisabled,
        "errorFocusOutlineColor" to errorFocusOutlineColor,
        "warningMutedBackground" to warningMutedBackground,
        "warningMutedBackgroundHover" to warningMutedBackgroundHover,
        "warningMutedBackgroundFocus" to warningMutedBackgroundFocus,
        "warningMutedBackgroundDisabled" to warningMutedBackgroundDisabled,
        "warningMutedIconColor" to warningMutedIconColor,
        "warningMutedIconColorDisabled" to warningMutedIconColorDisabled,
        "warningMutedText" to warningMutedText,
        "warningMutedTextDisabled" to warningMutedTextDisabled,
        "warningMutedLoaderColor" to warningMutedLoaderColor,
        "warningMutedLoaderColorDisabled" to warningMutedLoaderColorDisabled,
        "warningMutedFocusOutlineColor" to warningMutedFocusOutlineColor,
        "warningBackground" to warningBackground,
        "warningBackgroundHover" to warningBackgroundHover,
        "warningBackgroundFocus" to warningBackgroundFocus,
        "warningBackgroundDisabled" to warningBackgroundDisabled,
        "warningIconColor" to warningIconColor,
        "warningIconColorDisabled" to warningIconColorDisabled,
        "warningText" to warningText,
        "warningTextDisabled" to warningTextDisabled,
        "warningLoaderColor" to warningLoaderColor,
        "warningLoaderColorDisabled" to warningLoaderColorDisabled,
        "warningFocusOutlineColor" to warningFocusOutlineColor,
        "whiteBackground" to whiteBackground,
        "whiteBackgroundHover" to whiteBackgroundHover,
        "whiteBackgroundFocus" to whiteBackgroundFocus,
        "whiteBackgroundDisabled" to whiteBackgroundDisabled,
        "whiteIconColor" to whiteIconColor,
        "whiteIconColorDisabled" to whiteIconColorDisabled,
        "whiteText" to whiteText,
        "whiteTextDisabled" to whiteTextDisabled,
        "whiteLoaderColor" to whiteLoaderColor,
        "whiteLoaderColorDisabled" to whiteLoaderColorDisabled,
        "whiteFocusOutlineColor" to whiteFocusOutlineColor,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroButtonPillColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "infoBackground" to infoBackground,
        "infoBackgroundHover" to infoBackgroundHover,
        "infoBorder" to infoBorder,
        "infoText" to infoText,
        "infoFocusOutlineColor" to infoFocusOutlineColor,
        "infoAltBackground" to infoAltBackground,
        "infoAltBackgroundHover" to infoAltBackgroundHover,
        "infoAltBorder" to infoAltBorder,
        "infoAltText" to infoAltText,
        "infoAltFocusOutlineColor" to infoAltFocusOutlineColor,
        "successBackground" to successBackground,
        "successBackgroundHover" to successBackgroundHover,
        "successBorder" to successBorder,
        "successText" to successText,
        "successFocusOutlineColor" to successFocusOutlineColor,
        "successMutedBackground" to successMutedBackground,
        "successMutedBackgroundHover" to successMutedBackgroundHover,
        "successMutedBorder" to successMutedBorder,
        "successMutedText" to successMutedText,
        "successMutedFocusOutlineColor" to successMutedFocusOutlineColor,
        "errorBackground" to errorBackground,
        "errorBackgroundHover" to errorBackgroundHover,
        "errorBorder" to errorBorder,
        "errorText" to errorText,
        "errorFocusOutlineColor" to errorFocusOutlineColor,
        "errorMutedBackground" to errorMutedBackground,
        "errorMutedBackgroundHover" to errorMutedBackgroundHover,
        "errorMutedBorder" to errorMutedBorder,
        "errorMutedText" to errorMutedText,
        "errorMutedFocusOutlineColor" to errorMutedFocusOutlineColor,
        "warningBackground" to warningBackground,
        "warningBackgroundHover" to warningBackgroundHover,
        "warningBorder" to warningBorder,
        "warningText" to warningText,
        "warningFocusOutlineColor" to warningFocusOutlineColor,
        "warningMutedBackground" to warningMutedBackground,
        "warningMutedBackgroundHover" to warningMutedBackgroundHover,
        "warningMutedBorder" to warningMutedBorder,
        "warningMutedText" to warningMutedText,
        "warningMutedFocusOutlineColor" to warningMutedFocusOutlineColor,
        "neutralBackground" to neutralBackground,
        "neutralBackgroundHover" to neutralBackgroundHover,
        "neutralBorder" to neutralBorder,
        "neutralText" to neutralText,
        "neutralFocusOutlineColor" to neutralFocusOutlineColor,
        "neutralMutedBackground" to neutralMutedBackground,
        "neutralMutedBackgroundHover" to neutralMutedBackgroundHover,
        "neutralMutedBorder" to neutralMutedBorder,
        "neutralMutedText" to neutralMutedText,
        "neutralMutedFocusOutlineColor" to neutralMutedFocusOutlineColor,
        "pearlBackground" to pearlBackground,
        "pearlBackgroundHover" to pearlBackgroundHover,
        "pearlBorder" to pearlBorder,
        "pearlText" to pearlText,
        "pearlFocusOutlineColor" to pearlFocusOutlineColor,
        "pearlMutedBackground" to pearlMutedBackground,
        "pearlMutedBackgroundHover" to pearlMutedBackgroundHover,
        "pearlMutedBorder" to pearlMutedBorder,
        "pearlMutedText" to pearlMutedText,
        "pearlMutedFocusOutlineColor" to pearlMutedFocusOutlineColor,
        "highlightBackground" to highlightBackground,
        "highlightBackgroundHover" to highlightBackgroundHover,
        "highlightBorder" to highlightBorder,
        "highlightText" to highlightText,
        "highlightFocusOutlineColor" to highlightFocusOutlineColor,
        "highlightMutedBackground" to highlightMutedBackground,
        "highlightMutedBackgroundHover" to highlightMutedBackgroundHover,
        "highlightMutedBorder" to highlightMutedBorder,
        "highlightMutedText" to highlightMutedText,
        "highlightMutedFocusOutlineColor" to highlightMutedFocusOutlineColor,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

private fun AstroInputColors.flattenInto(out: MutableMap<String, String>, prefix: String) {
    val pairs = listOf(
        "background" to background,
        "backgroundHover" to backgroundHover,
        "backgroundFocus" to backgroundFocus,
        "backgroundActive" to backgroundActive,
        "backgroundFilled" to backgroundFilled,
        "backgroundDisabled" to backgroundDisabled,
        "backgroundError" to backgroundError,
        "backgroundSuccess" to backgroundSuccess,
        "border" to border,
        "borderHover" to borderHover,
        "borderFocus" to borderFocus,
        "borderActive" to borderActive,
        "borderFilled" to borderFilled,
        "borderDisabled" to borderDisabled,
        "borderError" to borderError,
        "borderSuccess" to borderSuccess,
        "text" to text,
        "textHover" to textHover,
        "textDisabled" to textDisabled,
        "placeholder" to placeholder,
        "placeholderHover" to placeholderHover,
        "label" to label,
        "helper" to helper,
        "errorMessage" to errorMessage,
        "successMessage" to successMessage,
        "icon" to icon,
        "iconHover" to iconHover,
        "iconFocus" to iconFocus,
        "iconDisabled" to iconDisabled,
        "caret" to caret,
        "focusOutlineColor" to focusOutlineColor,
        "iconBackground" to iconBackground,
        "iconBackgroundHover" to iconBackgroundHover,
        "iconBackgroundFocus" to iconBackgroundFocus,
        "iconBackgroundDisabled" to iconBackgroundDisabled,
        "dropdownBackground" to dropdownBackground,
        "dropdownBorder" to dropdownBorder,
        "dropdownOptionBackground" to dropdownOptionBackground,
        "dropdownOptionBackgroundHover" to dropdownOptionBackgroundHover,
        "dropdownOptionBackgroundSelected" to dropdownOptionBackgroundSelected,
        "dropdownOptionBackgroundDisabled" to dropdownOptionBackgroundDisabled,
        "dropdownOptionText" to dropdownOptionText,
        "dropdownOptionTextHover" to dropdownOptionTextHover,
        "dropdownOptionTextSelected" to dropdownOptionTextSelected,
        "dropdownOptionTextDisabled" to dropdownOptionTextDisabled,
        "dropdownOptionIcon" to dropdownOptionIcon,
        "dropdownEmptyMessage" to dropdownEmptyMessage,
        "phoneDropdownBackground" to phoneDropdownBackground,
        "phoneDropdownOverlayBackground" to phoneDropdownOverlayBackground,
        "phoneDropdownHeaderBackground" to phoneDropdownHeaderBackground,
        "phoneDropdownItemBackground" to phoneDropdownItemBackground,
        "phoneDropdownItemBackgroundHover" to phoneDropdownItemBackgroundHover,
        "phoneDropdownItemBackgroundActive" to phoneDropdownItemBackgroundActive,
        "phoneDropdownItemText" to phoneDropdownItemText,
        "phoneDropdownItemTextSecondary" to phoneDropdownItemTextSecondary,
    )
    pairs.forEach { (k, v) -> out.putColor(prefix + capitalize(k), v) }
}

// MARK: - Hex validation

private val HEX_COLOR_REGEX = Regex("^#?[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$")

/**
 * Returns true when [value] is a 6- or 8-digit hex color (with optional
 * leading '#'). The 8-digit form encodes an alpha suffix (`#RRGGBBAA`).
 * Single source of truth for hex validation across the SDK.
 */
internal fun isValidHexColor(value: String): Boolean = HEX_COLOR_REGEX.matches(value)

private fun requireValidHex(value: String?, fieldLabel: String) {
    val v = value?.takeIf { it.isNotBlank() } ?: return
    if (!isValidHexColor(v)) {
        throw AstroConfigurationException(
            "Invalid $fieldLabel '$v': expected 6- or 8-digit hex (e.g. '#1a2b3c' or '#1a2b3cff')",
        )
    }
}

@Throws(AstroConfigurationException::class)
internal fun AstroStyle.validate() {
    // Color fields are now typed @ColorInt Int? — no malformed value can
    // exist at the type level, so per-color requireValidHex calls are gone.
    header?.validate()

    // Typography slots are validated through the typed walk (not through the
    // flat colors map) because each leaf field has its own type rule. The
    // global typography surface only exposes a fontFamily string, which has
    // no shape to validate beyond null/empty; the typed walk skips it and
    // dives straight into per-component slots.
    buttons?.typography?.let { tp ->
        tp.label?.validate("style.buttons.typography.label")
    }
    buttonsIcon?.typography?.let { tp ->
        tp.label?.validate("style.buttonsIcon.typography.label")
    }
    buttonsPill?.typography?.let { tp ->
        tp.label?.validate("style.buttonsPill.typography.label")
    }
    inputs?.typography?.let { tp ->
        tp.input?.validate("style.inputs.typography.input")
        tp.label?.validate("style.inputs.typography.label")
        tp.helper?.validate("style.inputs.typography.helper")
        tp.placeholder?.validate("style.inputs.typography.placeholder")
    }
}

// MARK: - Typography validation

private fun requireNonNegative(value: Float?, path: String) {
    val v = value ?: return
    if (v < 0f || v.isNaN() || v.isInfinite()) {
        throw AstroConfigurationException(
            "Invalid $path '$v': expected a non-negative number (px).",
        )
    }
}

private fun requireFiniteFloat(value: Float?, path: String) {
    val v = value ?: return
    if (v.isNaN() || v.isInfinite()) {
        throw AstroConfigurationException(
            "Invalid $path '$v': expected a finite number (px).",
        )
    }
}

private fun requireFontWeight(value: Int?, path: String) {
    val v = value ?: return
    if (v < 100 || v > 900) {
        throw AstroConfigurationException(
            "Invalid $path '$v': expected an integer in 100..900.",
        )
    }
}

@Throws(AstroConfigurationException::class)
internal fun AstroFontStyle.validate(path: String) {
    requireNonNegative(fontSize, "$path.fontSize")
    requireFontWeight(fontWeight, "$path.fontWeight")
    requireNonNegative(lineHeight, "$path.lineHeight")
    requireFiniteFloat(letterSpacing, "$path.letterSpacing")
}

@Throws(AstroConfigurationException::class)
internal fun AstroHeaderStyle.validate() {
    // Header color fields are now typed @ColorInt Int? — no per-field hex
    // check is needed.
}

/**
 * Validates a free-form `styleOverrides` map. The map is a partner-facing
 * loose bag that can carry colors and typography side-by-side, so dispatch
 * by key:
 *
 * - `fontSize` / `lineHeight` numeric → range-check `>= 0` (throws).
 * - `letterSpacing` numeric → any finite value accepted (throws on NaN/Inf).
 * - `fontWeight` numeric → range-check `100..900` (throws).
 * - any other String leaf → must be a 6- or 8-digit hex color (throws).
 * - other key/value shapes → ignored (warn-only would log; we silently
 *   tolerate them so partners can stash bookkeeping fields).
 *
 * Keys are not normalized — they pass through to the web as-is, which is
 * responsible for interpreting snake/camel mapping, `colors` vs root
 * placement, and precedence vs the typed [AstroStyle].
 */
@Throws(AstroConfigurationException::class)
internal fun validateStyleOverrides(overrides: Map<String, Any>?, path: String = "styleOverrides") {
    if (overrides.isNullOrEmpty()) return
    for ((key, value) in overrides) {
        val childPath = "$path.$key"
        when (value) {
            is Map<*, *> -> {
                @Suppress("UNCHECKED_CAST")
                validateStyleOverrides(value as Map<String, Any>, childPath)
            }
            is Number -> {
                val asFloat = value.toFloat()
                when (key) {
                    "fontSize", "lineHeight" -> requireNonNegative(asFloat, childPath)
                    "letterSpacing" -> requireFiniteFloat(asFloat, childPath)
                    "fontWeight" -> requireFontWeight(value.toInt(), childPath)
                    else -> { /* unknown numeric key — pass through */ }
                }
            }
            is String -> {
                when (key) {
                    // Typography string leaves are not expected; legacy
                    // partners might still send "14px" strings. Accept any
                    // non-blank string for typography keys without further
                    // validation so we don't break free-form usage.
                    "fontSize", "lineHeight", "letterSpacing", "fontWeight", "fontFamily" -> {
                        /* warn-only: pass through */
                    }
                    else -> requireValidHex(value, childPath)
                }
            }
            // Compose Color leaves are a typed alternative to hex strings for
            // color keys — by definition valid, no validation needed. The
            // normalizer converts them to hex on the wire.
            is Color -> { /* accept as-is */ }
            else -> { /* booleans, nulls, etc. pass through untouched */ }
        }
    }
}

internal fun parseHexColor(hex: String): Color? {
    val sanitized = hex.trimStart('#')
    if (sanitized.length != 6) return null
    val colorLong = sanitized.toLongOrNull(16) ?: return null
    return Color(0xFF000000 or colorLong)
}
