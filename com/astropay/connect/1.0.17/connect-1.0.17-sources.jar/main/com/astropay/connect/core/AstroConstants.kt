package com.astropay.connect.core

/**
 * Constants used throughout the AstroPay Connect SDK.
 */
internal object AstroConstants {
    const val SDK_VERSION = "1.0.17"
    const val INTERNAL_SDK_VERSION = "3"
    const val PLATFORM = "android"

    object Network {
        object URLs {
            const val PRODUCTION = "https://web-app-connect.astropay.com/"
            const val SANDBOX = "https://web-app-connect-stg.astropay.com/"
            const val TESTING = "https://web-app-connect.testingap.com/"
            const val LOCAL_PORT = "3000"
        }
    }

    /**
     * JavaScript bridge configuration.
     */
    object Bridge {
        const val OBJECT_NAME = "AstroPayBridge"
        const val PRELOADER_OBJECT_NAME = "AstroPreloaderBridge"
        const val SDK_HEADER_NAME = "X-Astro-SDK"
        const val SDK_HEADER_VALUE = "AstroPayConnect/Android-$SDK_VERSION"

        object MessageHandlers {
            const val NOTIFY_LOADED = "notifyLoaded"
            const val NOTIFY_CLOSE = "notifyClose"
            const val NOTIFY_ERROR = "notifyError"
            const val NOTIFY_EVENT = "notifyEvent"
            const val HAS_CAMERA_PERMISSION = "hasCameraPermission"
            const val REQUEST_CAMERA_PERMISSIONS = "requestCameraPermissions"

            // Biometric 2FA
            const val CHECK_BIOMETRIC_AVAILABILITY = "checkBiometricAvailability"
            const val DELETE_SEED = "deleteSeed"
            const val GET_SEED = "getSeed"
            const val REGISTER_DEVICE = "registerDevice"
            const val GENERATE_TOTP = "generateTOTP"

            // Native KYC
            const val START_NATIVE_KYC = "startNativeKyc"
            // QR scanner
            const val OPEN_QR_SCANNER = "openQrScanner"
        }

        object Callbacks {
            const val CAMERA_PERMISSION = "window.AstroPayBridge.cameraPermissionCallback"

            // Biometric 2FA
            const val BIOMETRICS_RESULT = "window.AstroPayBridge.biometricsResultCallback"
            const val CHECK_BIOMETRIC_RESULT = "window.AstroPayBridge.checkBiometricResultCallback"
            const val DELETE_SEED_RESULT = "window.AstroPayBridge.deleteSeedResultCallback"
            const val GET_SEED_RESULT = "window.AstroPayBridge.getSeedResultCallback"
            const val REGISTER_DEVICE_RESULT = "window.AstroPayBridge.registerDeviceResultCallback"
            const val GENERATE_TOTP_RESULT = "window.AstroPayBridge.generateTOTPResultCallback"

            // QR scanner
            const val QR_SCAN_RESULT = "window.AstroPayBridge.qrScanResultCallback"
        }
    }

    /**
     * Timeout values.
     */
    object Timeouts {
        const val LOAD_TIMEOUT_MS = 35000L

        /**
         * Native-KYC (CAF) watchdog backstop: 5 minutes — long enough for a slow user to finish
         * document + liveness, still recovers a genuinely hung CAF callback. Native-KYC-only tunable
         * placed here for parity with iOS and consistency with [LOAD_TIMEOUT_MS]; names no CAF types.
         */
        const val NATIVE_KYC_WATCHDOG_MS = 300_000L
    }

    /**
     * Logging configuration.
     */
    object Logging {
        const val TAG = "AstroConnect"
        const val SUBSYSTEM = "com.astropay.connect"
        const val PREFIX = "APC ::"

        object Categories {
            const val BRIDGE = "Bridge"
        }
    }

    /**
     * Asset URLs for SDK resources (e.g. issuer logos).
     * PROD and STAGING share the same base URL.
     */
    object Assets {
        const val ISSUER_LOGO_BASE_PROD = "https://rs.astropay.com/img/platform/issuers_logo"
        const val ISSUER_LOGO_BASE_TESTING = "https://rs-tst.astropay.com/img/platform/issuers_logo"
    }

    /**
     * Biometric grace period configuration (in seconds).
     */
    object BiometricGracePeriod {
        const val MIN_SECONDS = 0L
        const val MAX_SECONDS = 600L
        const val DEFAULT_SECONDS = 120L
    }

    /**
     * URL query parameters.
     */
    object QueryParams {
        const val VERSION = "v"
        const val THEME = "theme"
        const val LANGUAGE = "language"
        const val ACCESS_TOKEN = "access_token"
        const val PRELOAD = "preload"
        const val BACKGROUND_COLOR = "bg_color"
        const val PRIMARY_COLOR = "primary_color"
    }

    /**
     * Signals used by the web during preload. The web sets the URL hash
     * when all chunks have finished downloading.
     */
    object Preload {
        const val DONE_HASH = "preload-done"
        const val TIMEOUT_MS = 30_000L
    }
}
