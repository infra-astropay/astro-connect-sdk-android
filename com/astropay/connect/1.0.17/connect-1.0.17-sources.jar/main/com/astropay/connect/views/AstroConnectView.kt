package com.astropay.connect.views

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.astropay.connect.AstroConnectController
import com.astropay.connect.AstroPreloadSession
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConfigurationException
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroEnvironment
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroEvent
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.AstroQrScanResult
import com.astropay.connect.core.AstroResult
import com.astropay.connect.core.AstroTheme
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.core.IssuerLogoCache
import com.astropay.connect.core.encodeForBridge
import com.astropay.connect.core.parseHexColor
import com.astropay.connect.core.resolveNativeBackgroundColor
import com.astropay.connect.core.resolveNativeHeaderBackgroundColor
import com.astropay.connect.core.resolveNativeHeaderBorderColor
import com.astropay.connect.core.resolveNativePrimaryColor
import com.astropay.connect.utils.BiometricManager
import com.astropay.connect.utils.CameraManager
import com.astropay.connect.utils.NativeKycColorResolver
import com.astropay.connect.utils.NativeKycEnvironment
import com.astropay.connect.utils.NativeKycErrorCode
import com.astropay.connect.utils.NativeKycEventMapper
import com.astropay.connect.utils.NativeKycHandlerProvider
import com.astropay.connect.utils.NativeKycResult
import com.astropay.connect.utils.NativeKycSession
import com.astropay.connect.utils.NativeKycStatus
import com.astropay.connect.utils.ThemeManager
import com.astropay.connect.utils.URLBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Constants for the native-KYC view-level lifecycle handling. Grouped in an `object` per the
 * Android code standard (no free-floating top-level constants); [AstroConnectView] is a composable
 * function, so there is no enclosing class to host a `companion object`.
 */
private object NativeKycViewConstants {
    /**
     * Delay before the native-KYC ON_RESUME back-out re-check fires. Gives an in-flight CAF
     * success/cancel callback time to arrive and flip `isNativeKycPending` first, so a successful
     * KYC is not misreported as CANCELLED on the host-ON_RESUME-wins-the-race path. Imperceptible
     * to the user; the 5-minute engine watchdog remains the backstop. Biased larger on purpose: a false
     * CANCELLED on a successful KYC (user must redo the whole flow) is a worse outcome than the host
     * waiting an extra 200ms before a genuine back-out is reported as CANCELLED. It remains a
     * heuristic against an ordering CAF does not guarantee; 500ms simply widens the safety margin.
     */
    const val BACKOUT_RECHECK_DELAY_MS = 500L

    /**
     * The only native KYC provider this SDK supports today. The web sends `provider: 'CAF'` in the
     * `startNativeKyc` bridge body; any other non-blank provider is rejected with
     * `UNSUPPORTED_PROVIDER` so the web can fall back deterministically to the iframe flow. Matched
     * case-insensitively.
     */
    const val PROVIDER_CAF = "CAF"
}

/**
 * Composable that displays the AstroPay Connect SDK inline.
 * This is equivalent to the iOS `.astroConnect()` modifier.
 *
 * Usage:
 * ```kotlin
 * AstroConnectView(
 *     configuration = configuration,
 *     onResult = { result ->
 *         when (result) {
 *             is AstroResult.Success -> // Handle success
 *             is AstroResult.Failure -> // Handle error
 *             is AstroResult.Closed -> // Handle user closed
 *         }
 *     }
 * )
 * ```
 *
 * @param configuration The SDK configuration.
 * @param modifier Modifier for the composable.
 * @param controller Optional [AstroConnectController] enabling integrators to dismiss the view
 *   from a custom header. When provided, calling `controller.close()` routes through the same
 *   close path as the built-in header button and emits `AstroResult.Closed` exactly once.
 * @param loadingContent Optional custom loading content. If null, a default CircularProgressIndicator is shown.
 * @param onResult Callback for SDK result.
 */
@SuppressLint("ClickableViewAccessibility")
@Composable
fun AstroConnectView(
    configuration: AstroConfiguration,
    modifier: Modifier = Modifier,
    controller: AstroConnectController? = null,
    loadingContent: @Composable (() -> Unit)? = null,
    onResult: (AstroResult) -> Unit,
) {
    // Per-presentation idempotency guard. Lives on the composition (not the controller) so a
    // retained controller instance does not carry close state across presentations. First-writer
    // wins: whichever close path fires first (built-in header button, web bridge notifyClose,
    // or integrator-initiated controller.close()) emits AstroResult.Closed; subsequent calls
    // within the same composition are no-ops.
    val alreadyClosedState = remember { mutableStateOf(false) }
    val handleClose: (String, String) -> Unit =
        remember(onResult, alreadyClosedState) {
            { code, message ->
                if (!alreadyClosedState.value) {
                    alreadyClosedState.value = true
                    AstroLogger.logInfo("Lifecycle: AstroConnect - closed")
                    onResult(AstroResult.Closed(code, message))
                }
            }
        }

    // Intercept system back-press while the SDK is mounted and hasn't fired a close yet.
    // Emits a synthetic `Closed(CLOSED_BY_SYSTEM_DISMISS)` so integrators get a uniform signal
    // regardless of how dismissal happened. Once any close path fires the handler disables
    // itself and back-press falls through to the parent for normal navigation.
    //
    // The companion path is the `onDispose` block below: if the composable is removed without
    // any close path having fired (host pops the screen, sheet swipe-down, navigation back-swipe),
    // dispose synthesises the same `Closed(SYSTEM_DISMISS, "View was dismissed")` so the
    // integrator is always notified. Message is kept identical across back-press and dispose
    // to match iOS, which has a single `.onDisappear` path with the same wording.
    BackHandler(enabled = !alreadyClosedState.value) {
        handleClose("CLOSED_BY_SYSTEM_DISMISS", "View was dismissed")
    }

    // Wire the controller's close request to handleClose while this composable is mounted.
    // Cleared on dispose so the controller cannot call into a torn-down view.
    DisposableEffect(controller) {
        controller?.onCloseRequest = handleClose
        onDispose {
            controller?.onCloseRequest = null
        }
    }

    val context = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingBridgePermissionRequest by remember { mutableStateOf(false) }
    var pendingTOTPGeneration by remember { mutableStateOf(false) }
    var isNativeKycPending by remember { mutableStateOf(false) }
    // Cancel handle for the in-flight native KYC session. Stored at the view level so the
    // lifecycle-resume back-out observer can suppress the engine watchdog when the user backs
    // out of CAF without a terminal event. Held in a `remember` box (not Compose state) because
    // it is only ever read/written on the main thread and never drives recomposition.
    val nativeKycSessionHolder = remember { arrayOfNulls<NativeKycSession>(1) }

    val themeParameter = remember { ThemeManager.getThemeParameter(context, configuration.theme) }

    fun defaultMainBGColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF041311)
            "light" -> Color(0xFFFFFFFF)
            else -> Color(0xFF041311)
        }

    fun defaultTopBarBGColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF061E1D)
            "light" -> Color(0xFFEFEFEF)
            else -> Color(0xFF061E1D)
        }

    fun defaultTopBarBorderColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF061E1D)
            "light" -> Color(0xFFEFEFEF)
            else -> Color(0xFF061E1D)
        }

    fun defaultCloseColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFFF2F2F2)
            "light" -> Color(0xFF262626)
            else -> Color(0xFFF2F2F2)
        }

    // `Color(color = it)` is the Compose `Color(Int)` constructor reading
    // the `@ColorInt` AARRGGBB packed Int — partial alpha is preserved.
    // Named arg disambiguates from the legacy hex-string Color helper.
    //
    // `resolveNativeBackgroundColor` falls back to `configuration.styleOverrides`
    // when the typed `style.backgroundColor` is absent, matching the web
    // alias list (bg_color / backgroundColor / background_color / colors.surfaceBase).
    val resolvedMainBGColor =
        resolveNativeBackgroundColor(configuration.style, configuration.styleOverrides)
            ?.let { Color(color = it) }
            ?: defaultMainBGColor(themeParameter)
    // Header colors honor `styleOverrides["header"]["backgroundColor"|"borderColor"]`
    // (hex String or Compose Color) over the typed `style.header.*` field,
    // falling back to the default theme color. Native chrome only — the web
    // has no header and ignores the `header` key.
    val resolvedHeaderBGColor =
        resolveNativeHeaderBackgroundColor(configuration.style, configuration.styleOverrides)
            ?.let { Color(color = it) }
            ?: defaultTopBarBGColor(themeParameter)
    val resolvedHeaderBorderColor =
        resolveNativeHeaderBorderColor(configuration.style, configuration.styleOverrides)
            ?.let { Color(color = it) }
            ?: defaultTopBarBorderColor(themeParameter)
    val resolvedHeaderBorderWidth = configuration.style?.header?.borderWidth ?: 2f
    val resolvedHeaderPaddingH = configuration.style?.header?.paddingHorizontal ?: 8f
    val resolvedHeaderPaddingV = configuration.style?.header?.paddingVertical ?: 8f

    // Configure logger and validate configuration synchronously before any UI is rendered
    // This matches iOS behavior where validation happens in init() before the view is created
    val configurationError =
        remember {
            AstroLogger.configure(configuration.logSetting, configuration.environment)
            BiometricManager.configure(configuration.biometricGracePeriodMs)
            AstroLogger.logDebug("Initialization")
            AstroLogger.logDebug("$configuration")

            try {
                configuration.validate()
                AstroLogger.logInfo("AstroConnect - initialized")
                null
            } catch (e: AstroConfigurationException) {
                val error = AstroError(ErrorCode.INVALID_CONFIGURATION, null, e.message)
                AstroLogger.logError(error)
                error
            }
        }

    // If configuration validation failed, report error and don't render the view
    if (configurationError != null) {
        LaunchedEffect(Unit) {
            alreadyClosedState.value = true
            onResult(AstroResult.Failure(configurationError))
        }
        return
    }

    // Camera permission launcher — requests CAMERA and RECORD_AUDIO together so that the
    // CAF native KYC face liveness flow (which requires the microphone) and the WebView
    // iframe KYC flow both receive mic access without a separate prompt.
    val cameraPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
        ) { results ->
            val cameraGranted = results[Manifest.permission.CAMERA] == true
            // The camera-permission status reported to the web MUST depend on CAMERA only. The web
            // KYC iframe flows (and `hasCameraPermission`/`getCameraPermissionStatus`) key off the
            // camera alone; a mic denial must NOT report the camera as `denied` or those flows break.
            // RECORD_AUDIO is only relevant to the native CAF liveness path and is handled per-resource
            // when granting the WebView PermissionRequest below.
            val status = CameraManager.getStatusFromResult(cameraGranted)

            // Handle pending web permission request: grant video only if CAMERA is held and audio
            // only if RECORD_AUDIO is held (partial grant), so a mic denial never yields a
            // granted-but-silent audio track.
            pendingPermissionRequest?.let { request ->
                grantWebPermissionRequestPartially(context, request)
                pendingPermissionRequest = null
            }

            // Send callback to JavaScript if request came from bridge
            if (pendingBridgePermissionRequest) {
                pendingBridgePermissionRequest = false
                webView?.let { wv ->
                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                    wv.evaluateJavascript(script, null)
                }
            }
        }

    // TOTP generation launcher (KeyguardManager fallback)
    val totpAuthLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (!pendingTOTPGeneration) {
                AstroLogger.logDebug("TOTP auth result but no pending generation")
                return@rememberLauncherForActivityResult
            }
            pendingTOTPGeneration = false

            val resultJson =
                if (result.resultCode == Activity.RESULT_OK) {
                    // Authentication successful - generate TOTP
                    when (val totpResult = BiometricManager.generateTOTPAfterAuth(context)) {
                        is BiometricManager.GenerateTOTPResult.Success -> {
                            JSONObject()
                                .apply {
                                    put("status", "OK")
                                    put("code", totpResult.code)
                                    put("remainingSeconds", totpResult.remainingSeconds)
                                }.toString()
                        }

                        is BiometricManager.GenerateTOTPResult.Error -> {
                            JSONObject()
                                .apply {
                                    put("status", "ERROR")
                                    put("code", totpResult.code)
                                }.toString()
                        }
                    }
                } else {
                    // User cancelled or authentication failed
                    JSONObject()
                        .apply {
                            put("status", "ERROR")
                            put("code", BiometricManager.ErrorCode.USER_CANCELLED)
                        }.toString()
                }

            webView?.let { wv ->
                val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                wv.evaluateJavascript(script, null)
            }
        }

    // Load timeout handler
    val loadTimeoutHandler = remember { Handler(Looper.getMainLooper()) }
    var hasTimedOut by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }

    val loadTimeoutSeconds = AstroConstants.Timeouts.LOAD_TIMEOUT_MS / 1000

    DisposableEffect(Unit) {
        val timeoutRunnable =
            Runnable {
                if (isLoading && !hasTimedOut) {
                    hasTimedOut = true
                    alreadyClosedState.value = true
                    val error = AstroError(ErrorCode.TIMEOUT, null, "SDK failed to load within $loadTimeoutSeconds seconds")
                    AstroLogger.logError(error)
                    onResult(AstroResult.Failure(error))
                }
            }
        loadTimeoutHandler.postDelayed(timeoutRunnable, AstroConstants.Timeouts.LOAD_TIMEOUT_MS)

        onDispose {
            // Teardown while a native KYC is still pending: the integrator must ALWAYS receive a
            // terminal AstroResult. The eventual CAF result can only be delivered via
            // evaluateJavascript into the WebView we are about to destroy (swallowed), so we deliver
            // the terminal result DIRECTLY to the integrator callback here and cancel the CAF
            // session/watchdog so no late callback races. `handleClose` is the single close path and
            // is idempotent (first-writer wins), so if a genuine close already fired it no-ops.
            if (isNativeKycPending) {
                AstroLogger.logDebug("NativeKYC: disposed while pending — cancelling session and delivering terminal Closed")
                isNativeKycPending = false
                nativeKycSessionHolder[0]?.cancel()
                nativeKycSessionHolder[0] = null
                handleClose("CLOSED_BY_SYSTEM_DISMISS", "View was dismissed")
            } else if (!alreadyClosedState.value) {
                // Synthesise a close if the composable is being torn down without any explicit
                // close path having fired (host popped the screen, sheet swipe-down, nav back-swipe,
                // process death from host). Mirrors iOS `.onDisappear`. Guarded by `alreadyClosed`
                // so explicit closes (header button, controller, web bridge, back-press) win.
                handleClose("CLOSED_BY_SYSTEM_DISMISS", "View was dismissed")
            }
            loadTimeoutHandler.removeCallbacksAndMessages(null)
            webView?.apply {
                stopLoading()
                destroy()
            }
            AstroLogger.logInfo("Lifecycle: AstroConnect - disposed")
        }
    }

    // Native KYC back-out detection (CAF gap fix).
    //
    // CAF starts its OWN Activities stacked over the host, so during a normal flow the host sees
    // exactly one ON_STOP and stays stopped across all intra-CAF transitions; it only receives an
    // ON_RESUME once every CAF Activity has been popped. When the user presses system back from
    // the CAF document screen, CAF fires NO terminal event — leaving the web stuck on a spinner
    // until the 5-minute watchdog. A host ON_RESUME while `isNativeKycPending == true` means the user
    // *may* have backed out, so we treat it as a candidate back-out.
    //
    // Why a delayed re-check (not synchronous): on the SUCCESS path the ordering between (a) CAF
    // popping its Activities → host ON_RESUME and (b) CAF delivering its real onResult callback is
    // internal to CAF and NOT guaranteed. If host ON_RESUME wins that race and we delivered
    // CANCELLED synchronously, we would convert a genuinely successful KYC into CANCELLED and
    // suppress the real CAF result (the shared `resultDelivered`/watchdog guard in the engine
    // session is single-shot). To avoid that, ON_RESUME only POSTS a short delayed re-check
    // (~500ms) on the main thread. That gives an in-flight CAF success/cancel callback time to
    // arrive first and flip `isNativeKycPending` false. We re-read the flag AT FIRE TIME: if it is
    // already false a terminal CAF/watchdog result landed in the gap and the runnable no-ops; if it
    // is still true CAF fired no terminal event (genuine back-out) and we synthesise CANCELLED. The
    // 5-minute watchdog remains the backstop, so ~500ms is imperceptible.
    //
    // Inter-module transition guard (mid-flow progress signal): CAF's document activity `finish()`es
    // and the liveness module is launched asynchronously host-side, so the host can transiently
    // ON_RESUME BETWEEN the two CAF modules — which is NOT a back-out. To avoid synthesising CANCELLED
    // in that window we (1) cancel any pending re-check on ON_PAUSE (the liveness activity coming to
    // the front pauses the host again, cancelling the just-scheduled re-check before it can fire),
    // and (2) require the host to see the CAF stack fully gone: the re-check only fires if no
    // ON_PAUSE arrived to cancel it. A genuine back-out leaves the host resumed with no subsequent
    // pause, so the re-check survives and CANCELLED is delivered; an inter-module transition pauses
    // the host again within the window, cancelling it.
    //
    // Idempotency / ordering: `isNativeKycPending` is the single view-level winner-take-all flag.
    // The CAF onResult callback sets it false synchronously as its first action; both that setter
    // and the delayed runnable run on the main thread, so the flag transition is the linearisation
    // point. Either a CAF/watchdog result already ran and flipped the flag (the runnable no-ops), or
    // it has not (the runnable wins, flips the flag, cancels the engine session/watchdog, and
    // delivers CANCELLED). Gated strictly on ON_RESUME (not ON_START) so backgrounding+foregrounding
    // while CAF is still on top does not schedule a false cancel — the host stays behind CAF, never
    // reaching ON_RESUME, until the whole CAF stack is gone.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val handler = Handler(Looper.getMainLooper())
        val backOutRecheck =
            Runnable {
                // Re-read the flag at fire time (not captured stale). A terminal CAF/watchdog
                // result that landed during the delay already flipped it false → no-op.
                if (!isNativeKycPending) {
                    AstroLogger.logDebug("NativeKYC: ON_RESUME re-check — terminal result arrived, no synthetic CANCELLED")
                    return@Runnable
                }
                AstroLogger.logDebug("NativeKYC: ON_RESUME re-check — still pending, treating as back-out, delivering CANCELLED")
                // Flip the flag FIRST so a racing CAF/watchdog result on the same thread no-ops.
                isNativeKycPending = false
                // Suppress the engine watchdog and any late CAF callback.
                nativeKycSessionHolder[0]?.cancel()
                nativeKycSessionHolder[0] = null
                // Deliver CANCELLED through the same bridge path the CAF onResult block uses.
                webView?.let { wv ->
                    val script = AstroBridgeManager.createNativeKycCallback(
                        NativeKycResult(status = NativeKycStatus.CANCELLED).jsonString
                    )
                    wv.post {
                        runCatching { wv.evaluateJavascript(script, null) }
                    }
                }
            }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    if (isNativeKycPending) {
                        AstroLogger.logDebug("NativeKYC: host ON_RESUME while pending — scheduling back-out re-check")
                        // Coalesce: a single pending re-check is enough even if ON_RESUME fires repeatedly.
                        handler.removeCallbacks(backOutRecheck)
                        handler.postDelayed(backOutRecheck, NativeKycViewConstants.BACKOUT_RECHECK_DELAY_MS)
                    }
                }
                Lifecycle.Event.ON_PAUSE -> {
                    // The host is going behind another Activity again. During a native KYC this is
                    // the signal of a mid-flow inter-module transition (document→liveness): CAF's
                    // next module activity is coming to the front, so cancel the just-scheduled
                    // back-out re-check before it can synthesise a false CANCELLED on a still-running
                    // KYC. A genuine back-out produces no such follow-up ON_PAUSE, so its re-check
                    // survives.
                    if (isNativeKycPending) {
                        AstroLogger.logDebug("NativeKYC: host ON_PAUSE while pending — cancelling any scheduled back-out re-check")
                        handler.removeCallbacks(backOutRecheck)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            // Remove any pending re-check so it never fires after the composable leaves (avoids
            // leaks / posting into a torn-down webView).
            handler.removeCallbacks(backOutRecheck)
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        modifier = modifier.imePadding(),
        topBar = {
            if (configuration.effectiveShowHeader) {
                val logoUrl = "${configuration.issuerLogoBaseUrl}/${configuration.appIssuer.lowercase()}_$themeParameter.webp"
                val fallbackUrl = "${configuration.issuerLogoBaseUrl}/astropay_$themeParameter.webp"
                AstroLogger.logDebug("Issuer logo URL: ${configuration.appIssuer.lowercase()}_$themeParameter")
                val logoBitmap = rememberIssuerLogoBitmap(logoUrl)
                val fallbackBitmap = rememberIssuerLogoBitmap(fallbackUrl)
                val displayBitmap = if (configuration.showHeaderLogo == true) logoBitmap ?: fallbackBitmap else null

                Column {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .background(resolvedHeaderBGColor)
                                .statusBarsPadding()
                                .padding(horizontal = resolvedHeaderPaddingH.dp, vertical = resolvedHeaderPaddingV.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (displayBitmap != null) {
                            Image(
                                bitmap = displayBitmap,
                                contentDescription = configuration.appIssuer,
                                contentScale = ContentScale.FillHeight,
                                modifier =
                                    Modifier
                                        .padding(start = 4.dp)
                                        .height(20.dp)
                                        .wrapContentWidth()
                                        .clip(RoundedCornerShape(8.dp)),
                            )
                        } else {
                            Spacer(modifier = Modifier.size(20.dp))
                        }

                        IconButton(
                            onClick = {
                                handleClose("CLOSED_BY_USER_HEADER_BUTTON", "User tapped the close button")
                            },
                            modifier = Modifier.size(42.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = defaultCloseColor(themeParameter),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                    if (resolvedHeaderBorderWidth > 0f) {
                        HorizontalDivider(
                            color = resolvedHeaderBorderColor,
                            thickness = resolvedHeaderBorderWidth.dp,
                        )
                    }
                }
            }
        },
    ) { paddingValues ->
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(resolvedMainBGColor),
        ) {
            AndroidView(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .then(if (configuration.effectiveShowHeader) Modifier.padding(paddingValues) else Modifier),
                factory = { ctx ->
                    val claimed = AstroPreloadSession.claim(configuration, themeParameter)
                    if (claimed != null) {
                        // ---- Preloaded path: wire up the existing WebView ----
                        // The preload caller is notified through `onPreloadEnded` directly
                        // by AstroPreloadSession (it fires `Deferred` from claim() when no
                        // terminal result has been delivered yet), so we don't need to
                        // chain anything here.
                        claimed.webView.apply {
                            layoutParams =
                                ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )

                            if (!claimed.bridge.isLoaded) {
                                visibility = View.INVISIBLE
                                alpha = 0f
                            }

                            setOnTouchListener { v, _ ->
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                                false
                            }

                            claimed.bridge.apply {
                                onLoaded = {
                                    post {
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        if (hasTimedOut || hasError) {
                                            AstroLogger.logDebug("SDK loaded but error occurred, skipping onLoaded")
                                            return@post
                                        }
                                        isLoading = false
                                        visibility = View.VISIBLE
                                        animate().alpha(1f).setDuration(0).start()
                                        AstroLogger.logInfo("Lifecycle: AstroConnect - loaded")
                                        onResult(AstroResult.Success)
                                    }
                                }
                                onClose = { code, message ->
                                    post {
                                        handleClose(code, message)
                                    }
                                }
                                onError = { error ->
                                    post {
                                        if (!hasError) {
                                            hasError = true
                                            alreadyClosedState.value = true
                                            loadTimeoutHandler.removeCallbacksAndMessages(null)
                                            onResult(AstroResult.Failure(error))
                                        }
                                    }
                                }
                                onEvent = { event -> post { onResult(AstroResult.Event(event)) } }
                                onCheckCameraPermission = {
                                    val status = CameraManager.getCameraPermissionStatus(ctx, null)
                                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                                    post { evaluateJavascript(script, null) }
                                }
                                onRequestCameraPermission = {
                                    CameraManager.markPermissionRequested(ctx)
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        val script =
                                            AstroBridgeManager.createCameraPermissionCallback(
                                                CameraManager.PermissionStatus.AUTHORIZED,
                                            )
                                        post { evaluateJavascript(script, null) }
                                    } else {
                                        pendingBridgePermissionRequest = true
                                        cameraPermissionLauncher.launch(CameraManager.REQUIRED_MEDIA_PERMISSIONS)
                                    }
                                }
                                onCheckBiometricAvailability = {
                                    val errorCode = BiometricManager.getBiometricErrorCode(ctx)
                                    val resultJson =
                                        if (errorCode == null) {
                                            JSONObject().apply { put("status", "OK") }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", errorCode)
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createCheckBiometricCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onDeleteSeed = {
                                    val success = BiometricManager.deleteSeed(ctx)
                                    val resultJson =
                                        if (success) {
                                            JSONObject().apply { put("status", "OK") }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", "KEYSTORE_ERROR")
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createDeleteSeedCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onGetSeed = {
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for getSeed")
                                        BiometricManager.getSeed(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GetSeedResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("seed", result.seed)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GetSeedResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGetSeedCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available for getSeed")
                                        val errorJson =
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", BiometricManager.ErrorCode.BIOMETRIC_NOT_AVAILABLE)
                                                }.toString()
                                        val script = AstroBridgeManager.createGetSeedCallback(errorJson)
                                        post { evaluateJavascript(script, null) }
                                    }
                                }
                                onRegisterDevice = { seed ->
                                    val result = BiometricManager.registerDevice(ctx, seed)
                                    val resultJson =
                                        when (result) {
                                            is BiometricManager.RegisterDeviceResult.Success -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "OK")
                                                        put("deviceInfo", result.deviceInfo)
                                                        put("deviceId", result.deviceId)
                                                    }.toString()
                                            }

                                            is BiometricManager.RegisterDeviceResult.Error -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", result.code)
                                                    }.toString()
                                            }
                                        }
                                    val script = AstroBridgeManager.createRegisterDeviceCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onGenerateTOTP = totp@{
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for TOTP generation")
                                        BiometricManager.generateTOTP(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available, using KeyguardManager fallback for TOTP")
                                        if (BiometricManager.canSkipAuth()) {
                                            val result = BiometricManager.generateTOTPAfterAuth(ctx)
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        if (!BiometricManager.prepareTOTPGeneration(ctx)) {
                                            AstroLogger.logDebug("Cannot prepare TOTP generation")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.SEED_NOT_FOUND)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        val intent =
                                            BiometricManager.createKeyguardIntent(
                                                ctx,
                                                title = "Verify Identity",
                                                description = "Authenticate to generate verification code",
                                            )
                                        if (intent == null) {
                                            AstroLogger.logDebug("Cannot create keyguard intent for TOTP")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.DEVICE_NOT_SECURE)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        pendingTOTPGeneration = true
                                        totpAuthLauncher.launch(intent)
                                    }
                                }
                                onStartNativeKyc = { provider, token, userId, docTypes ->
                                    claimed.webView.post {
                                        handleStartNativeKyc(
                                            webView = claimed.webView,
                                            ctx = ctx,
                                            provider = provider,
                                            token = token,
                                            userId = userId,
                                            docTypes = docTypes,
                                            configuration = configuration,
                                            isNativeKycPending = { isNativeKycPending },
                                            setNativeKycPending = { isNativeKycPending = it },
                                            setNativeKycSession = { nativeKycSessionHolder[0] = it },
                                            onStepEvent = { event -> post { onResult(AstroResult.Event(event)) } },
                                        )
                                    }
                                }
                                onOpenQrScanner = { texts ->
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroQrScannerFragment
                                            .newInstance(texts) { result ->
                                                val script =
                                                    AstroBridgeManager.createQrScanResultCallback(
                                                        result.encodeForBridge(),
                                                    )
                                                post { evaluateJavascript(script, null) }
                                            }.show(fragmentActivity.supportFragmentManager, "qr_scanner")
                                    } else {
                                        val script =
                                            AstroBridgeManager.createQrScanResultCallback(
                                                """{"error":"SCAN_FAILED"}""",
                                            )
                                        post { evaluateJavascript(script, null) }
                                    }
                                }
                            }

                            // The bridge is now wired to the live AstroConnectView; mark it
                            // visible and dispatch any generateTOTP request that was deferred
                            // while running invisibly during preload.
                            claimed.bridge.markVisibleAndFlush()

                            webViewClient =
                                AstroWebViewClient(
                                    configuration = configuration,
                                    themeParameter = themeParameter,
                                    onPageStarted = {},
                                    onPageFinished = {},
                                    onError = { error ->
                                        if (!hasError) {
                                            hasError = true
                                            alreadyClosedState.value = true
                                            loadTimeoutHandler.removeCallbacksAndMessages(null)
                                            onResult(AstroResult.Failure(error))
                                        }
                                    },
                                )
                            webChromeClient =
                                AstroWebChromeClient(
                                    context = ctx,
                                    onCameraPermissionNeeded = { request ->
                                        if (CameraManager.hasCameraPermission(ctx)) {
                                            // Grant per-resource against the OS permissions held so a
                                            // mic denial never yields a granted-but-silent audio track.
                                            grantWebPermissionRequestPartially(ctx, request)
                                        } else {
                                            pendingPermissionRequest = request
                                            if (!pendingBridgePermissionRequest) {
                                                CameraManager.markPermissionRequested(ctx)
                                                cameraPermissionLauncher.launch(CameraManager.REQUIRED_MEDIA_PERMISSIONS)
                                            }
                                        }
                                    },
                                )

                            if (claimed.bridge.isLoaded) {
                                // Page already loaded — re-inject bridge with current config then fire result.
                                // (The preload WebView injected the bridge at load time; this ensures the
                                // current configuration is in place before the SDK becomes visible.)
                                post {
                                    val script = AstroBridgeManager.createBridgeScript(configuration, themeParameter)
                                    evaluateJavascript(script) {
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        if (!hasTimedOut && !hasError) {
                                            isLoading = false
                                            visibility = View.VISIBLE
                                            animate().alpha(1f).setDuration(0).start()
                                            AstroLogger.logInfo("Lifecycle: AstroConnect - loaded (from preload)")
                                            onResult(AstroResult.Success)
                                        }
                                    }
                                }
                            }

                            webView = this
                        }
                    } else {
                        // ---- Normal path: create a fresh WebView ----
                        WebView(ctx).apply {
                            layoutParams =
                                ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )
                            visibility = View.INVISIBLE
                            alpha = 0f

                            // Prevent parent (BottomSheet, etc.) from intercepting touch events
                            // This allows WebView to handle scroll instead of sheet dismiss gesture
                            setOnTouchListener { v, _ ->
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                                false
                            }

                            setupWebView(
                                configuration = configuration,
                                themeParameter = themeParameter,
                                onLoaded = {
                                    loadTimeoutHandler.removeCallbacksAndMessages(null)
                                    if (hasTimedOut || hasError) {
                                        AstroLogger.logDebug("SDK loaded but error occurred, skipping onLoaded")
                                        return@setupWebView
                                    }
                                    isLoading = false
                                    visibility = View.VISIBLE
                                    animate().alpha(1f).setDuration(0).start()
                                    AstroLogger.logInfo("Lifecycle: AstroConnect - loaded")
                                    onResult(AstroResult.Success)
                                },
                                onClose = { code, message ->
                                    handleClose(code, message)
                                },
                                onError = { error ->
                                    if (!hasError) {
                                        hasError = true
                                        alreadyClosedState.value = true
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        onResult(AstroResult.Failure(error))
                                    }
                                },
                                onEvent = { event ->
                                    onResult(AstroResult.Event(event))
                                },
                                onCameraPermissionCheck = {
                                    val status = CameraManager.getCameraPermissionStatus(ctx, null)
                                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                                    post { evaluateJavascript(script, null) }
                                },
                                onCameraPermissionRequest = {
                                    CameraManager.markPermissionRequested(ctx)
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        val script =
                                            AstroBridgeManager.createCameraPermissionCallback(
                                                CameraManager.PermissionStatus.AUTHORIZED,
                                            )
                                        post { evaluateJavascript(script, null) }
                                    } else {
                                        pendingBridgePermissionRequest = true
                                        cameraPermissionLauncher.launch(CameraManager.REQUIRED_MEDIA_PERMISSIONS)
                                    }
                                },
                                onWebPermissionRequest = { request ->
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        // Grant per-resource against the OS permissions held so a
                                        // mic denial never yields a granted-but-silent audio track.
                                        grantWebPermissionRequestPartially(ctx, request)
                                    } else {
                                        pendingPermissionRequest = request
                                        if (!pendingBridgePermissionRequest) {
                                            CameraManager.markPermissionRequested(ctx)
                                            cameraPermissionLauncher.launch(CameraManager.REQUIRED_MEDIA_PERMISSIONS)
                                        }
                                    }
                                },
                                onCheckBiometricAvailability = {
                                    val errorCode = BiometricManager.getBiometricErrorCode(ctx)
                                    val resultJson =
                                        if (errorCode == null) {
                                            JSONObject()
                                                .apply {
                                                    put("status", "OK")
                                                }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", errorCode)
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createCheckBiometricCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onDeleteSeed = {
                                    val success = BiometricManager.deleteSeed(ctx)
                                    val resultJson =
                                        if (success) {
                                            JSONObject()
                                                .apply {
                                                    put("status", "OK")
                                                }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", "KEYSTORE_ERROR")
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createDeleteSeedCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onGetSeed = {
                                    val fragmentActivity = ctx.findFragmentActivity()

                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for getSeed")
                                        BiometricManager.getSeed(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GetSeedResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("seed", result.seed)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GetSeedResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGetSeedCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available for getSeed")
                                        val errorJson =
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", BiometricManager.ErrorCode.BIOMETRIC_NOT_AVAILABLE)
                                                }.toString()
                                        val script = AstroBridgeManager.createGetSeedCallback(errorJson)
                                        post { evaluateJavascript(script, null) }
                                    }
                                },
                                onRegisterDevice = { seed ->
                                    // Register device - stores seed encrypted without biometric prompt
                                    // Biometric is only required when generating TOTP
                                    val result = BiometricManager.registerDevice(ctx, seed)
                                    val resultJson =
                                        when (result) {
                                            is BiometricManager.RegisterDeviceResult.Success -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "OK")
                                                        put("deviceInfo", result.deviceInfo)
                                                        put("deviceId", result.deviceId)
                                                    }.toString()
                                            }

                                            is BiometricManager.RegisterDeviceResult.Error -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", result.code)
                                                    }.toString()
                                            }
                                        }
                                    val script = AstroBridgeManager.createRegisterDeviceCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onGenerateTOTP = {
                                    // Try BiometricPrompt first (requires FragmentActivity)
                                    val fragmentActivity = ctx.findFragmentActivity()

                                    if (fragmentActivity != null) {
                                        // Use BiometricPrompt (preferred method)
                                        AstroLogger.logDebug("Using BiometricPrompt for TOTP generation")
                                        BiometricManager.generateTOTP(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        // Fallback to KeyguardManager (works with any Activity)
                                        AstroLogger.logDebug("FragmentActivity not available, using KeyguardManager fallback for TOTP")

                                        // Skip authentication if within grace period
                                        if (BiometricManager.canSkipAuth()) {
                                            val result = BiometricManager.generateTOTPAfterAuth(ctx)
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Check if we can generate TOTP
                                        if (!BiometricManager.prepareTOTPGeneration(ctx)) {
                                            AstroLogger.logDebug("Cannot prepare TOTP generation")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.SEED_NOT_FOUND)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Create keyguard intent
                                        val intent =
                                            BiometricManager.createKeyguardIntent(
                                                ctx,
                                                title = "Verify Identity",
                                                description = "Authenticate to generate verification code",
                                            )
                                        if (intent == null) {
                                            AstroLogger.logDebug("Cannot create keyguard intent for TOTP")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.DEVICE_NOT_SECURE)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Mark pending and launch authentication
                                        pendingTOTPGeneration = true
                                        totpAuthLauncher.launch(intent)
                                    }
                                },
                                onStartNativeKyc = { provider, token, userId, docTypes ->
                                    // Called directly (no post): the setupWebView wrapper already
                                    // hops this callback onto the main looper (needed because
                                    // @JavascriptInterface runs off-main). A second post here was
                                    // redundant. handleStartNativeKyc requires the main thread.
                                    handleStartNativeKyc(
                                        webView = this,
                                        ctx = ctx,
                                        provider = provider,
                                        token = token,
                                        userId = userId,
                                        docTypes = docTypes,
                                        configuration = configuration,
                                        isNativeKycPending = { isNativeKycPending },
                                        setNativeKycPending = { isNativeKycPending = it },
                                        setNativeKycSession = { nativeKycSessionHolder[0] = it },
                                        onStepEvent = { event -> onResult(AstroResult.Event(event)) },
                                    )
                                },
                                onOpenQrScanner = { texts ->
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroQrScannerFragment
                                            .newInstance(texts) { result ->
                                                val script =
                                                    AstroBridgeManager.createQrScanResultCallback(
                                                        result.encodeForBridge(),
                                                    )
                                                post { evaluateJavascript(script, null) }
                                            }.show(fragmentActivity.supportFragmentManager, "qr_scanner")
                                    } else {
                                        val script =
                                            AstroBridgeManager.createQrScanResultCallback(
                                                """{"error":"SCAN_FAILED"}""",
                                            )
                                        post { evaluateJavascript(script, null) }
                                    }
                                },
                            )

                            // Load URL with custom SDK header
                            val url = URLBuilder.buildURL(configuration, themeParameter)
                            if (url != null) {
                                AstroLogger.logInfo("Loading App")
                                val headers =
                                    mapOf(
                                        AstroConstants.Bridge.SDK_HEADER_NAME to AstroConstants.Bridge.SDK_HEADER_VALUE,
                                    )
                                loadUrl(url, headers)
                            } else {
                                val error = AstroError(ErrorCode.INITIALIZATION_ERROR, null, "Failed to build URL from configuration")
                                AstroLogger.logError(error)
                                alreadyClosedState.value = true
                                onResult(AstroResult.Failure(error))
                            }

                            webView = this
                        }
                    }
                },
            )

            // Loading indicator
            AnimatedVisibility(
                visible = isLoading,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center),
            ) {
                if (loadingContent != null) {
                    loadingContent()
                } else {
                    // Primary color resolves through the same alias fallback as the
                    // brand background — partners that ship only `styleOverrides`
                    // (no typed `style.primaryColor`) still tint the spinner.
                    val spinnerColor =
                        resolveNativePrimaryColor(
                            configuration.style,
                            configuration.styleOverrides,
                        )?.let { Color(color = it) }
                            ?: MaterialTheme.colorScheme.primary
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp,
                        color = spinnerColor,
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun WebView.setupWebView(
    configuration: AstroConfiguration,
    themeParameter: String,
    onLoaded: () -> Unit,
    onClose: (code: String, message: String) -> Unit,
    onError: (AstroError) -> Unit,
    onEvent: (AstroEvent) -> Unit,
    onCameraPermissionCheck: () -> Unit,
    onCameraPermissionRequest: () -> Unit,
    onWebPermissionRequest: (PermissionRequest) -> Unit,
    onCheckBiometricAvailability: () -> Unit,
    onDeleteSeed: () -> Unit,
    onGetSeed: () -> Unit,
    onRegisterDevice: (String) -> Unit, // seed parameter
    onGenerateTOTP: () -> Unit,
    onStartNativeKyc: (provider: String, token: String, userId: String, docTypes: List<String>) -> Unit,
    onOpenQrScanner: (AstroQrScannerTexts) -> Unit,
) {
    settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        mediaPlaybackRequiresUserGesture = false
        allowFileAccess = true
        allowContentAccess = true
        loadWithOverviewMode = true
        useWideViewPort = true
        cacheMode = WebSettings.LOAD_DEFAULT
        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        setSupportMultipleWindows(true)
        javaScriptCanOpenWindowsAutomatically = true
    }

    // Add JavaScript interface — registered once; callbacks updated via mutable properties.
    // Cold-open: the SDK is presented directly so the bridge is visible from the start.
    val bridge =
        AstroBridgeInterface().apply {
            this.onLoaded = { post { onLoaded() } }
            this.onClose = { code, message -> post { onClose(code, message) } }
            this.onError = { error -> post { onError(error) } }
            this.onEvent = { event -> post { onEvent(event) } }
            this.onCheckCameraPermission = { onCameraPermissionCheck() }
            this.onRequestCameraPermission = { post { onCameraPermissionRequest() } }
            this.onCheckBiometricAvailability = { post { onCheckBiometricAvailability() } }
            this.onDeleteSeed = { post { onDeleteSeed() } }
            this.onGetSeed = { post { onGetSeed() } }
            this.onRegisterDevice = { seed -> post { onRegisterDevice(seed) } }
            this.onGenerateTOTP = { post { onGenerateTOTP() } }
            this.onStartNativeKyc = { provider, token, userId, docTypes -> post { onStartNativeKyc(provider, token, userId, docTypes) } }
            this.onOpenQrScanner = { texts -> post { onOpenQrScanner(texts) } }
        }
    bridge.markVisibleAndFlush()
    addJavascriptInterface(bridge, AstroConstants.Bridge.OBJECT_NAME)

    // Set WebView clients
    webViewClient =
        AstroWebViewClient(
            configuration = configuration,
            themeParameter = themeParameter,
            onPageStarted = { },
            onPageFinished = { },
            onError = { error -> onError(error) },
        )

    webChromeClient =
        AstroWebChromeClient(
            context = context,
            onCameraPermissionNeeded = { request -> onWebPermissionRequest(request) },
        )
}

@Composable
private fun rememberIssuerLogoBitmap(url: String): ImageBitmap? {
    var bitmap by remember(url) { mutableStateOf(IssuerLogoCache.get(url)) }
    LaunchedEffect(url) {
        if (bitmap != null) return@LaunchedEffect
        bitmap =
            withContext(Dispatchers.IO) {
                try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connect()
                    BitmapFactory.decodeStream(connection.inputStream)?.asImageBitmap()?.also {
                        IssuerLogoCache.put(url, it)
                    }
                } catch (_: Exception) {
                    null
                }
            }
    }
    return bitmap
}

/**
 * Starts the native KYC flow through [NativeKycHandler] and delivers the result back to the
 * web layer via evaluateJavascript. Must be called on the main thread.
 *
 * The concrete handler is resolved per build flavor by [NativeKycHandlerProvider]: the `nativeKyc`
 * variant runs the CAF engine, while the CAF-free core variant returns `ERROR / SDK_ERROR`.
 *
 * @param webView The active WebView to deliver the result into.
 * @param ctx Context used by the native KYC handler to start its flow.
 * @param provider The native KYC provider requested by the web (e.g. `"CAF"`). Any non-blank value
 *   other than a supported provider yields a terminal `ERROR` with code `UNSUPPORTED_PROVIDER` so
 *   the web can fall back deterministically to the iframe flow. A blank provider (legacy / parse
 *   failure) falls through to the default provider path.
 * @param token KYC mobile token from the bridge payload.
 * @param userId User identifier from the bridge payload.
 * @param docTypes Document type strings from the bridge payload.
 * @param configuration The active [AstroConfiguration]; used to resolve the theme for the KYC color config.
 * @param isNativeKycPending Getter for the current pending flag.
 * @param setNativeKycPending Setter to mutate the pending flag.
 * @param setNativeKycSession Stores the engine cancel handle at the view level so the
 *   lifecycle-resume back-out path can suppress the engine watchdog. Cleared (null) on the
 *   terminal engine result.
 * @param onStepEvent Sink for non-terminal native KYC progress ([AstroEvent]). Fired on the main
 *   thread, always before the terminal result, on the SAME `onEvent`/`AstroResult.Event` channel
 *   the web uses. The core stub never invokes it.
 */
private fun handleStartNativeKyc(
    webView: WebView,
    ctx: Context,
    provider: String,
    token: String,
    userId: String,
    docTypes: List<String>,
    configuration: AstroConfiguration,
    isNativeKycPending: () -> Boolean,
    setNativeKycPending: (Boolean) -> Unit,
    setNativeKycSession: (NativeKycSession?) -> Unit,
    onStepEvent: (AstroEvent) -> Unit,
) {
    if (isNativeKycPending()) {
        AstroLogger.logDebug("NativeKYC: ignoring startNativeKyc — already in progress")
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.SDK_ERROR).jsonString
        )
        webView.evaluateJavascript(script, null)
        return
    }
    // Provider routing. Only CAF is supported today. An unknown (non-blank, non-CAF) provider is a
    // terminal ERROR with code UNSUPPORTED_PROVIDER — a cross-platform contract (matches iOS) so the
    // web can fall back deterministically to the iframe flow on SDKs that don't support the provider.
    // A blank provider (legacy body / parse failure) falls through to the default CAF path; a genuine
    // parse failure is still caught downstream by the empty-token guard (INVALID_TOKEN).
    if (provider.isNotBlank() && !provider.equals(NativeKycViewConstants.PROVIDER_CAF, ignoreCase = true)) {
        AstroLogger.logDebug("NativeKYC: unsupported provider '$provider' — returning UNSUPPORTED_PROVIDER")
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.UNSUPPORTED_PROVIDER).jsonString
        )
        webView.evaluateJavascript(script, null)
        return
    }
    if (token.isEmpty()) {
        AstroLogger.logDebug("NativeKYC: missing token — returning error")
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.INVALID_TOKEN).jsonString
        )
        webView.evaluateJavascript(script, null)
        return
    }
    // The web sends `userId: identity.userId ?? ''`, so a blank userId can be forwarded here.
    // Fail fast before any CAF presentation rather than failing late after the camera UI shows.
    // INVALID_TOKEN is the closest existing code for a missing required identifier (matches iOS).
    if (userId.isBlank()) {
        AstroLogger.logDebug("NativeKYC: missing userId — returning error")
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.INVALID_TOKEN).jsonString
        )
        webView.evaluateJavascript(script, null)
        return
    }
    // CAF SDK requires API 26+; guard prevents crash on Android 7 devices where
    // tools:overrideLibrary only silences the build error, not the runtime gap.
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        AstroLogger.logDebug("NativeKYC: unsupported OS (API ${Build.VERSION.SDK_INT}) — returning error")
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.SDK_ERROR).jsonString
        )
        webView.evaluateJavascript(script, null)
        return
    }

    setNativeKycPending(true)
    AstroLogger.logDebug("NativeKYC: starting — docTypes=$docTypes isNativeKycPending=true")

    val theme = ThemeManager.getThemeParameter(ctx, configuration.theme)
    // `isForced` is true only for an explicitly forced LIGHT/DARK theme (not SYSTEM), so the engine
    // can pin its base appearance; SYSTEM applies no override and follows the device.
    val isForced = configuration.theme == AstroTheme.LIGHT || configuration.theme == AstroTheme.DARK
    // Resolve the partner colors (or today's theme fallbacks) at the call site so the CAF layer
    // stays free of the style model and the resolvers.
    val colors = NativeKycColorResolver.resolve(
        style = configuration.style,
        styleOverrides = configuration.styleOverrides,
        theme = theme,
    )
    // Derive the CAF environment from the SDK configuration environment: production maps to CAF
    // production; any non-production environment (sandbox/testing/local) maps to CAF's staging tier
    // so QA can exercise the flow without a release build. Contract mirrored on iOS.
    val kycEnvironment =
        if (configuration.environment == AstroEnvironment.PRODUCTION) {
            NativeKycEnvironment.PRODUCTION
        } else {
            NativeKycEnvironment.SANDBOX
        }

    // Catching Throwable on purpose: NoClassDefFoundError/VerifyError are Error, not Exception.
    try {
        val handler = NativeKycHandlerProvider.create()
        val session = handler.startKyc(
            context = ctx,
            token = token,
            userId = userId,
            docTypes = docTypes,
            theme = theme,
            colors = colors,
            forceTheme = isForced,
            environment = kycEnvironment,
            onEvent = { nativeEvent -> onStepEvent(NativeKycEventMapper.toAstroEvent(nativeEvent)) },
        ) { result ->
            // The handler guarantees this callback is on the main thread.
            AstroLogger.logDebug("NativeKYC: result — status=${result.status.value}")
            // Flip the flag FIRST (linearisation point) so a racing host ON_RESUME no-ops, then
            // drop the now-finished session handle.
            setNativeKycPending(false)
            setNativeKycSession(null)
            val payload = result.jsonString
            val script = AstroBridgeManager.createNativeKycCallback(payload)
            webView.post {
                runCatching {
                    webView.evaluateJavascript(script) { returnValue ->
                        val diagnostic = returnValue ?: "null"
                        if (diagnostic.contains("no_callback")) {
                            AstroLogger.logDebug("NativeKYC: nativeKycResultCallback not available — $diagnostic")
                        }
                    }
                }
            }
        }
        // Store the cancel handle for the lifecycle-resume back-out path — but only if the engine
        // hasn't already delivered synchronously (e.g. the core stub or an immediate error), in
        // which case the onResult lambda above already cleared the session to null.
        if (isNativeKycPending()) {
            setNativeKycSession(session)
        }
    } catch (t: Throwable) {
        AstroLogger.logDebug("NativeKYC: native KYC handler threw — ${t.message}")
        // Reset flag — if left true, close event and re-entrancy guard stay stuck.
        setNativeKycPending(false)
        setNativeKycSession(null)
        val script = AstroBridgeManager.createNativeKycCallback(
            NativeKycResult(NativeKycStatus.ERROR, NativeKycErrorCode.SDK_ERROR).jsonString
        )
        webView.evaluateJavascript(script, null)
    }
}

/**
 * Grants a combined video+audio WebView [PermissionRequest] per-resource against the OS
 * permissions actually held: `RESOURCE_VIDEO_CAPTURE` only when CAMERA is granted and
 * `RESOURCE_AUDIO_CAPTURE` only when RECORD_AUDIO is granted.
 *
 * This prevents granting `RESOURCE_AUDIO_CAPTURE` when only the CAMERA OS-permission is held (which
 * would produce a granted-but-silent mic track). It mirrors the audio-only branch in
 * [AstroWebChromeClient], which already gates the audio grant on RECORD_AUDIO. If neither requested
 * resource is backed by an OS permission the request is denied for a clean, predictable failure.
 */
private fun grantWebPermissionRequestPartially(
    ctx: Context,
    request: PermissionRequest,
) {
    val cameraGranted =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
    val audioGranted =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    val granted = mutableListOf<String>()
    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && cameraGranted) {
        granted.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
    }
    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && audioGranted) {
        granted.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
    }

    if (granted.isEmpty()) {
        AstroLogger.logDebug("WebView permission: no OS-granted resources to grant — denying")
        request.deny()
    } else {
        AstroLogger.logDebug("WebView permission: granting ${granted.joinToString()}")
        request.grant(granted.toTypedArray())
    }
}

/**
 * Extension function to find FragmentActivity from a Context.
 * Unwraps ContextWrapper chain to find the underlying FragmentActivity.
 */
private fun Context.findFragmentActivity(): FragmentActivity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is FragmentActivity) {
            return context
        }
        context = context.baseContext
    }
    return null
}
