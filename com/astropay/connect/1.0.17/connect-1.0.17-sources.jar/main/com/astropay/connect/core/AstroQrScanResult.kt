package com.astropay.connect.core

/**
 * Internal result type for a native QR scanner request initiated by the web layer via
 * `window.AstroPayBridge.openQrScanner()`. The SDK presents its own scanner UI and
 * delivers this result internally — it is never exposed to host app partners.
 */
internal sealed class AstroQrScanResult {
    /**
     * The SDK successfully scanned a QR code.
     *
     * @property scannedCode The raw QR code string. Forwarded verbatim to the web layer
     *   (with JSON escaping) via [encodeForBridge].
     */
    data class Success(val scannedCode: String) : AstroQrScanResult()

    /**
     * The SDK could not complete the scan. See [AstroQrScanError] for the canonical reason set.
     */
    data class Error(val code: AstroQrScanError) : AstroQrScanResult()
}

/**
 * Internal error codes for a QR scan. The string [value] is the wire format sent to the web layer.
 */
internal enum class AstroQrScanError(val value: String) {
    /** The user dismissed the scanner without scanning a code. */
    USER_CANCELLED("USER_CANCELLED"),

    /** Camera permission was denied. */
    PERMISSION_DENIED("PERMISSION_DENIED"),

    /** The scanner failed to decode a valid code (timeout, decoding error). */
    SCAN_FAILED("SCAN_FAILED"),

    /** Any other failure. */
    UNKNOWN("UNKNOWN"),
}

/**
 * Encodes a result as the JSON payload expected by the web `qrScanResultCallback`.
 * Uses [org.json.JSONObject] for serialization so all control characters and unicode
 * are escaped correctly — no manual string substitution.
 */
internal fun AstroQrScanResult.encodeForBridge(): String = when (this) {
    is AstroQrScanResult.Success ->
        org.json.JSONObject().put("scannedCode", scannedCode).toString()
    is AstroQrScanResult.Error ->
        org.json.JSONObject().put("error", code.value).toString()
}
