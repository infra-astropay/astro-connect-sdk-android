package com.astropay.connect.views

import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.normalizeStyleOverridesForWire
import com.astropay.connect.core.toBridgeMap
import com.astropay.connect.core.withCascadingDefaults
import com.astropay.connect.utils.JSONConverter
import com.astropay.connect.utils.sanitizeForJs

internal object AstroBridgeManager {
    fun createBridgeScript(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String {
        val flowParamsJson =
            configuration.flowParams?.let {
                JSONConverter.mapToJsonString(it)
            } ?: "null"
        val flowValue = configuration.flow?.let { "'${sanitizeForJs(it)}'" } ?: "null"
        val phoneCodeValue = configuration.phoneCode?.let { "'${sanitizeForJs(it)}'" } ?: "null"
        val phoneNumberValue = configuration.phoneNumber?.let { "'${sanitizeForJs(it)}'" } ?: "null"
        val styleJson =
            configuration.style
                ?.withCascadingDefaults()
                ?.toBridgeMap()
                ?.let { JSONConverter.mapToJsonString(it) }
                ?: "null"
        // Validation already ran on the raw map; here we normalize for the
        // wire so numeric typography values become "<n>px" strings (web's
        // isFontStyle requires strings and silently drops numbers).
        val styleOverridesJson =
            configuration.styleOverrides
                ?.takeIf { it.isNotEmpty() }
                ?.let { normalizeStyleOverridesForWire(it) }
                ?.let { JSONConverter.mapToJsonString(it) }
                ?: "null"

        return """
            (function() {
              console.log('[AstroPayBridge] Starting bridge initialization...');
                try {
                    var nativeInterface = window.AstroPayBridge;

                    var existingCameraCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function')
                        ? window.AstroPayBridge.cameraPermissionCallback
                        : null;
                    var existingBiometricsCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.biometricsResultCallback === 'function')
                        ? window.AstroPayBridge.biometricsResultCallback
                        : null;
                    var existingCheckBiometricCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.checkBiometricResultCallback === 'function')
                        ? window.AstroPayBridge.checkBiometricResultCallback
                        : null;
                    var existingDeleteSeedCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.deleteSeedResultCallback === 'function')
                        ? window.AstroPayBridge.deleteSeedResultCallback
                        : null;
                    var existingGetSeedCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.getSeedResultCallback === 'function')
                        ? window.AstroPayBridge.getSeedResultCallback
                        : null;
                    var existingRegisterDeviceCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.registerDeviceResultCallback === 'function')
                        ? window.AstroPayBridge.registerDeviceResultCallback
                        : null;
                    var existingGenerateTOTPCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.generateTOTPResultCallback === 'function')
                        ? window.AstroPayBridge.generateTOTPResultCallback
                        : null;
                    var existingNativeKycCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.nativeKycResultCallback === 'function')
                        ? window.AstroPayBridge.nativeKycResultCallback
                        : null;
                    var existingQrScanResultCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.qrScanResultCallback === 'function')
                        ? window.AstroPayBridge.qrScanResultCallback
                        : null;
                    // Create the bridge object with properties and wrapper functions
                    window.AstroPayBridge = {
                        platform: '${AstroConstants.PLATFORM}',
                        sdkVersion: '${AstroConstants.SDK_VERSION}',
                        internalSdkVersion: '${AstroConstants.INTERNAL_SDK_VERSION}',
                        environment: '${sanitizeForJs(configuration.environment.value)}',
                        accessToken: '${sanitizeForJs(configuration.accessToken)}',
                        theme: '${sanitizeForJs(themeParameter)}',
                        language: '${sanitizeForJs(configuration.language)}',
                        appIssuer: '${sanitizeForJs(configuration.appIssuer)}',
                        clientId: '${sanitizeForJs(configuration.clientId)}',
                        partnerUserId: '${sanitizeForJs(configuration.partnerUserId)}',
                        phoneCode: $phoneCodeValue,
                        phoneNumber: $phoneNumberValue,
                        flow: $flowValue,
                        flowParams: $flowParamsJson,
                        style: $styleJson,
                        styleOverrides: $styleOverridesJson,
                        embedded: ${configuration.embedded},
                        cameraPermissionCallback: existingCameraCallback,
                        biometricsResultCallback: existingBiometricsCallback,
                        checkBiometricResultCallback: existingCheckBiometricCallback,
                        deleteSeedResultCallback: existingDeleteSeedCallback,
                        getSeedResultCallback: existingGetSeedCallback,
                        registerDeviceResultCallback: existingRegisterDeviceCallback,
                        generateTOTPResultCallback: existingGenerateTOTPCallback,
                        nativeKycResultCallback: existingNativeKycCallback,
                        qrScanResultCallback: existingQrScanResultCallback,

                        notifyLoaded: function() {
                            if (nativeInterface && nativeInterface.notifyLoaded) {
                                nativeInterface.notifyLoaded();
                            }
                        },

                        notifyClose: function(code, message) {
                            if (nativeInterface && nativeInterface.notifyClose) {
                                nativeInterface.notifyClose(code || '', message || '');
                            }
                        },

                        notifyError: function(code, error, severity) {
                            if (nativeInterface && nativeInterface.notifyError) {
                                nativeInterface.notifyError(code || '', error || '', severity || '');
                            }
                        },

                        notifyEvent: function(event) {
                            if (nativeInterface && nativeInterface.notifyEvent) {
                                nativeInterface.notifyEvent(JSON.stringify(event));
                            }
                        },

                        hasCameraPermission: function() {
                            if (nativeInterface && nativeInterface.hasCameraPermission) {
                                // Note: Android @JavascriptInterface cannot return values synchronously to JS.
                                // The native side will call cameraPermissionCallback via evaluateJavascript.
                                nativeInterface.hasCameraPermission();
                            }
                        },

                        requestCameraPermissions: function() {
                            if (nativeInterface && nativeInterface.requestCameraPermissions) {
                                nativeInterface.requestCameraPermissions();
                            }
                        },

                        checkBiometricAvailability: function() {
                            if (nativeInterface && nativeInterface.checkBiometricAvailability) {
                                nativeInterface.checkBiometricAvailability();
                            }
                        },

                        deleteSeed: function() {
                            if (nativeInterface && nativeInterface.deleteSeed) {
                                nativeInterface.deleteSeed();
                            }
                        },

                        getSeed: function() {
                            if (nativeInterface && nativeInterface.getSeed) {
                                nativeInterface.getSeed();
                            }
                        },

                        registerDevice: function(seed) {
                            if (nativeInterface && nativeInterface.registerDevice) {
                                nativeInterface.registerDevice(seed);
                            }
                        },

                        generateTOTP: function() {
                            if (nativeInterface && nativeInterface.generateTOTP) {
                                nativeInterface.generateTOTP();
                            }
                        },

                        startNativeKyc: function(body) {
                            if (nativeInterface && nativeInterface.startNativeKyc) {
                                nativeInterface.startNativeKyc(typeof body === 'string' ? body : JSON.stringify(body));
                            }
                        },

                        openQrScanner: function(texts) {
                            if (nativeInterface && nativeInterface.openQrScanner) {
                                nativeInterface.openQrScanner(JSON.stringify(texts || {}));
                            }
                        }
                    };
                    console.log('[AstroPayBridge] Bridge initialized for Android');
                    return true;
                } catch (e) {
                    console.error('[AstroPayBridge] Failed to initialize bridge:', e);
                    console.error('[AstroPayBridge] Error details:', e.message, e.stack);
                    return false;
                }
            })();
            """.trimIndent()
    }

    /**
     * Creates JavaScript code to send the camera permission result back to the web content.
     *
     * @param status The permission status string.
     * @return The JavaScript code to execute.
     */
    fun createCameraPermissionCallback(status: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function') {
                window.AstroPayBridge.cameraPermissionCallback('${sanitizeForJs(status)}');
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to update a bridge property.
     *
     * @param property The property name.
     * @param value The new value (will be JSON-encoded if needed).
     * @return The JavaScript code to execute.
     */
    fun createPropertyUpdate(
        property: String,
        value: Any,
    ): String {
        val jsValue =
            when (value) {
                is String -> {
                    "'${sanitizeForJs(value)}'"
                }

                is Boolean -> {
                    value.toString()
                }

                is Number -> {
                    value.toString()
                }

                is Map<*, *> -> {
                    @Suppress("UNCHECKED_CAST")
                    JSONConverter.mapToJsonString(value as Map<String, Any>)
                }

                else -> {
                    "'${sanitizeForJs(value.toString())}'"
                }
            }

        return """
            (function() {
                if (window.AstroPayBridge) {
                    window.AstroPayBridge.$property = $jsValue;
                }
            })();
            """.trimIndent()
    }

    /**
     * Creates JavaScript code to send the biometric availability check result back to the web content.
     *
     * @param resultJson The JSON result string (OK or error).
     * @return The JavaScript code to execute.
     */
    fun createCheckBiometricCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.checkBiometricResultCallback === 'function') {
                window.AstroPayBridge.checkBiometricResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the delete seed result back to the web content.
     *
     * @param resultJson The JSON result string (OK or error).
     * @return The JavaScript code to execute.
     */
    fun createDeleteSeedCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.deleteSeedResultCallback === 'function') {
                window.AstroPayBridge.deleteSeedResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the get seed result back to the web content.
     *
     * @param resultJson The JSON result string (OK with seed or error).
     * @return The JavaScript code to execute.
     */
    fun createGetSeedCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.getSeedResultCallback === 'function') {
                window.AstroPayBridge.getSeedResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the register device result back to the web content.
     *
     * @param resultJson The JSON result string (success or error).
     * @return The JavaScript code to execute.
     */
    fun createRegisterDeviceCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.registerDeviceResultCallback === 'function') {
                window.AstroPayBridge.registerDeviceResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the TOTP generation result back to the web content.
     *
     * @param resultJson The JSON result string (success or error).
     * @return The JavaScript code to execute.
     */
    fun createGenerateTOTPCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.generateTOTPResultCallback === 'function') {
                window.AstroPayBridge.generateTOTPResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the native KYC result back to the web content.
     *
     * @param resultJson The JSON result object string (already valid JSON, not a string literal).
     * @return The JavaScript code to execute.
     */
    fun createNativeKycCallback(resultJson: String): String =
        """
        (function() {
            var cb = window.${AstroConstants.Bridge.OBJECT_NAME} &&
                     window.${AstroConstants.Bridge.OBJECT_NAME}.nativeKycResultCallback;
            if (typeof cb !== 'function') {
                return 'no_callback:' + (typeof cb);
            }
            var nativeResult = $resultJson;
            console.log('[APC-KYC] callback — status=' + nativeResult.status);
            cb(nativeResult);
            return 'called';
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to deliver a QR scan result back to the web content.
     *
     * @param resultJson The JSON result string (either `{"scannedCode":"…"}` or
     *   `{"error":"…"}`). Caller is responsible for JSON correctness — see
     *   `AstroQrScanResult.encodeForBridge()`.
     * @return The JavaScript code to execute.
     */
    fun createQrScanResultCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.qrScanResultCallback === 'function') {
                window.AstroPayBridge.qrScanResultCallback($resultJson);
            }
        })();
        """.trimIndent()
}