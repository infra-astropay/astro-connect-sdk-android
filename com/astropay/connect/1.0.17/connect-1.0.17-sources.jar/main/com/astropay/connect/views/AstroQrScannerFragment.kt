package com.astropay.connect.views

import android.Manifest
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.Button
import android.widget.FrameLayout
import android.widget.FrameLayout.LayoutParams.MATCH_PARENT
import android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.astropay.connect.core.AstroQrScanError
import com.astropay.connect.core.AstroQrScanResult
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Localized UI strings passed from the web layer when opening the QR scanner.
 *
 * All fields fall back to empty strings if the web layer omits them.
 */
internal data class AstroQrScannerTexts(
    val title: String,
    val cancelText: String,
    val lowLightWarning: String,
)

/**
 * Full-screen SDK-owned QR scanner fragment. Uses CameraX + bundled ML Kit for
 * barcode decoding. Delivers a result exactly once through a companion-level callback
 * registered via [newInstance], then dismisses itself.
 *
 * Not part of the public SDK surface — never exposed to host app partners.
 */
internal class AstroQrScannerFragment : DialogFragment() {

    private val delivered = AtomicBoolean(false)
    private lateinit var cameraExecutor: ExecutorService
    private var previewView: PreviewView? = null
    private var camera: Camera? = null
    private var torchButtonView: Button? = null
    private var isTorchOn = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startCamera()
        } else {
            deliverResult(AstroQrScanResult.Error(AstroQrScanError.PERMISSION_DENIED))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        cameraExecutor = Executors.newSingleThreadExecutor()
        val texts = textsStore[TAG] ?: AstroQrScannerTexts("", "Cancel", "")
        val ctx = requireContext()
        val density = resources.displayMetrics.density

        val frame = FrameLayout(ctx)

        // 1. Camera preview — full screen
        val pv = PreviewView(ctx).also { previewView = it }
        frame.addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // 2. Dark overlay with rounded-rect scan window cutout — full screen, above preview
        val overlay = ScannerOverlayView(ctx)
        frame.addView(overlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // 3. Torch button — circular, centered horizontally, below the scan window
        val btnSize = (56 * density).toInt()
        val torchBtn = Button(ctx).apply {
            text = "⚡" // lightning bolt character as flashlight placeholder
            setTextColor(Color.WHITE)
            textSize = 18f
            background = circularBackground(false)
            visibility = View.GONE // shown after camera binds and flash availability is checked
            contentDescription = "Toggle torch"
            setOnClickListener { toggleTorch() }
        }
        torchButtonView = torchBtn

        val torchParams = FrameLayout.LayoutParams(btnSize, btnSize).apply {
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            topMargin = 0 // set after layout via ViewTreeObserver
        }
        frame.addView(torchBtn, torchParams)

        // 4. Title label — top center, white text, above overlay
        if (texts.title.isNotEmpty()) {
            val titleTv = TextView(ctx).apply {
                text = texts.title
                setTextColor(Color.WHITE)
                textSize = 20f
                gravity = Gravity.CENTER
            }
            val titleParams = FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = (56 * density).toInt()
            }
            frame.addView(titleTv, titleParams)
        }

        // 5. Cancel button — bottom center, transparent background, white text
        val cancelBtn = Button(ctx).apply {
            text = texts.cancelText.ifEmpty { "Cancel" }
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                deliverResult(AstroQrScanResult.Error(AstroQrScanError.USER_CANCELLED))
            }
        }
        val cancelParams = FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = (48 * density).toInt()
        }
        frame.addView(cancelBtn, cancelParams)

        // Position torch button below the scan window once layout dimensions are known
        frame.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                frame.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val scanSize = frame.width * 0.7f
                val scanBottom = (frame.height + scanSize) / 2f
                val margin = scanBottom + (32 * density)
                torchParams.topMargin = margin.toInt()
                torchBtn.layoutParams = torchParams
            }
        })

        return frame
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val context = requireContext()
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView?.surfaceProvider)
            }

            val barcodeScanner = BarcodeScanning.getClient()
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage != null) {
                    val inputImage = InputImage.fromMediaImage(
                        mediaImage,
                        imageProxy.imageInfo.rotationDegrees,
                    )
                    barcodeScanner.process(inputImage)
                        .addOnSuccessListener { barcodes ->
                            barcodes.firstOrNull()?.rawValue?.let { code ->
                                deliverResult(AstroQrScanResult.Success(code))
                            }
                        }
                        .addOnCompleteListener { imageProxy.close() }
                } else {
                    imageProxy.close()
                }
            }

            try {
                cameraProvider.unbindAll()
                val boundCamera = cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis,
                )
                this.camera = boundCamera
                activity?.runOnUiThread { updateTorchButtonVisibility() }
            } catch (e: Exception) {
                deliverResult(AstroQrScanResult.Error(AstroQrScanError.SCAN_FAILED))
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun updateTorchButtonVisibility() {
        val hasFlash = camera?.cameraInfo?.hasFlashUnit() ?: false
        torchButtonView?.visibility = if (hasFlash) View.VISIBLE else View.GONE
    }

    private fun toggleTorch() {
        isTorchOn = !isTorchOn
        camera?.cameraControl?.enableTorch(isTorchOn)
        updateTorchIcon()
    }

    private fun updateTorchIcon() {
        torchButtonView?.background = circularBackground(isTorchOn)
        torchButtonView?.setTextColor(if (isTorchOn) Color.BLACK else Color.WHITE)
    }

    private fun circularBackground(filled: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (filled) 0xFFFFFFFF.toInt() else 0x55FFFFFF.toInt())
        }
    }

    private fun deliverResult(result: AstroQrScanResult) {
        if (delivered.compareAndSet(false, true)) {
            if (!cameraExecutor.isShutdown) cameraExecutor.shutdown()
            val hostActivity = activity ?: return
            hostActivity.runOnUiThread {
                callbacks[TAG]?.invoke(result)
                callbacks.remove(TAG)
                textsStore.remove(TAG)
                dismissAllowingStateLoss()
            }
        }
    }

    override fun onCancel(dialog: DialogInterface) {
        deliverResult(AstroQrScanResult.Error(AstroQrScanError.USER_CANCELLED))
        super.onCancel(dialog)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (!cameraExecutor.isShutdown) cameraExecutor.shutdown()
    }

    // ---------------------------------------------------------------------------
    // ScannerOverlayView — semi-transparent dark overlay with a clear rounded-rect
    // cutout centred on screen (70 % of screen width, square, corner radius 30 dp).
    // Uses PorterDuff.Mode.CLEAR on a saved Canvas layer so the cutout is truly
    // transparent (shows through to the camera preview beneath).
    // ---------------------------------------------------------------------------
    private inner class ScannerOverlayView(context: Context) : View(context) {

        private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x77000000.toInt()
        }

        private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }

        private val cornerRadiusPx: Float by lazy {
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                30f,
                resources.displayMetrics,
            )
        }

        override fun onDraw(canvas: Canvas) {
            val sc = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)
            val scanSize = width * 0.7f
            val left = (width - scanSize) / 2f
            val top = (height - scanSize) / 2f
            val rectF = RectF(left, top, left + scanSize, top + scanSize)
            canvas.drawRoundRect(rectF, cornerRadiusPx, cornerRadiusPx, clearPaint)
            canvas.restoreToCount(sc)
        }
    }

    companion object {
        private val callbacks = mutableMapOf<String, (AstroQrScanResult) -> Unit>()
        private val textsStore = mutableMapOf<String, AstroQrScannerTexts>()
        private const val TAG = "AstroQrScannerFragment"

        /**
         * Creates a new [AstroQrScannerFragment] and registers [onResult] as the
         * one-shot delivery callback. Stores [texts] so [onCreateView] can apply
         * localized strings to the UI. Show the returned fragment via
         * `fragmentManager.show(fragment, "qr_scanner")`.
         */
        fun newInstance(texts: AstroQrScannerTexts, onResult: (AstroQrScanResult) -> Unit): AstroQrScannerFragment {
            callbacks[TAG] = onResult
            textsStore[TAG] = texts
            return AstroQrScannerFragment()
        }
    }
}
