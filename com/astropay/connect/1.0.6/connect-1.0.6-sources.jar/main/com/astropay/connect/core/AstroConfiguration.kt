package com.astropay.connect.core

/**
 * Configuration class for AstroPay Connect SDK.
 * Contains all the parameters needed to initialize and configure the SDK.
 */
class AstroConfiguration(
    environment: String,
    val appIssuer: String,
    val accessToken: String,
    val theme: AstroTheme = AstroTheme.SYSTEM,
    val language: String = "en",
    val flow: String? = null,
    val flowParams: Map<String, Any>? = null,
    val showCloseButton: Boolean? = true,
    val autoSize: Boolean? = true,
    val embedded: Boolean = true,
    val logSetting: AstroLogSetting = AstroLogSetting(enabled = false),
    val localIP: String? = null,
) {
    /**
     * Internal environment enum for SDK use.
     */
    internal val environment: AstroEnvironment = AstroEnvironment.fromString(environment)

    /**
     * Validates the configuration and throws an exception if invalid.
     */
    @Throws(AstroConfigurationException::class)
    fun validate() {
        if (appIssuer.isBlank()) {
            throw AstroConfigurationException("appIssuer is required")
        }
        // if (accessToken.isBlank()) {
        //     throw AstroConfigurationException("accessToken is required")
        // }
        if (environment.isUnknown) {
            throw AstroConfigurationException("Environment is not supported")
        }
        if (environment.isLocal && localIP.isNullOrBlank()) {
            throw AstroConfigurationException("localIP is required for local environment")
        }
    }

    /**
     * Builder class for creating AstroConfiguration instances.
     */
    class Builder {
        private var environment: String = "sandbox"
        private var appIssuer: String = ""
        private var accessToken: String = ""
        private var theme: AstroTheme = AstroTheme.SYSTEM
        private var language: String = "en"
        private var flow: String? = null
        private var flowParams: Map<String, Any>? = null
        private var showCloseButton: Boolean? = true
        private var autoSize: Boolean? = true
        private var embedded: Boolean = true
        private var logSetting: AstroLogSetting = AstroLogSetting(enabled = false)
        private var localIP: String? = null

        fun setEnvironment(environment: String): Builder {
            this.environment = environment
            return this
        }

        fun setAppIssuer(appIssuer: String): Builder {
            this.appIssuer = appIssuer
            return this
        }

        fun setAccessToken(accessToken: String): Builder {
            this.accessToken = accessToken
            return this
        }

        fun setTheme(theme: AstroTheme): Builder {
            this.theme = theme
            return this
        }

        fun setLanguage(language: String): Builder {
            this.language = language
            return this
        }

        fun setFlow(flow: String?): Builder {
            this.flow = flow
            return this
        }

        fun setFlowParams(flowParams: Map<String, Any>?): Builder {
            this.flowParams = flowParams
            return this
        }

        fun setEmbedded(embedded: Boolean): Builder {
            this.embedded = embedded
            return this
        }

        fun setLogSetting(logSetting: AstroLogSetting): Builder {
            this.logSetting = logSetting
            return this
        }

        fun setLocalIP(localIP: String?): Builder {
            this.localIP = localIP
            return this
        }

        fun setShowCloseButton(showCloseButton: Boolean?): Builder {
            this.showCloseButton = showCloseButton
            return this
        }

        fun setAutoSize(autoSize: Boolean?): Builder {
            this.autoSize = autoSize
            return this
        }

        /**
         * Builds the configuration without validation.
         * Validation is performed internally by the SDK when starting.
         */
        fun build(): AstroConfiguration =
            AstroConfiguration(
                environment = environment,
                appIssuer = appIssuer,
                accessToken = accessToken,
                theme = theme,
                language = language,
                flow = flow,
                flowParams = flowParams,
                showCloseButton = showCloseButton,
                autoSize = autoSize,
                embedded = embedded,
                logSetting = logSetting,
                localIP = localIP,
            )
    }

    companion object {
        /**
         * Creates a new Builder instance.
         */
        fun builder(): Builder = Builder()
    }

    override fun toString(): String {
        val result =
            """
            AstroConfiguration(
              environment: $environment,
              appIssuer: $appIssuer,
              accessToken: ${if (accessToken.isBlank()) "nil" else "****"},
              theme: $theme,
              language: $language,
              flow: $flow,
              flowParams: $flowParams,
              showCloseButton: $showCloseButton,
              autoSize: $autoSize,
              embedded: $embedded,
            """.trimIndent()

        return if (environment.isLocal) {
            "$result\n  localIP: $localIP\n)"
        } else {
            "$result\n)"
        }
    }
}

/**
 * Exception thrown when configuration validation fails.
 */
class AstroConfigurationException(
    message: String,
) : Exception(message)
