package com.astropay.connect.views

import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.utils.JSONConverter

internal object AstroBridgeManager {
    fun createBridgeScript(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String {
        val flowParamsJson =
            configuration.flowParams?.let {
                JSONConverter.mapToJsonString(it)
            } ?: "null"
        val flowValue = configuration.flow?.let { "'$it'" } ?: "null"
        val phoneCodeValue = configuration.phoneCode?.let { "'$it'" } ?: "null"
        val phoneNumberValue = configuration.phoneNumber?.let { "'$it'" } ?: "null"

        return """
            (function() {

                var nativeInterface = window.AstroPayBridge;

                var existingCameraCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function')
                    ? window.AstroPayBridge.cameraPermissionCallback
                    : null;
                var existingBiometricsCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.biometricsResultCallback === 'function')
                    ? window.AstroPayBridge.biometricsResultCallback
                    : null;
                var existingRegisterDeviceCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.registerDeviceResultCallback === 'function')
                    ? window.AstroPayBridge.registerDeviceResultCallback
                    : null;
                var existingGenerateTOTPCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.generateTOTPResultCallback === 'function')
                    ? window.AstroPayBridge.generateTOTPResultCallback
                    : null;

                // Create the bridge object with properties and wrapper functions
                window.AstroPayBridge = {
                    platform: '${AstroConstants.PLATFORM}',
                    sdkVersion: '${AstroConstants.SDK_VERSION}',
                    internalSdkVersion: '${AstroConstants.INTERNAL_SDK_VERSION}',
                    environment: '${configuration.environment.value}',
                    accessToken: '${configuration.accessToken}',
                    theme: '$themeParameter',
                    language: '${configuration.language}',
                    appIssuer: '${configuration.appIssuer}',
                    clientId: '${configuration.clientId}',
                    partnerUserId: '${configuration.partnerUserId}',
                    phoneCode: $phoneCodeValue,
                    phoneNumber: $phoneNumberValue,
                    flow: $flowValue,
                    flowParams: $flowParamsJson,
                    embedded: ${configuration.embedded},
                    cameraPermissionCallback: existingCameraCallback,
                    biometricsResultCallback: existingBiometricsCallback,
                    registerDeviceResultCallback: existingRegisterDeviceCallback,
                    generateTOTPResultCallback: existingGenerateTOTPCallback,

                    notifyLoaded: function() {
                        if (nativeInterface && nativeInterface.notifyLoaded) {
                            nativeInterface.notifyLoaded();
                        }
                    },

                    notifyClose: function() {
                        if (nativeInterface && nativeInterface.notifyClose) {
                            nativeInterface.notifyClose();
                        }
                    },

                    notifyError: function(code, error, severity) {
                        if (nativeInterface && nativeInterface.notifyError) {
                            nativeInterface.notifyError(code || '', error || '', severity || '');
                        }
                    },

                    notifyEvent: function(event) {
                        if (nativeInterface && nativeInterface.notifyEvent) {
                            nativeInterface.notifyEvent(JSON.stringify(event));
                        }
                    },

                    hasCameraPermission: function() {
                        if (nativeInterface && nativeInterface.hasCameraPermission) {
                            // Note: Android @JavascriptInterface cannot return values synchronously to JS.
                            // The native side will call cameraPermissionCallback via evaluateJavascript.
                            nativeInterface.hasCameraPermission();
                        }
                    },

                    requestCameraPermissions: function() {
                        if (nativeInterface && nativeInterface.requestCameraPermissions) {
                            nativeInterface.requestCameraPermissions();
                        }
                    },

                    registerDevice: function(seed) {
                        if (nativeInterface && nativeInterface.registerDevice) {
                            nativeInterface.registerDevice(seed);
                        }
                    },

                    generateTOTP: function() {
                        if (nativeInterface && nativeInterface.generateTOTP) {
                            nativeInterface.generateTOTP();
                        }
                    }
                };

                console.log('[AstroPayBridge] Bridge initialized for Android');
            })();
            """.trimIndent()
    }

    /**
     * Creates JavaScript code to send the camera permission result back to the web content.
     *
     * @param status The permission status string.
     * @return The JavaScript code to execute.
     */
    fun createCameraPermissionCallback(status: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function') {
                window.AstroPayBridge.cameraPermissionCallback('$status');
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to update a bridge property.
     *
     * @param property The property name.
     * @param value The new value (will be JSON-encoded if needed).
     * @return The JavaScript code to execute.
     */
    fun createPropertyUpdate(
        property: String,
        value: Any,
    ): String {
        val jsValue =
            when (value) {
                is String -> {
                    "'$value'"
                }

                is Boolean -> {
                    value.toString()
                }

                is Number -> {
                    value.toString()
                }

                is Map<*, *> -> {
                    @Suppress("UNCHECKED_CAST")
                    JSONConverter.mapToJsonString(value as Map<String, Any>)
                }

                else -> {
                    "'$value'"
                }
            }

        return """
            (function() {
                if (window.AstroPayBridge) {
                    window.AstroPayBridge.$property = $jsValue;
                }
            })();
            """.trimIndent()
    }

    /**
     * Creates JavaScript code to send the register device result back to the web content.
     *
     * @param resultJson The JSON result string (success or error).
     * @return The JavaScript code to execute.
     */
    fun createRegisterDeviceCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.registerDeviceResultCallback === 'function') {
                window.AstroPayBridge.registerDeviceResultCallback($resultJson);
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to send the TOTP generation result back to the web content.
     *
     * @param resultJson The JSON result string (success or error).
     * @return The JavaScript code to execute.
     */
    fun createGenerateTOTPCallback(resultJson: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.generateTOTPResultCallback === 'function') {
                window.AstroPayBridge.generateTOTPResultCallback($resultJson);
            }
        })();
        """.trimIndent()
}
