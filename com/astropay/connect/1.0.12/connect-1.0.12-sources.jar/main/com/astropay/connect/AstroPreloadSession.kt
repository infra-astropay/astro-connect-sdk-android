package com.astropay.connect

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.MainThread
import com.astropay.connect.core.AppContext
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.utils.ThemeManager
import com.astropay.connect.views.AstroBridgeInterface
import com.astropay.connect.views.AstroWebViewClient

/**
 * Manages a pre-loaded SDK WebView so subsequent [AstroConnect] invocations render
 * without visible loaders.
 *
 * Call [start] as early as possible (e.g. just after the user logs in or just before
 * opening a flow). When [AstroConnectView] mounts it calls [claim]: if the stored
 * session matches the current configuration the preloaded [WebView] is handed off and
 * shown immediately; otherwise a fresh WebView is created as usual.
 */
internal object AstroPreloadSession {

    data class Session(
        val webView: WebView,
        val bridge: AstroBridgeInterface,
        val matchKey: String,
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var session: Session? = null
    private var pendingSuccess: (() -> Unit)? = null
    private var pendingError: ((AstroError) -> Unit)? = null

    // -----------------------------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    @MainThread
    fun start(
        configuration: AstroConfiguration,
        onSuccess: (() -> Unit)?,
        onError: ((AstroError) -> Unit)?,
    ) {
        val themeParameter = ThemeManager.getThemeParameter(AppContext.get(), configuration.theme)
        val matchKey = buildMatchKey(configuration, themeParameter)

        session?.let { existing ->
            if (existing.matchKey == matchKey && existing.bridge.isLoaded) {
                AstroLogger.logDebug("AstroPreloadSession: already loaded — firing success immediately")
                onSuccess?.invoke()
                return
            }
        }

        discard()

        val url = buildPreloadURL(configuration, themeParameter)
        if (url == null) {
            onError?.invoke(
                AstroError(ErrorCode.INITIALIZATION_ERROR, null, "AstroPreloadSession: invalid configuration"),
            )
            return
        }

        pendingSuccess = onSuccess
        pendingError = onError

        val bridge = AstroBridgeInterface()
        bridge.onLoaded = {
            mainHandler.post {
                AstroLogger.logInfo("AstroPreloadSession: page loaded")
                pendingSuccess?.invoke()
                pendingSuccess = null
                pendingError = null
            }
        }
        bridge.onError = { error ->
            mainHandler.post {
                AstroLogger.logDebug("AstroPreloadSession: page error — ${error.errorDetail}")
                pendingError?.invoke(error)
                pendingSuccess = null
                pendingError = null
            }
        }

        val wv = WebView(AppContext.get())
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        wv.addJavascriptInterface(bridge, AstroConstants.Bridge.OBJECT_NAME)
        wv.webViewClient = AstroWebViewClient(
            configuration = configuration,
            themeParameter = themeParameter,
            onPageStarted = {},
            onPageFinished = {},
            onError = { error ->
                mainHandler.post {
                    pendingError?.invoke(error)
                    pendingSuccess = null
                    pendingError = null
                }
            },
        )

        session = Session(webView = wv, bridge = bridge, matchKey = matchKey)

        AstroLogger.logDebug("AstroPreloadSession: loading $url")
        wv.loadUrl(url, mapOf(AstroConstants.Bridge.SDK_HEADER_NAME to AstroConstants.Bridge.SDK_HEADER_VALUE))
    }

    /**
     * Claims the preloaded session if it matches [configuration] and [themeParameter].
     * Returns `null` if there is no session or the configuration does not match (in
     * which case the existing session is discarded).
     */
    @MainThread
    fun claim(configuration: AstroConfiguration, themeParameter: String): Session? {
        val matchKey = buildMatchKey(configuration, themeParameter)
        val existing = session ?: return null
        return if (existing.matchKey == matchKey) {
            session = null
            AstroLogger.logDebug("AstroPreloadSession: claimed (isLoaded=${existing.bridge.isLoaded})")
            existing
        } else {
            AstroLogger.logDebug("AstroPreloadSession: config mismatch — discarding preload")
            discard()
            null
        }
    }

    /**
     * Returns the pending preload callbacks and clears them.
     * Call after a successful [claim] so [AstroConnectView] can chain them into the real
     * onLoaded / onError — ensuring the preload caller is always notified even when the SDK
     * is opened before the preload finishes.
     */
    @MainThread
    fun takePendingCallbacks(): Pair<(() -> Unit)?, ((AstroError) -> Unit)?> {
        val s = pendingSuccess
        val e = pendingError
        pendingSuccess = null
        pendingError = null
        return Pair(s, e)
    }

    @MainThread
    fun discard() {
        session?.webView?.apply {
            stopLoading()
            destroy()
        }
        session = null
        pendingSuccess = null
        pendingError = null
    }

    // -----------------------------------------------------------------------------------------
    // Internal
    // -----------------------------------------------------------------------------------------

    private fun buildMatchKey(configuration: AstroConfiguration, themeParameter: String): String {
        val flowParamsStr = configuration.flowParams
            ?.entries?.sortedBy { it.key }
            ?.joinToString(",") { "${it.key}=${it.value}" }
            ?: ""
        return listOf(
            configuration.environment.value,
            configuration.accessToken,
            configuration.language,
            themeParameter,
            configuration.appIssuer,
            configuration.clientId,
            configuration.partnerUserId,
            configuration.flow ?: "",
            flowParamsStr,
            configuration.phoneCode ?: "",
            configuration.phoneNumber ?: "",
            "${configuration.embedded}",
        ).joinToString("|")
    }

    private fun buildPreloadURL(configuration: AstroConfiguration, themeParameter: String): String? {
        val baseURL = configuration.environment.getBaseURL(configuration.localIP) ?: return null
        return Uri
            .parse(baseURL)
            .buildUpon()
            .appendQueryParameter(AstroConstants.QueryParams.THEME, themeParameter)
            .appendQueryParameter(AstroConstants.QueryParams.ACCESS_TOKEN, configuration.accessToken)
            .appendQueryParameter(AstroConstants.QueryParams.LANGUAGE, configuration.language)
            .build()
            .toString()
    }
}
