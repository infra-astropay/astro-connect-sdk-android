package com.astropay.connect.views

import android.webkit.JavascriptInterface
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroEvent
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.utils.JSONConverter
import org.json.JSONObject

/**
 * JavaScript interface for AstroPay Connect bridge.
 * Provides native methods that can be called from JavaScript.
 *
 * Note: @JavascriptInterface methods run on a background thread and cannot
 * return values synchronously to JavaScript. All results must be sent via
 * evaluateJavascript callbacks.
 *
 * Callbacks are @Volatile mutable properties so they can be updated when the
 * view remounts without re-registering the JS interface (which only takes
 * effect on the next page load).
 */
internal class AstroBridgeInterface {

    @Volatile var onLoaded: () -> Unit = {}
    @Volatile var onClose: () -> Unit = {}
    @Volatile var onError: (AstroError) -> Unit = {}
    @Volatile var onEvent: (AstroEvent) -> Unit = {}
    @Volatile var onCheckCameraPermission: () -> Unit = {}
    @Volatile var onRequestCameraPermission: () -> Unit = {}
    @Volatile var onCheckBiometricAvailability: () -> Unit = {}
    @Volatile var onDeleteSeed: () -> Unit = {}
    @Volatile var onGetSeed: () -> Unit = {}
    @Volatile var onRegisterDevice: (String) -> Unit = { _ -> }
    @Volatile var onGenerateTOTP: () -> Unit = {}

    @Volatile private var hasNotifiedLoaded = false

    val isLoaded: Boolean get() = hasNotifiedLoaded

    fun resetLoadState() {
        hasNotifiedLoaded = false
    }

    /**
     * Called when the SDK page has finished loading.
     * Uses a flag to ensure this is only processed once, since the bridge
     * may be injected multiple times (onPageStarted and onPageFinished).
     */
    @JavascriptInterface
    fun notifyLoaded() {
        if (hasNotifiedLoaded) {
            return
        }
        hasNotifiedLoaded = true
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.NOTIFY_LOADED}")
        onLoaded()
    }

    /**
     * Called when the user closes the SDK.
     */
    @JavascriptInterface
    fun notifyClose() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.NOTIFY_CLOSE}")
        onClose()
    }

    /**
     * Called when an error occurs in the SDK.
     */
    @JavascriptInterface
    fun notifyError(
        code: String,
        error: String,
        severity: String,
    ) {
        val astroError = AstroError(ErrorCode.BRIDGE_ERROR, code, error)
        AstroLogger.logError(astroError)
        onError(astroError)
    }

    /**
     * Called when an analytics event is received from the SDK.
     */
    @JavascriptInterface
    fun notifyEvent(eventJson: String) {
        try {
            val event = parseEventJson(eventJson)
            onEvent(event)
        } catch (e: Exception) {
            val error = AstroError(ErrorCode.BRIDGE_ERROR, "01", "Failed to parse event: ${e.message}")
            AstroLogger.logError(error)
        }
    }

    private fun parseEventJson(json: String): AstroEvent {
        val eventMap =
            JSONConverter.jsonStringToMap(json)
                ?: throw IllegalArgumentException("Invalid JSON: $json")

        @Suppress("UNCHECKED_CAST")
        return AstroEvent(
            screenName = eventMap["screenName"] as? String ?: "",
            eventName = eventMap["eventName"] as? String ?: "",
            eventCategory = eventMap["eventCategory"] as? String ?: "",
            eventProperties = eventMap["eventProperties"] as? Map<String, Any>,
            sessionId = eventMap["sessionId"] as? String ?: "",
            appVersion = eventMap["appVersion"] as? String ?: "",
            platform = eventMap["platform"] as? String ?: "",
        )
    }

    /**
     * Checks if camera permission is granted.
     * The result is sent via cameraPermissionCallback using evaluateJavascript.
     */
    @JavascriptInterface
    fun hasCameraPermission() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.HAS_CAMERA_PERMISSION}")
        onCheckCameraPermission()
    }

    /**
     * Requests camera permission from the user.
     * The result is sent via cameraPermissionCallback.
     */
    @JavascriptInterface
    fun requestCameraPermissions() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.REQUEST_CAMERA_PERMISSIONS}")
        onRequestCameraPermission()
    }

    /**
     * Checks if biometric authentication is available on the device.
     * The result is sent via checkBiometricResultCallback.
     */
    @JavascriptInterface
    fun checkBiometricAvailability() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.CHECK_BIOMETRIC_AVAILABILITY}")
        onCheckBiometricAvailability()
    }

    /**
     * Deletes the stored TOTP seed from the device.
     * The result is sent via deleteSeedResultCallback.
     */
    @JavascriptInterface
    fun deleteSeed() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.DELETE_SEED}")
        onDeleteSeed()
    }

    /**
     * Retrieves the stored TOTP seed from the device.
     * The result is sent via getSeedResultCallback.
     */
    @JavascriptInterface
    fun getSeed() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.GET_SEED}")
        onGetSeed()
    }

    /**
     * Registers the device for biometric 2FA.
     * Stores the provided TOTP seed securely with biometric protection.
     * The result is sent via registerDeviceResultCallback.
     */
    @JavascriptInterface
    fun registerDevice(seed: String) {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.REGISTER_DEVICE}")
        onRegisterDevice(seed)
    }

    /**
     * Generates a TOTP code using the stored seed.
     * Requires biometric authentication to access the stored seed.
     * The result is sent via generateTOTPResultCallback.
     */
    @JavascriptInterface
    fun generateTOTP() {
        AstroLogger.logDebug("Bridge: ${AstroConstants.Bridge.MessageHandlers.GENERATE_TOTP}")
        onGenerateTOTP()
    }
}
