package com.astropay.connect.views

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentActivity
import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConfigurationException
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.core.AstroError
import com.astropay.connect.core.AstroEvent
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.AstroResult
import com.astropay.connect.core.ErrorCode
import com.astropay.connect.core.IssuerLogoCache
import com.astropay.connect.core.parseHexColor
import com.astropay.connect.AstroPreloadSession
import com.astropay.connect.utils.BiometricManager
import com.astropay.connect.utils.CameraManager
import com.astropay.connect.utils.ThemeManager
import com.astropay.connect.utils.URLBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Composable that displays the AstroPay Connect SDK inline.
 * This is equivalent to the iOS `.astroConnect()` modifier.
 *
 * Usage:
 * ```kotlin
 * AstroConnectView(
 *     configuration = configuration,
 *     onResult = { result ->
 *         when (result) {
 *             is AstroResult.Success -> // Handle success
 *             is AstroResult.Failure -> // Handle error
 *             is AstroResult.Closed -> // Handle user closed
 *         }
 *     }
 * )
 * ```
 *
 * @param configuration The SDK configuration.
 * @param modifier Modifier for the composable.
 * @param loadingContent Optional custom loading content. If null, a default CircularProgressIndicator is shown.
 * @param onResult Callback for SDK result.
 */
@SuppressLint("ClickableViewAccessibility")
@Composable
fun AstroConnectView(
    configuration: AstroConfiguration,
    modifier: Modifier = Modifier,
    loadingContent: @Composable (() -> Unit)? = null,
    onResult: (AstroResult) -> Unit,
) {
    val context = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingBridgePermissionRequest by remember { mutableStateOf(false) }
    var pendingTOTPGeneration by remember { mutableStateOf(false) }

    val themeParameter = remember { ThemeManager.getThemeParameter(context, configuration.theme) }

    fun defaultMainBGColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF041311)
            "light" -> Color(0xFFFFFFFF)
            else -> Color(0xFF041311)
        }

    fun defaultTopBarBGColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF061E1D)
            "light" -> Color(0xFFEFEFEF)
            else -> Color(0xFF061E1D)
        }

    fun defaultTopBarBorderColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFF061E1D)
            "light" -> Color(0xFFEFEFEF)
            else -> Color(0xFF061E1D)
        }

    fun defaultCloseColor(themeParameter: String): Color =
        when (themeParameter) {
            "dark" -> Color(0xFFF2F2F2)
            "light" -> Color(0xFF262626)
            else -> Color(0xFFF2F2F2)
        }

    val resolvedMainBGColor = configuration.style?.backgroundColor?.let { parseHexColor(it) }
        ?: defaultMainBGColor(themeParameter)
    val resolvedHeaderBGColor = configuration.style?.header?.backgroundColor?.let { parseHexColor(it) }
        ?: defaultTopBarBGColor(themeParameter)
    val resolvedHeaderBorderColor = configuration.style?.header?.borderColor?.let { parseHexColor(it) }
        ?: defaultTopBarBorderColor(themeParameter)
    val resolvedHeaderBorderWidth = configuration.style?.header?.borderWidth ?: 2f
    val resolvedHeaderPaddingH = configuration.style?.header?.paddingHorizontal ?: 8f
    val resolvedHeaderPaddingV = configuration.style?.header?.paddingVertical ?: 8f

    // Configure logger and validate configuration synchronously before any UI is rendered
    // This matches iOS behavior where validation happens in init() before the view is created
    val configurationError =
        remember {
            AstroLogger.configure(configuration.logSetting, configuration.environment)
            BiometricManager.configure(configuration.biometricGracePeriodMs)
            AstroLogger.logDebug("Initialization")
            AstroLogger.logDebug("$configuration")

            try {
                configuration.validate()
                AstroLogger.logInfo("AstroConnect - initialized")
                null
            } catch (e: AstroConfigurationException) {
                val error = AstroError(ErrorCode.INVALID_CONFIGURATION, null, e.message)
                AstroLogger.logError(error)
                error
            }
        }

    // If configuration validation failed, report error and don't render the view
    if (configurationError != null) {
        LaunchedEffect(Unit) {
            onResult(AstroResult.Failure(configurationError))
        }
        return
    }

    // Camera permission launcher
    val cameraPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission(),
        ) { granted ->
            val status = CameraManager.getStatusFromResult(granted)

            // Handle pending web permission request
            pendingPermissionRequest?.let { request ->
                if (granted) {
                    request.grant(request.resources)
                } else {
                    request.deny()
                }
                pendingPermissionRequest = null
            }

            // Send callback to JavaScript if request came from bridge
            if (pendingBridgePermissionRequest) {
                pendingBridgePermissionRequest = false
                webView?.let { wv ->
                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                    wv.evaluateJavascript(script, null)
                }
            }
        }

    // TOTP generation launcher (KeyguardManager fallback)
    val totpAuthLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (!pendingTOTPGeneration) {
                AstroLogger.logDebug("TOTP auth result but no pending generation")
                return@rememberLauncherForActivityResult
            }
            pendingTOTPGeneration = false

            val resultJson =
                if (result.resultCode == Activity.RESULT_OK) {
                    // Authentication successful - generate TOTP
                    when (val totpResult = BiometricManager.generateTOTPAfterAuth(context)) {
                        is BiometricManager.GenerateTOTPResult.Success -> {
                            JSONObject()
                                .apply {
                                    put("status", "OK")
                                    put("code", totpResult.code)
                                    put("remainingSeconds", totpResult.remainingSeconds)
                                }.toString()
                        }

                        is BiometricManager.GenerateTOTPResult.Error -> {
                            JSONObject()
                                .apply {
                                    put("status", "ERROR")
                                    put("code", totpResult.code)
                                }.toString()
                        }
                    }
                } else {
                    // User cancelled or authentication failed
                    JSONObject()
                        .apply {
                            put("status", "ERROR")
                            put("code", BiometricManager.ErrorCode.USER_CANCELLED)
                        }.toString()
                }

            webView?.let { wv ->
                val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                wv.evaluateJavascript(script, null)
            }
        }

    // Load timeout handler
    val loadTimeoutHandler = remember { Handler(Looper.getMainLooper()) }
    var hasTimedOut by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }

    val loadTimeoutSeconds = AstroConstants.Timeouts.LOAD_TIMEOUT_MS / 1000

    DisposableEffect(Unit) {
        val timeoutRunnable =
            Runnable {
                if (isLoading && !hasTimedOut) {
                    hasTimedOut = true
                    val error = AstroError(ErrorCode.TIMEOUT, null, "SDK failed to load within $loadTimeoutSeconds seconds")
                    AstroLogger.logError(error)
                    onResult(AstroResult.Failure(error))
                }
            }
        loadTimeoutHandler.postDelayed(timeoutRunnable, AstroConstants.Timeouts.LOAD_TIMEOUT_MS)

        onDispose {
            loadTimeoutHandler.removeCallbacksAndMessages(null)
            webView?.apply {
                stopLoading()
                destroy()
            }
            AstroLogger.logInfo("Lifecycle: AstroConnect - disposed")
        }
    }

    Scaffold(
        modifier = modifier.imePadding(),
        topBar = {
            if (configuration.effectiveShowHeader) {
                val logoUrl = "${configuration.issuerLogoBaseUrl}/${configuration.appIssuer.lowercase()}_$themeParameter.webp"
                val fallbackUrl = "${configuration.issuerLogoBaseUrl}/astropay_$themeParameter.webp"
                AstroLogger.logDebug("Issuer logo URL: $logoUrl")
                val logoBitmap = rememberIssuerLogoBitmap(logoUrl)
                val fallbackBitmap = rememberIssuerLogoBitmap(fallbackUrl)
                val displayBitmap = if (configuration.showHeaderLogo == true) logoBitmap ?: fallbackBitmap else null

                Column {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .background(resolvedHeaderBGColor)
                                .statusBarsPadding()
                                .padding(horizontal = resolvedHeaderPaddingH.dp, vertical = resolvedHeaderPaddingV.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (displayBitmap != null) {
                            Image(
                                bitmap = displayBitmap,
                                contentDescription = configuration.appIssuer,
                                contentScale = ContentScale.FillHeight,
                                modifier =
                                    Modifier
                                        .padding(start = 4.dp)
                                        .height(20.dp)
                                        .wrapContentWidth()
                                        .clip(RoundedCornerShape(8.dp)),
                            )
                        } else {
                            Spacer(modifier = Modifier.size(20.dp))
                        }

                        IconButton(
                            onClick = {
                                onResult(AstroResult.Closed)
                            },
                            modifier = Modifier.size(42.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = defaultCloseColor(themeParameter),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                    if (resolvedHeaderBorderWidth > 0f) {
                        HorizontalDivider(
                            color = resolvedHeaderBorderColor,
                            thickness = resolvedHeaderBorderWidth.dp,
                        )
                    }
                }
            }
        },
    ) { paddingValues ->
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(resolvedMainBGColor),
        ) {
            AndroidView(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .then(if (configuration.effectiveShowHeader) Modifier.padding(paddingValues) else Modifier),
                factory = { ctx ->
                    val claimed = AstroPreloadSession.claim(configuration, themeParameter)
                    if (claimed != null) {
                        // ---- Preloaded path: wire up the existing WebView ----
                        // Consume pending preload callbacks so the preload caller is always
                        // notified even when the SDK is opened before the preload finishes.
                        val (preloadSuccess, preloadError) = AstroPreloadSession.takePendingCallbacks()
                        claimed.webView.apply {
                            layoutParams =
                                ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )

                            if (!claimed.bridge.isLoaded) {
                                visibility = View.INVISIBLE
                                alpha = 0f
                            }

                            setOnTouchListener { v, _ ->
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                                false
                            }

                            claimed.bridge.apply {
                                onLoaded = {
                                    post {
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        if (hasTimedOut || hasError) {
                                            AstroLogger.logDebug("SDK loaded but error occurred, skipping onLoaded")
                                            return@post
                                        }
                                        preloadSuccess?.invoke()
                                        isLoading = false
                                        visibility = View.VISIBLE
                                        animate().alpha(1f).setDuration(0).start()
                                        AstroLogger.logInfo("Lifecycle: AstroConnect - loaded")
                                        onResult(AstroResult.Success)
                                    }
                                }
                                onClose = {
                                    post {
                                        AstroLogger.logInfo("Lifecycle: AstroConnect - closed")
                                        onResult(AstroResult.Closed)
                                    }
                                }
                                onError = { error ->
                                    post {
                                        if (!hasError) {
                                            hasError = true
                                            loadTimeoutHandler.removeCallbacksAndMessages(null)
                                            preloadError?.invoke(error)
                                            onResult(AstroResult.Failure(error))
                                        }
                                    }
                                }
                                onEvent = { event -> post { onResult(AstroResult.Event(event)) } }
                                onCheckCameraPermission = {
                                    val status = CameraManager.getCameraPermissionStatus(ctx, null)
                                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                                    post { evaluateJavascript(script, null) }
                                }
                                onRequestCameraPermission = {
                                    CameraManager.markPermissionRequested(ctx)
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        val script =
                                            AstroBridgeManager.createCameraPermissionCallback(
                                                CameraManager.PermissionStatus.AUTHORIZED,
                                            )
                                        post { evaluateJavascript(script, null) }
                                    } else {
                                        pendingBridgePermissionRequest = true
                                        cameraPermissionLauncher.launch(CameraManager.CAMERA_PERMISSION)
                                    }
                                }
                                onCheckBiometricAvailability = {
                                    val errorCode = BiometricManager.getBiometricErrorCode(ctx)
                                    val resultJson =
                                        if (errorCode == null) {
                                            JSONObject().apply { put("status", "OK") }.toString()
                                        } else {
                                            JSONObject().apply { put("status", "ERROR"); put("code", errorCode) }.toString()
                                        }
                                    val script = AstroBridgeManager.createCheckBiometricCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onDeleteSeed = {
                                    val success = BiometricManager.deleteSeed(ctx)
                                    val resultJson =
                                        if (success) {
                                            JSONObject().apply { put("status", "OK") }.toString()
                                        } else {
                                            JSONObject().apply { put("status", "ERROR"); put("code", "KEYSTORE_ERROR") }.toString()
                                        }
                                    val script = AstroBridgeManager.createDeleteSeedCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onGetSeed = {
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for getSeed")
                                        BiometricManager.getSeed(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GetSeedResult.Success ->
                                                        JSONObject().apply { put("status", "OK"); put("seed", result.seed) }.toString()
                                                    is BiometricManager.GetSeedResult.Error ->
                                                        JSONObject().apply { put("status", "ERROR"); put("code", result.code) }.toString()
                                                }
                                            val script = AstroBridgeManager.createGetSeedCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available for getSeed")
                                        val errorJson = JSONObject().apply {
                                            put("status", "ERROR"); put("code", BiometricManager.ErrorCode.BIOMETRIC_NOT_AVAILABLE)
                                        }.toString()
                                        val script = AstroBridgeManager.createGetSeedCallback(errorJson)
                                        post { evaluateJavascript(script, null) }
                                    }
                                }
                                onRegisterDevice = { seed ->
                                    val result = BiometricManager.registerDevice(ctx, seed)
                                    val resultJson =
                                        when (result) {
                                            is BiometricManager.RegisterDeviceResult.Success ->
                                                JSONObject().apply {
                                                    put("status", "OK"); put("deviceInfo", result.deviceInfo); put("deviceId", result.deviceId)
                                                }.toString()
                                            is BiometricManager.RegisterDeviceResult.Error ->
                                                JSONObject().apply { put("status", "ERROR"); put("code", result.code) }.toString()
                                        }
                                    val script = AstroBridgeManager.createRegisterDeviceCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                }
                                onGenerateTOTP = totp@{
                                    val fragmentActivity = ctx.findFragmentActivity()
                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for TOTP generation")
                                        BiometricManager.generateTOTP(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success ->
                                                        JSONObject().apply {
                                                            put("status", "OK"); put("code", result.code); put("remainingSeconds", result.remainingSeconds)
                                                        }.toString()
                                                    is BiometricManager.GenerateTOTPResult.Error ->
                                                        JSONObject().apply { put("status", "ERROR"); put("code", result.code) }.toString()
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available, using KeyguardManager fallback for TOTP")
                                        if (BiometricManager.canSkipAuth()) {
                                            val result = BiometricManager.generateTOTPAfterAuth(ctx)
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success ->
                                                        JSONObject().apply {
                                                            put("status", "OK"); put("code", result.code); put("remainingSeconds", result.remainingSeconds)
                                                        }.toString()
                                                    is BiometricManager.GenerateTOTPResult.Error ->
                                                        JSONObject().apply { put("status", "ERROR"); put("code", result.code) }.toString()
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        if (!BiometricManager.prepareTOTPGeneration(ctx)) {
                                            AstroLogger.logDebug("Cannot prepare TOTP generation")
                                            val errorJson = JSONObject().apply {
                                                put("status", "ERROR"); put("code", BiometricManager.ErrorCode.SEED_NOT_FOUND)
                                            }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        val intent = BiometricManager.createKeyguardIntent(
                                            ctx, title = "Verify Identity", description = "Authenticate to generate verification code",
                                        )
                                        if (intent == null) {
                                            AstroLogger.logDebug("Cannot create keyguard intent for TOTP")
                                            val errorJson = JSONObject().apply {
                                                put("status", "ERROR"); put("code", BiometricManager.ErrorCode.DEVICE_NOT_SECURE)
                                            }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@totp
                                        }
                                        pendingTOTPGeneration = true
                                        totpAuthLauncher.launch(intent)
                                    }
                                }
                            }

                            webViewClient =
                                AstroWebViewClient(
                                    configuration = configuration,
                                    themeParameter = themeParameter,
                                    onPageStarted = {},
                                    onPageFinished = {},
                                    onError = { error ->
                                        if (!hasError) {
                                            hasError = true
                                            loadTimeoutHandler.removeCallbacksAndMessages(null)
                                            onResult(AstroResult.Failure(error))
                                        }
                                    },
                                )
                            webChromeClient =
                                AstroWebChromeClient(
                                    onCameraPermissionNeeded = { request ->
                                        if (CameraManager.hasCameraPermission(ctx)) {
                                            request.grant(request.resources)
                                        } else {
                                            pendingPermissionRequest = request
                                            if (!pendingBridgePermissionRequest) {
                                                CameraManager.markPermissionRequested(ctx)
                                                cameraPermissionLauncher.launch(CameraManager.CAMERA_PERMISSION)
                                            }
                                        }
                                    },
                                )

                            if (claimed.bridge.isLoaded) {
                                // Page already loaded — re-inject bridge with current config then fire result.
                                // (The preload WebView injected the bridge at load time; this ensures the
                                // current configuration is in place before the SDK becomes visible.)
                                post {
                                    val script = AstroBridgeManager.createBridgeScript(configuration, themeParameter)
                                    evaluateJavascript(script) {
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        if (!hasTimedOut && !hasError) {
                                            preloadSuccess?.invoke()
                                            isLoading = false
                                            visibility = View.VISIBLE
                                            animate().alpha(1f).setDuration(0).start()
                                            AstroLogger.logInfo("Lifecycle: AstroConnect - loaded (from preload)")
                                            onResult(AstroResult.Success)
                                        }
                                    }
                                }
                            }

                            webView = this
                        }
                    } else {
                        // ---- Normal path: create a fresh WebView ----
                        WebView(ctx).apply {
                            layoutParams =
                                ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )
                            visibility = View.INVISIBLE
                            alpha = 0f

                            // Prevent parent (BottomSheet, etc.) from intercepting touch events
                            // This allows WebView to handle scroll instead of sheet dismiss gesture
                            setOnTouchListener { v, _ ->
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                                false
                            }

                            setupWebView(
                                configuration = configuration,
                                themeParameter = themeParameter,
                                onLoaded = {
                                    loadTimeoutHandler.removeCallbacksAndMessages(null)
                                    if (hasTimedOut || hasError) {
                                        AstroLogger.logDebug("SDK loaded but error occurred, skipping onLoaded")
                                        return@setupWebView
                                    }
                                    isLoading = false
                                    visibility = View.VISIBLE
                                    animate().alpha(1f).setDuration(0).start()
                                    AstroLogger.logInfo("Lifecycle: AstroConnect - loaded")
                                    onResult(AstroResult.Success)
                                },
                                onClose = {
                                    AstroLogger.logInfo("Lifecycle: AstroConnect - closed")
                                    onResult(AstroResult.Closed)
                                },
                                onError = { error ->
                                    if (!hasError) {
                                        hasError = true
                                        loadTimeoutHandler.removeCallbacksAndMessages(null)
                                        onResult(AstroResult.Failure(error))
                                    }
                                },
                                onEvent = { event ->
                                    onResult(AstroResult.Event(event))
                                },
                                onCameraPermissionCheck = {
                                    val status = CameraManager.getCameraPermissionStatus(ctx, null)
                                    val script = AstroBridgeManager.createCameraPermissionCallback(status)
                                    post { evaluateJavascript(script, null) }
                                },
                                onCameraPermissionRequest = {
                                    CameraManager.markPermissionRequested(ctx)
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        val script =
                                            AstroBridgeManager.createCameraPermissionCallback(
                                                CameraManager.PermissionStatus.AUTHORIZED,
                                            )
                                        post { evaluateJavascript(script, null) }
                                    } else {
                                        pendingBridgePermissionRequest = true
                                        cameraPermissionLauncher.launch(CameraManager.CAMERA_PERMISSION)
                                    }
                                },
                                onWebPermissionRequest = { request ->
                                    if (CameraManager.hasCameraPermission(ctx)) {
                                        request.grant(request.resources)
                                    } else {
                                        pendingPermissionRequest = request
                                        if (!pendingBridgePermissionRequest) {
                                            CameraManager.markPermissionRequested(ctx)
                                            cameraPermissionLauncher.launch(CameraManager.CAMERA_PERMISSION)
                                        }
                                    }
                                },
                                onCheckBiometricAvailability = {
                                    val errorCode = BiometricManager.getBiometricErrorCode(ctx)
                                    val resultJson =
                                        if (errorCode == null) {
                                            JSONObject()
                                                .apply {
                                                    put("status", "OK")
                                                }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", errorCode)
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createCheckBiometricCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onDeleteSeed = {
                                    val success = BiometricManager.deleteSeed(ctx)
                                    val resultJson =
                                        if (success) {
                                            JSONObject()
                                                .apply {
                                                    put("status", "OK")
                                                }.toString()
                                        } else {
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", "KEYSTORE_ERROR")
                                                }.toString()
                                        }
                                    val script = AstroBridgeManager.createDeleteSeedCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onGetSeed = {
                                    val fragmentActivity = ctx.findFragmentActivity()

                                    if (fragmentActivity != null) {
                                        AstroLogger.logDebug("Using BiometricPrompt for getSeed")
                                        BiometricManager.getSeed(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GetSeedResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("seed", result.seed)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GetSeedResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGetSeedCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        AstroLogger.logDebug("FragmentActivity not available for getSeed")
                                        val errorJson =
                                            JSONObject()
                                                .apply {
                                                    put("status", "ERROR")
                                                    put("code", BiometricManager.ErrorCode.BIOMETRIC_NOT_AVAILABLE)
                                                }.toString()
                                        val script = AstroBridgeManager.createGetSeedCallback(errorJson)
                                        post { evaluateJavascript(script, null) }
                                    }
                                },
                                onRegisterDevice = { seed ->
                                    // Register device - stores seed encrypted without biometric prompt
                                    // Biometric is only required when generating TOTP
                                    val result = BiometricManager.registerDevice(ctx, seed)
                                    val resultJson =
                                        when (result) {
                                            is BiometricManager.RegisterDeviceResult.Success -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "OK")
                                                        put("deviceInfo", result.deviceInfo)
                                                        put("deviceId", result.deviceId)
                                                    }.toString()
                                            }

                                            is BiometricManager.RegisterDeviceResult.Error -> {
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", result.code)
                                                    }.toString()
                                            }
                                        }
                                    val script = AstroBridgeManager.createRegisterDeviceCallback(resultJson)
                                    post { evaluateJavascript(script, null) }
                                },
                                onGenerateTOTP = {
                                    // Try BiometricPrompt first (requires FragmentActivity)
                                    val fragmentActivity = ctx.findFragmentActivity()

                                    if (fragmentActivity != null) {
                                        // Use BiometricPrompt (preferred method)
                                        AstroLogger.logDebug("Using BiometricPrompt for TOTP generation")
                                        BiometricManager.generateTOTP(fragmentActivity) { result ->
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                        }
                                    } else {
                                        // Fallback to KeyguardManager (works with any Activity)
                                        AstroLogger.logDebug("FragmentActivity not available, using KeyguardManager fallback for TOTP")

                                        // Skip authentication if within grace period
                                        if (BiometricManager.canSkipAuth()) {
                                            val result = BiometricManager.generateTOTPAfterAuth(ctx)
                                            val resultJson =
                                                when (result) {
                                                    is BiometricManager.GenerateTOTPResult.Success -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "OK")
                                                                put("code", result.code)
                                                                put("remainingSeconds", result.remainingSeconds)
                                                            }.toString()
                                                    }

                                                    is BiometricManager.GenerateTOTPResult.Error -> {
                                                        JSONObject()
                                                            .apply {
                                                                put("status", "ERROR")
                                                                put("code", result.code)
                                                            }.toString()
                                                    }
                                                }
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(resultJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Check if we can generate TOTP
                                        if (!BiometricManager.prepareTOTPGeneration(ctx)) {
                                            AstroLogger.logDebug("Cannot prepare TOTP generation")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.SEED_NOT_FOUND)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Create keyguard intent
                                        val intent =
                                            BiometricManager.createKeyguardIntent(
                                                ctx,
                                                title = "Verify Identity",
                                                description = "Authenticate to generate verification code",
                                            )
                                        if (intent == null) {
                                            AstroLogger.logDebug("Cannot create keyguard intent for TOTP")
                                            val errorJson =
                                                JSONObject()
                                                    .apply {
                                                        put("status", "ERROR")
                                                        put("code", BiometricManager.ErrorCode.DEVICE_NOT_SECURE)
                                                    }.toString()
                                            val script = AstroBridgeManager.createGenerateTOTPCallback(errorJson)
                                            post { evaluateJavascript(script, null) }
                                            return@setupWebView
                                        }

                                        // Mark pending and launch authentication
                                        pendingTOTPGeneration = true
                                        totpAuthLauncher.launch(intent)
                                    }
                                },
                            )

                            // Load URL with custom SDK header
                            val url = URLBuilder.buildURL(configuration, themeParameter)
                            if (url != null) {
                                AstroLogger.logInfo("Loading App")
                                val headers =
                                    mapOf(
                                        AstroConstants.Bridge.SDK_HEADER_NAME to AstroConstants.Bridge.SDK_HEADER_VALUE,
                                    )
                                loadUrl(url, headers)
                            } else {
                                val error = AstroError(ErrorCode.INITIALIZATION_ERROR, null, "Failed to build URL from configuration")
                                AstroLogger.logError(error)
                                onResult(AstroResult.Failure(error))
                            }

                            webView = this
                        }
                    }
                },
            )

            // Loading indicator
            AnimatedVisibility(
                visible = isLoading,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center),
            ) {
                if (loadingContent != null) {
                    loadingContent()
                } else {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp,
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun WebView.setupWebView(
    configuration: AstroConfiguration,
    themeParameter: String,
    onLoaded: () -> Unit,
    onClose: () -> Unit,
    onError: (AstroError) -> Unit,
    onEvent: (AstroEvent) -> Unit,
    onCameraPermissionCheck: () -> Unit,
    onCameraPermissionRequest: () -> Unit,
    onWebPermissionRequest: (PermissionRequest) -> Unit,
    onCheckBiometricAvailability: () -> Unit,
    onDeleteSeed: () -> Unit,
    onGetSeed: () -> Unit,
    onRegisterDevice: (String) -> Unit, // seed parameter
    onGenerateTOTP: () -> Unit,
) {
    settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        mediaPlaybackRequiresUserGesture = false
        allowFileAccess = true
        allowContentAccess = true
        loadWithOverviewMode = true
        useWideViewPort = true
        cacheMode = WebSettings.LOAD_DEFAULT
        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        setSupportMultipleWindows(true)
        javaScriptCanOpenWindowsAutomatically = true
    }

    // Add JavaScript interface — registered once; callbacks updated via mutable properties
    val bridge = AstroBridgeInterface().apply {
        this.onLoaded = { post { onLoaded() } }
        this.onClose = { post { onClose() } }
        this.onError = { error -> post { onError(error) } }
        this.onEvent = { event -> post { onEvent(event) } }
        this.onCheckCameraPermission = { onCameraPermissionCheck() }
        this.onRequestCameraPermission = { post { onCameraPermissionRequest() } }
        this.onCheckBiometricAvailability = { post { onCheckBiometricAvailability() } }
        this.onDeleteSeed = { post { onDeleteSeed() } }
        this.onGetSeed = { post { onGetSeed() } }
        this.onRegisterDevice = { seed -> post { onRegisterDevice(seed) } }
        this.onGenerateTOTP = { post { onGenerateTOTP() } }
    }
    addJavascriptInterface(bridge, AstroConstants.Bridge.OBJECT_NAME)

    // Set WebView clients
    webViewClient =
        AstroWebViewClient(
            configuration = configuration,
            themeParameter = themeParameter,
            onPageStarted = { },
            onPageFinished = { },
            onError = { error -> onError(error) },
        )

    webChromeClient =
        AstroWebChromeClient(
            onCameraPermissionNeeded = { request -> onWebPermissionRequest(request) },
        )
}

@Composable
private fun rememberIssuerLogoBitmap(url: String): ImageBitmap? {
    var bitmap by remember(url) { mutableStateOf(IssuerLogoCache.get(url)) }
    LaunchedEffect(url) {
        if (bitmap != null) return@LaunchedEffect
        bitmap =
            withContext(Dispatchers.IO) {
                try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connect()
                    BitmapFactory.decodeStream(connection.inputStream)?.asImageBitmap()?.also {
                        IssuerLogoCache.put(url, it)
                    }
                } catch (_: Exception) {
                    null
                }
            }
    }
    return bitmap
}

/**
 * Extension function to find FragmentActivity from a Context.
 * Unwraps ContextWrapper chain to find the underlying FragmentActivity.
 */
private fun Context.findFragmentActivity(): FragmentActivity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is FragmentActivity) {
            return context
        }
        context = context.baseContext
    }
    return null
}
