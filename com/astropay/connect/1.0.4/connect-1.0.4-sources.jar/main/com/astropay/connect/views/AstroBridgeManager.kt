package com.astropay.connect.views

import com.astropay.connect.core.AstroConfiguration
import com.astropay.connect.core.AstroConstants
import com.astropay.connect.utils.JSONConverter

internal object AstroBridgeManager {
    fun createBridgeScript(
        configuration: AstroConfiguration,
        themeParameter: String,
    ): String {
        val flowParamsJson =
            configuration.flowParams?.let {
                JSONConverter.mapToJsonString(it)
            } ?: "null"
        val flowValue = configuration.flow?.let { "'$it'" } ?: "null"

        return """
            (function() {
                
                var nativeInterface = window.AstroPayBridge;

                var existingCallback = (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function')
                    ? window.AstroPayBridge.cameraPermissionCallback
                    : null;

                // Create the bridge object with properties and wrapper functions
                window.AstroPayBridge = {
                    platform: '${AstroConstants.PLATFORM}',
                    sdkVersion: '${AstroConstants.SDK_VERSION}',
                    internalSdkVersion: '${AstroConstants.INTERNAL_SDK_VERSION}',
                    environment: '${configuration.environment.value}',
                    accessToken: '${configuration.accessToken}',
                    theme: '$themeParameter',
                    language: '${configuration.language}',
                    appIssuer: '${configuration.appIssuer}',
                    flow: $flowValue,
                    flowParams: $flowParamsJson,
                    embedded: ${configuration.embedded},
                    cameraPermissionCallback: existingCallback,

                    notifyLoaded: function() {
                        if (nativeInterface && nativeInterface.notifyLoaded) {
                            nativeInterface.notifyLoaded();
                        }
                    },

                    notifyClose: function() {
                        if (nativeInterface && nativeInterface.notifyClose) {
                            nativeInterface.notifyClose();
                        }
                    },

                    notifyError: function(code, error, severity) {
                        if (nativeInterface && nativeInterface.notifyError) {
                            nativeInterface.notifyError(code || '', error || '', severity || '');
                        }
                    },

                    notifyEvent: function(event) {
                        if (nativeInterface && nativeInterface.notifyEvent) {
                            nativeInterface.notifyEvent(JSON.stringify(event));
                        }
                    },

                    hasCameraPermission: function() {
                        if (nativeInterface && nativeInterface.hasCameraPermission) {
                            // Note: Android @JavascriptInterface cannot return values synchronously to JS.
                            // The native side will call cameraPermissionCallback via evaluateJavascript.
                            nativeInterface.hasCameraPermission();
                        }
                    },

                    requestCameraPermissions: function() {
                        if (nativeInterface && nativeInterface.requestCameraPermissions) {
                            nativeInterface.requestCameraPermissions();
                        }
                    }
                };

                console.log('[AstroPayBridge] Bridge initialized for Android');
            })();
            """.trimIndent()
    }

    /**
     * Creates JavaScript code to send the camera permission result back to the web content.
     *
     * @param status The permission status string.
     * @return The JavaScript code to execute.
     */
    fun createCameraPermissionCallback(status: String): String =
        """
        (function() {
            if (window.AstroPayBridge && typeof window.AstroPayBridge.cameraPermissionCallback === 'function') {
                window.AstroPayBridge.cameraPermissionCallback('$status');
            }
        })();
        """.trimIndent()

    /**
     * Creates JavaScript code to update a bridge property.
     *
     * @param property The property name.
     * @param value The new value (will be JSON-encoded if needed).
     * @return The JavaScript code to execute.
     */
    fun createPropertyUpdate(
        property: String,
        value: Any,
    ): String {
        val jsValue =
            when (value) {
                is String -> {
                    "'$value'"
                }

                is Boolean -> {
                    value.toString()
                }

                is Number -> {
                    value.toString()
                }

                is Map<*, *> -> {
                    @Suppress("UNCHECKED_CAST")
                    JSONConverter.mapToJsonString(value as Map<String, Any>)
                }

                else -> {
                    "'$value'"
                }
            }

        return """
            (function() {
                if (window.AstroPayBridge) {
                    window.AstroPayBridge.$property = $jsValue;
                }
            })();
            """.trimIndent()
    }
}
