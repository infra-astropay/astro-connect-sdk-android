package com.astropay.connect.views

import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import com.astropay.connect.core.AstroLogger

/**
 * Custom WebChromeClient for AstroPay Connect SDK.
 * Handles JavaScript console messages and permission requests.
 */
internal class AstroWebChromeClient(
    private val onCameraPermissionNeeded: (PermissionRequest) -> Unit,
) : WebChromeClient() {
    // override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
    //     consoleMessage?.let { message ->
    //         val logMessage = "[WebView Console] ${message.message()} (${message.sourceId()}:${message.lineNumber()})"

    //         when (message.messageLevel()) {
    //             ConsoleMessage.MessageLevel.ERROR -> AstroLogger.error(logMessage)
    //             ConsoleMessage.MessageLevel.WARNING -> AstroLogger.warning(logMessage)
    //             ConsoleMessage.MessageLevel.LOG -> AstroLogger.info(logMessage)
    //             ConsoleMessage.MessageLevel.DEBUG -> AstroLogger.debug(logMessage)
    //             ConsoleMessage.MessageLevel.TIP -> AstroLogger.verbose(logMessage)
    //             else -> AstroLogger.debug(logMessage)
    //         }
    //     }
    //     return true
    // }

    override fun onPermissionRequest(request: PermissionRequest?) {
        request?.let { permRequest ->
            val resources = permRequest.resources
            AstroLogger.logDebug("Permission requested: ${resources.joinToString()}, origin: ${permRequest.origin}")

            if (resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                onCameraPermissionNeeded(permRequest)
            } else {
                AstroLogger.logDebug("Denying non-camera permission")
                permRequest.deny()
            }
        }
    }

    override fun onProgressChanged(
        view: WebView?,
        newProgress: Int,
    ) {
        super.onProgressChanged(view, newProgress)
    }
}
