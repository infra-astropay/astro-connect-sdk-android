package com.astropay.connect.core

/**
 * Constants used throughout the AstroPay Connect SDK.
 */
internal object AstroConstants {
    const val SDK_VERSION = "1.0.4"
    const val INTERNAL_SDK_VERSION = "1"
    const val PLATFORM = "android"

    object Network {
        object URLs {
            const val PRODUCTION = "https://web-app-connect.astropay.com/"
            const val SANDBOX = "https://web-app-connect-stg.astropay.com/"
            const val TESTING = "https://web-app-connect.testingap.com/"
            const val LOCAL_PORT = "3000"
        }
    }

    /**
     * JavaScript bridge configuration.
     */
    object Bridge {
        const val OBJECT_NAME = "AstroPayBridge"
        const val SDK_HEADER_NAME = "X-Astro-SDK"
        const val SDK_HEADER_VALUE = "AstroPayConnect/Android-$SDK_VERSION"

        object MessageHandlers {
            const val NOTIFY_LOADED = "notifyLoaded"
            const val NOTIFY_CLOSE = "notifyClose"
            const val NOTIFY_ERROR = "notifyError"
            const val NOTIFY_EVENT = "notifyEvent"
            const val HAS_CAMERA_PERMISSION = "hasCameraPermission"
            const val REQUEST_CAMERA_PERMISSIONS = "requestCameraPermissions"
        }

        object Callbacks {
            const val CAMERA_PERMISSION = "window.AstroPayBridge.cameraPermissionCallback"
        }
    }

    /**
     * Timeout values.
     */
    object Timeouts {
        const val LOAD_TIMEOUT_MS = 35000L
    }

    /**
     * Logging configuration.
     */
    object Logging {
        const val TAG = "AstroConnect"
        const val SUBSYSTEM = "com.astropay.connect"
        const val PREFIX = "APC ::"

        object Categories {
            const val BRIDGE = "Bridge"
        }
    }

    /**
     * URL query parameters.
     */
    object QueryParams {
        const val VERSION = "v"
        const val THEME = "theme"
        const val LANGUAGE = "language"
        const val ACCESS_TOKEN = "access_token"
    }
}
