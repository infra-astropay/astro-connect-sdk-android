package com.astropay.connect.views

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import com.astropay.connect.core.AstroLogger

internal class FileChooserHandler(private val context: Context) {
    private var pending: ValueCallback<Array<Uri>>? = null

    fun open(callback: ValueCallback<Array<Uri>>, launch: () -> Unit): Boolean {
        // Keep the active request: its activity result cannot be matched to a replacement.
        if (pending != null) {
            callback.onReceiveValue(null)
            return true
        }
        pending = callback
        try {
            launch()
        } catch (error: ActivityNotFoundException) {
            cancel()
            AstroLogger.logDebug("No activity can handle the file chooser: ${error.message}")
        } catch (error: SecurityException) {
            cancel()
            AstroLogger.logDebug("File chooser permission denied: ${error.message}")
        }
        // Invoking the callback claims the request, including when launch fails.
        return true
    }

    fun complete(uris: Array<Uri>?) {
        val callback = pending ?: return
        pending = null
        // Picker results are untrusted: never expose host-private files to the page.
        // One unsafe URI rejects the whole selection.
        val safeUris = try {
            uris?.takeIf { selected -> selected.isNotEmpty() && selected.all { isSafeUri(it) } }
        } catch (error: RuntimeException) {
            AstroLogger.logDebug("Could not validate file chooser result: ${error.message}")
            null
        } catch (error: PackageManager.NameNotFoundException) {
            AstroLogger.logDebug("Could not validate file chooser result: ${error.message}")
            null
        }
        AstroLogger.logDebug("File chooser result: ${safeUris?.size ?: 0} file(s)")
        callback.onReceiveValue(safeUris)
    }

    private fun isSafeUri(uri: Uri): Boolean {
        if (uri.scheme != "content") return reject(uri, "scheme is not content")
        // Android resolves content://userId@authority against the authority without userId.
        val authority = uri.authority?.substringAfterLast('@')
        if (authority.isNullOrEmpty()) return reject(uri, "no authority")
        // First layer: the host's own providers. They are always visible to the host, so this
        // does not depend on package visibility (API 30+).
        if (authority in hostAuthorities()) return reject(uri, "authority belongs to the host app")
        // Second layer: a provider of another package that shares the host's uid. A provider the
        // host cannot see does not resolve; it is not the host's, so it is accepted.
        val provider = context.packageManager.resolveContentProvider(authority, 0) ?: return true
        val isHostOwned =
            provider.packageName == context.packageName ||
                provider.applicationInfo?.uid == context.applicationInfo.uid
        return if (isHostOwned) reject(uri, "provider is owned by the host app") else true
    }

    private fun hostAuthorities(): Set<String> {
        val providers =
            context.packageManager
                .getPackageInfo(context.packageName, PackageManager.GET_PROVIDERS)
                ?.providers
                ?: return emptySet()
        // One provider can declare several authorities, separated by ';'.
        return providers
            .flatMap { provider -> provider.authority?.split(';').orEmpty() }
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    // Never log the path: it can carry a document id or a file name.
    private fun reject(uri: Uri, reason: String): Boolean {
        AstroLogger.logDebug(
            "File chooser URI rejected ($reason): scheme=${uri.scheme}, authority=${uri.authority}",
        )
        return false
    }

    fun cancel() = complete(null)

    companion object {
        private const val ANY_MIME_TYPE = "*/*"

        /**
         * Maps a picker activity result to the selected URIs, or `null` when nothing was chosen.
         *
         * `WebChromeClient.FileChooserParams.parseResult` only reads `Intent.getData()`; a
         * multiple selection arrives in `Intent.getClipData()` with a null data URI.
         */
        fun parseResult(resultCode: Int, data: Intent?): Array<Uri>? {
            if (resultCode != Activity.RESULT_OK || data == null) return null
            val clipUris =
                data.clipData?.let { clip ->
                    (0 until clip.itemCount).mapNotNull { index -> clip.getItemAt(index)?.uri }
                }.orEmpty()
            val uris = clipUris.ifEmpty { listOfNotNull(data.data) }.distinct()
            return uris.takeIf { it.isNotEmpty() }?.toTypedArray()
        }

        /**
         * Returns the WebView's own chooser intent, completed with what older WebView versions
         * leave out: they set only the first accept type and no `EXTRA_MIME_TYPES`, so a picker
         * would offer just that one type. Values the WebView already set are kept.
         */
        fun buildIntent(params: WebChromeClient.FileChooserParams): Intent {
            val intent = params.createIntent()
            val mimeTypes = acceptedMimeTypes(params.acceptTypes)
            if (mimeTypes.isNotEmpty() && !intent.hasExtra(Intent.EXTRA_MIME_TYPES)) {
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
            }
            // An extension such as ".pdf" is not a MIME type and matches no picker.
            if (intent.type?.contains('/') != true) {
                intent.setDataAndType(intent.data, ANY_MIME_TYPE)
            }
            if (params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE &&
                !intent.hasExtra(Intent.EXTRA_ALLOW_MULTIPLE)
            ) {
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            return intent
        }

        /**
         * Turns the `accept` values of a file input into MIME types: trimmed, non-empty and
         * de-duplicated, with extensions (".pdf") mapped through [MimeTypeMap]. Unknown
         * extensions are dropped.
         */
        fun acceptedMimeTypes(acceptTypes: Array<String>?): List<String> =
            acceptTypes
                .orEmpty()
                .flatMap { it.split(',') }
                .map { it.trim().lowercase() }
                .filter { it.isNotEmpty() }
                .mapNotNull { type ->
                    if (type.contains('/')) {
                        type
                    } else {
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension(type.removePrefix("."))
                    }
                }.distinct()
    }
}
