package com.astropay.connect.utils

import java.util.Locale

/**
 * Why the SDK itself (not the KYC engine) decided a terminal native KYC result.
 *
 * Wire values are a cross-platform contract shared verbatim with iOS. Android declares only the
 * reasons it can produce.
 */
internal enum class NativeKycSdkReason(val value: String) {
    UNSUPPORTED_PROVIDER("UNSUPPORTED_PROVIDER"),
    REENTRANT("REENTRANT"),

    // Also covers a request body that could not be parsed: the bridge collapses a parse failure
    // into empty fields, so it reaches the empty-token guard (iOS reports MALFORMED_BODY there).
    MISSING_TOKEN("MISSING_TOKEN"),
    MISSING_USER_ID("MISSING_USER_ID"),
    API_LEVEL("API_LEVEL"),
    HANDLER_EXCEPTION("HANDLER_EXCEPTION"),
    CORE_VARIANT("CORE_VARIANT"),
    WATCHDOG("WATCHDOG"),
    LIFECYCLE_BACKOUT("LIFECYCLE_BACKOUT"),
}

internal enum class NativeKycOrigin(val value: String) {
    CAF("CAF"),
    SDK("SDK"),
}

internal enum class NativeKycCafEvent(val value: String) {
    SUCCESS("SUCCESS"),
    FAILURE("FAILURE"),
    ERROR("ERROR"),
    CANCELLED("CANCELLED"),
}

internal enum class NativeKycTraceEvent(val value: String) {
    LOADING("LOADING"),
    LOADED("LOADED"),
    LOG("LOG"),
    SUCCESS("SUCCESS"),
    FAILURE("FAILURE"),
    ERROR("ERROR"),
    CANCELLED("CANCELLED"),
    UNKNOWN("UNKNOWN"),
}

/**
 * One engine callback of a native KYC session.
 *
 * @param ms Milliseconds since the session started (monotonic clock).
 * @param event The callback kind wire value (see [NativeKycTraceEvent]).
 * @param level Log level, only for `LOG` entries.
 * @param message Short, already sanitised text; null when there is nothing to report.
 */
internal data class NativeKycTraceEntry(
    val ms: Long,
    val event: String,
    val level: String? = null,
    val message: String? = null,
) {
    fun toMap(): Map<String, Any> =
        buildMap {
            put("ms", ms)
            put("event", event)
            level?.let { put("level", it) }
            message?.let { put("message", it) }
        }
}

/**
 * Reports the engine callbacks of one native KYC session as they happen. Nothing is kept: each
 * entry is handed to [onRecord] and forgotten. CAF-free and Android-free, so it compiles in both
 * flavors and runs in plain unit tests.
 *
 * @param secrets Exact values handed to the engine (the CAF token and the user id). Every
 *   occurrence is replaced before any free text is reported.
 * @param now Monotonic clock in milliseconds; injectable for tests.
 * @param onRecord Called with each entry as it is recorded, so it can be forwarded while the
 *   engine is still on screen.
 */
internal class NativeKycTrace(
    val secrets: List<String>,
    private val now: () -> Long = { System.nanoTime() / NANOS_PER_MILLI },
    private val onRecord: (NativeKycTraceEntry) -> Unit = {},
) {
    private val startedAt = now()

    /**
     * Reports one entry.
     *
     * @param message Free text; sanitised and capped at [MAX_MESSAGE_LENGTH] here.
     */
    fun record(
        event: NativeKycTraceEvent,
        level: String? = null,
        message: String? = null,
    ) {
        val entry =
            NativeKycTraceEntry(
                ms = (now() - startedAt).coerceAtLeast(0),
                event = event.value,
                level = level?.let { NativeKycDiagnostics.normalizeCafType(it) },
                message = message?.let { NativeKycDiagnostics.sanitize(it, secrets, MAX_MESSAGE_LENGTH) },
            )
        onRecord(entry)
    }

    companion object {
        const val MAX_MESSAGE_LENGTH = 120
        private const val NANOS_PER_MILLI = 1_000_000L
    }
}

/**
 * Optional diagnostics attached to the terminal native KYC result. Never carries a token, a signed
 * response or the user id: free text goes through [sanitize] and the CAF types through
 * [normalizeCafType] before they are stored here.
 *
 * Build it only through [sdk] and [caf].
 */
internal data class NativeKycDiagnostics(
    val origin: NativeKycOrigin,
    val attemptId: String? = null,
    val sdkReason: NativeKycSdkReason? = null,
    val cafEvent: NativeKycCafEvent? = null,
    val cafType: String? = null,
    val cafDescription: String? = null,
) {
    /** Returns a copy carrying [attemptId] when it is valid, or no attempt id otherwise. */
    fun withAttemptId(attemptId: String?): NativeKycDiagnostics = copy(attemptId = validAttemptId(attemptId))

    /** The wire shape. Absent fields are omitted, never sent as null or empty. */
    fun toMap(): Map<String, Any> =
        buildMap {
            attemptId?.let { put("attemptId", it) }
            put("origin", origin.value)
            sdkReason?.let { put("sdkReason", it.value) }
            cafEvent?.let { put("cafEvent", it.value) }
            cafType?.let { put("cafType", it) }
            cafDescription?.let { put("cafDescription", it) }
        }

    companion object {
        const val MAX_TYPE_LENGTH = 64
        const val MAX_DESCRIPTION_LENGTH = 200
        const val REDACTED = "[REDACTED]"
        private const val UNKNOWN_TYPE = "UNKNOWN"
        private const val LINE_SEPARATOR = '\u2028'
        private const val PARAGRAPH_SEPARATOR = '\u2029'

        private val ATTEMPT_ID_PATTERN = Regex("^[A-Za-z0-9-]{1,64}$")
        private val JWT_PATTERN = Regex("eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]*")
        private val CAMEL_BOUNDARY_PATTERN = Regex("(?<=[a-z0-9])(?=[A-Z])")
        private val NON_TYPE_CHARACTER_PATTERN = Regex("[^A-Z0-9_]")

        /** Diagnostics for a result the SDK synthesised (validation failure, watchdog, back-out...). */
        fun sdk(
            reason: NativeKycSdkReason,
            attemptId: String? = null,
        ): NativeKycDiagnostics =
            NativeKycDiagnostics(
                origin = NativeKycOrigin.SDK,
                attemptId = validAttemptId(attemptId),
                sdkReason = reason,
            )

        /**
         * Diagnostics for a result decided by a CAF terminal callback.
         *
         * [type] and [description] are kept only for `FAILURE` / `ERROR`. The description is
         * sanitised with [secrets] (the CAF token and the user id).
         */
        fun caf(
            event: NativeKycCafEvent,
            type: String? = null,
            description: String? = null,
            secrets: List<String>,
        ): NativeKycDiagnostics {
            val hasDetail = event == NativeKycCafEvent.FAILURE || event == NativeKycCafEvent.ERROR
            return NativeKycDiagnostics(
                origin = NativeKycOrigin.CAF,
                cafEvent = event,
                cafType = if (hasDetail) normalizeCafType(type.orEmpty()) else null,
                cafDescription =
                    if (hasDetail) {
                        description?.let { sanitize(it, secrets, MAX_DESCRIPTION_LENGTH) }
                    } else {
                        null
                    },
            )
        }

        /** Returns [raw] when it is a well-formed attempt id, null otherwise. */
        fun validAttemptId(raw: String?): String? = raw?.takeIf { ATTEMPT_ID_PATTERN.matches(it) }

        /**
         * Normalises a CAF type name to `UPPER_SNAKE`, so iOS (`tooDark`) and Android (`TOO_DARK`)
         * emit the same string. Blank input yields `UNKNOWN`; the result is capped at
         * [MAX_TYPE_LENGTH].
         */
        fun normalizeCafType(raw: String): String {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) return UNKNOWN_TYPE
            val split =
                if (trimmed.any { it in 'a'..'z' }) {
                    trimmed.replace(CAMEL_BOUNDARY_PATTERN, "_")
                } else {
                    trimmed
                }
            return split
                .uppercase(Locale.ROOT)
                .replace(NON_TYPE_CHARACTER_PATTERN, "_")
                .take(MAX_TYPE_LENGTH)
        }

        /**
         * Makes free text safe to leave the device: replaces every [secrets] occurrence and every
         * JWT-shaped substring with [REDACTED], turns control characters (and U+2028 / U+2029,
         * which old WebViews reject inside a JS string literal) into spaces, and truncates to [max].
         *
         * @return The sanitised text, or null when nothing is left.
         */
        fun sanitize(
            text: String,
            secrets: List<String>,
            max: Int,
        ): String? {
            var result = text
            // Longest first: when one secret contains another, replacing the short one first
            // would leave fragments of the long one behind.
            secrets
                .filter { it.isNotEmpty() }
                .sortedByDescending { it.length }
                .forEach { secret -> result = result.replace(secret, REDACTED) }
            result = JWT_PATTERN.replace(result, REDACTED)
            result =
                buildString(result.length) {
                    result.forEach { character ->
                        append(if (isUnsafeCharacter(character)) ' ' else character)
                    }
                }
            if (max <= 0) return null
            if (result.length > max) {
                result = result.substring(0, max)
                // Never leave half of a surrogate pair at the cut.
                if (result.last().isHighSurrogate()) {
                    result = result.dropLast(1)
                }
            }
            return result.ifEmpty { null }
        }

        // C0 and C1 control characters, DEL, and the two Unicode line terminators.
        private fun isUnsafeCharacter(character: Char): Boolean =
            Character.isISOControl(character) || character == LINE_SEPARATOR || character == PARAGRAPH_SEPARATOR
    }
}
