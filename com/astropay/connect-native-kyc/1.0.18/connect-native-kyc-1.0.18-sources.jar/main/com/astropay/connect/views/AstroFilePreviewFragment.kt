package com.astropay.connect.views

import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.DialogFragment
import com.astropay.connect.core.AstroFilePreviewStyle
import com.astropay.connect.core.AstroFilePreviewTexts
import com.astropay.connect.core.AstroFileSharer
import com.astropay.connect.core.AstroLogger
import com.astropay.connect.core.AstroShareFileError
import com.astropay.connect.core.AstroShareFileResult
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Full-screen SDK-owned PDF preview with a share action, shown when the web layer calls
 * `shareFile` with `mode: 'preview'`.
 *
 * Mirrors the host app's receipt preview: a header with close button and title, the document pages
 * rendered with [PdfRenderer] inside a pinch-zoomable container, and a primary "Share" button that
 * opens the system chooser without leaving the preview. Delivers a result exactly once through the
 * callback registered via [newInstance]: [AstroShareFileResult.Shared] if the chooser was opened at
 * least once, [AstroShareFileResult.Cancelled] otherwise, or an error when the document cannot be
 * rendered.
 *
 * Not part of the public SDK surface — never exposed to host app partners.
 */
internal class AstroFilePreviewFragment : DialogFragment() {

    private val delivered = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var hasShared = false
    private var isViewAlive = false
    private var previewStyle: AstroFilePreviewStyle? = null

    /** The payload this instance is showing; lets [onDestroy] release only its own. */
    private var shownPayload: Payload? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, android.R.style.Theme_Material_Light_NoActionBar)
        // A rotation recreates the fragment: what the user already did must survive it.
        hasShared = savedInstanceState?.getBoolean(STATE_HAS_SHARED) ?: false
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_HAS_SHARED, hasShared)
    }

    override fun onDestroy() {
        // Destroyed for good without a result (the host closed the SDK): release the payload, which
        // holds the file and a callback into the screen. A rotation keeps it for the new instance.
        if (activity?.isChangingConfigurations != true && pending === shownPayload) {
            pending = null
        }
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        val window = dialog?.window ?: return
        window.setLayout(MATCH_PARENT, MATCH_PARENT)
        // Draw behind the status and navigation bars and pad the content by their insets ourselves
        // (see onCreateView). Targeting Android 15 the window is edge-to-edge anyway; doing it
        // explicitly gives the same layout on every API level.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val style = previewStyle ?: return
        window.setBackgroundDrawable(ColorDrawable(style.background))
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        val isLightBackground = ColorUtils.calculateLuminance(style.background) > LIGHT_BACKGROUND_LUMINANCE
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = isLightBackground
            isAppearanceLightNavigationBars = isLightBackground
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        // A fragment recreated by the system has lost its in-memory payload: close instead of
        // rendering an empty screen.
        val payload = pending
        if (payload == null) {
            mainHandler.post { dismissAllowingStateLoss() }
            return root
        }

        shownPayload = payload
        val style = payload.style
        previewStyle = style
        // The header and the bottom bar take the background color up to the screen edges; the
        // document sits between them on the canvas.
        root.setBackgroundColor(style.background)

        // Keep the header below the status bar / cutout and the button above the navigation bar.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        root.addView(buildHeader(payload), LinearLayout.LayoutParams(MATCH_PARENT, dp(HEADER_HEIGHT_DP)))
        root.addView(buildSeparator(style), LinearLayout.LayoutParams(MATCH_PARENT, SEPARATOR_HEIGHT_PX))

        val pageMargin = dp(PAGE_MARGIN_DP)
        val pagesContainer =
            LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pageMargin, pageMargin, pageMargin, 0)
                // The pages cast a shadow, which must not be cut at the container's edges.
                clipToPadding = false
                clipChildren = false
            }
        val zoomableContainer =
            AstroZoomableContainer(ctx).apply {
                clipChildren = false
                addView(pagesContainer)
            }
        val loading =
            ProgressBar(ctx).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(style.content)
            }
        val document =
            FrameLayout(ctx).apply {
                setBackgroundColor(style.canvas)
                addView(zoomableContainer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
                addView(loading, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
            }
        root.addView(document, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        root.addView(buildSeparator(style), LinearLayout.LayoutParams(MATCH_PARENT, SEPARATOR_HEIGHT_PX))
        root.addView(
            buildShareButton(payload),
            // As wide as its content, centered; it only grows up to the side margins.
            LinearLayout.LayoutParams(WRAP_CONTENT, dp(BUTTON_HEIGHT_DP)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(dp(16), dp(10), dp(16), dp(10))
            },
        )

        ViewCompat.requestApplyInsets(root)

        isViewAlive = true
        val pageWidth = (resources.displayMetrics.widthPixels - pageMargin * 2).coerceAtLeast(1)
        renderPages(payload, pagesContainer, loading, pageWidth)
        return root
    }

    private fun buildHeader(payload: Payload): View {
        val ctx = requireContext()
        val content = payload.style.content
        val header = FrameLayout(ctx)

        val closeButton =
            ImageView(ctx).apply {
                setImageDrawable(CloseIconDrawable(content, dpF(ICON_STROKE_DP), dp(CLOSE_ICON_DP)))
                scaleType = ImageView.ScaleType.CENTER
                background = rippleOn(content, ShapeDrawable(OvalShape()), null)
                contentDescription = payload.texts.closeButton
                isClickable = true
                isFocusable = true
                setOnClickListener { finish() }
            }
        header.addView(
            closeButton,
            FrameLayout.LayoutParams(dp(CLOSE_BUTTON_DP), dp(CLOSE_BUTTON_DP), Gravity.START or Gravity.CENTER_VERTICAL).apply {
                marginStart = dp(4)
            },
        )

        val title =
            TextView(ctx).apply {
                text = payload.texts.title
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(content)
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                ViewCompat.setAccessibilityHeading(this, true)
            }
        // The title is centered on the screen, so it keeps the same free space on both sides.
        header.addView(
            title,
            FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER).apply {
                marginStart = dp(CLOSE_BUTTON_DP + 12)
                marginEnd = dp(CLOSE_BUTTON_DP + 12)
            },
        )
        return header
    }

    private fun buildSeparator(style: AstroFilePreviewStyle): View =
        View(requireContext()).apply { setBackgroundColor(style.separator) }

    /** The share action: an icon and a label on the web's primary button colors, with a ripple. */
    private fun buildShareButton(payload: Payload): View {
        val ctx = requireContext()
        val style = payload.style
        val shape =
            GradientDrawable().apply {
                cornerRadius = dp(BUTTON_RADIUS_DP).toFloat()
                setColor(style.buttonBackground)
            }
        val icon =
            ImageView(ctx).apply {
                setImageDrawable(ShareIconDrawable(style.buttonText, dpF(ICON_STROKE_DP)))
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
        val label =
            TextView(ctx).apply {
                text = payload.texts.shareButton
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(style.buttonText)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            minimumWidth = dp(BUTTON_MIN_WIDTH_DP)
            setPadding(dp(BUTTON_SIDE_PADDING_DP), 0, dp(BUTTON_SIDE_PADDING_DP), 0)
            background = rippleOn(style.buttonText, shape, shape)
            isClickable = true
            isFocusable = true
            // Announced as a button with the label as its name.
            contentDescription = payload.texts.shareButton
            ViewCompat.setAccessibilityDelegate(
                this,
                object : androidx.core.view.AccessibilityDelegateCompat() {
                    override fun onInitializeAccessibilityNodeInfo(
                        host: View,
                        info: androidx.core.view.accessibility.AccessibilityNodeInfoCompat,
                    ) {
                        super.onInitializeAccessibilityNodeInfo(host, info)
                        info.className = Button::class.java.name
                    }
                },
            )
            addView(icon, LinearLayout.LayoutParams(dp(SHARE_ICON_DP), dp(SHARE_ICON_DP)).apply { marginEnd = dp(6) })
            addView(label, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            setOnClickListener { share(payload) }
        }
    }

    /** A ripple in a translucent [color] over [content], bounded by [mask]. */
    private fun rippleOn(@ColorInt color: Int, mask: Drawable?, content: Drawable?): Drawable =
        RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, RIPPLE_ALPHA)), content, mask)

    /** Renders the pages off the main thread and appends them once the view is still alive. */
    private fun renderPages(payload: Payload, container: LinearLayout, loading: View, pageWidth: Int) {
        Thread {
            val bitmaps =
                try {
                    renderPdf(payload.file, pageWidth)
                } catch (e: Exception) {
                    AstroLogger.logDebug("File preview: could not render PDF — ${e.message}")
                    emptyList()
                }
            mainHandler.post {
                if (!isViewAlive) {
                    bitmaps.forEach { it.recycle() }
                    return@post
                }
                loading.visibility = View.GONE
                if (bitmaps.isEmpty()) {
                    // A file that cannot be previewed falls back to the chooser, as on iOS, so the
                    // user can still open it elsewhere.
                    val hostActivity = activity
                    val shared =
                        hostActivity != null &&
                            AstroFileSharer.startChooser(hostActivity, payload.file, payload.mimeType)
                    deliverResult(
                        if (shared) {
                            AstroShareFileResult.Shared
                        } else {
                            AstroShareFileResult.Error(AstroShareFileError.UNKNOWN)
                        },
                    )
                    return@post
                }
                bitmaps.forEach { bitmap ->
                    // Each page is a sheet of paper: white, slightly rounded, with a soft shadow.
                    val pageView =
                        ImageView(container.context).apply {
                            setImageBitmap(bitmap)
                            adjustViewBounds = true
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setBackgroundColor(Color.WHITE)
                            elevation = dp(3).toFloat()
                            clipToOutline = true
                            outlineProvider =
                                object : ViewOutlineProvider() {
                                    override fun getOutline(view: View, outline: Outline) {
                                        outline.setRoundRect(0, 0, view.width, view.height, dp(PAGE_RADIUS_DP).toFloat())
                                    }
                                }
                        }
                    container.addView(
                        pageView,
                        LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(PAGE_MARGIN_DP) },
                    )
                }
            }
        }.start()
    }

    /**
     * Renders each page into a bitmap sized from the screen content width (not the PDF's native
     * size), which keeps memory bounded. Short documents — receipts — render at a higher resolution
     * so they stay sharp when zoomed in.
     */
    private fun renderPdf(file: File, pageWidth: Int): List<Bitmap> =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                val renderScale = if (renderer.pageCount <= HIGH_RESOLUTION_MAX_PAGES) HIGH_RESOLUTION_SCALE else 1f
                val bitmapWidth = (pageWidth * renderScale).toInt()
                (0 until minOf(renderer.pageCount, MAX_PAGES)).mapNotNull { index ->
                    renderer.openPage(index).use { page ->
                        if (page.width <= 0 || page.height <= 0) {
                            null
                        } else {
                            val bitmapHeight = (bitmapWidth.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                            Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888).also { bitmap ->
                                bitmap.eraseColor(Color.WHITE)
                                // A null transform scales the page to fill the bitmap.
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            }
                        }
                    }
                }
            }
        }

    private fun share(payload: Payload) {
        val hostActivity = activity ?: return
        if (AstroFileSharer.startChooser(hostActivity, payload.file, payload.mimeType)) {
            hasShared = true
        }
    }

    private fun finish() {
        deliverResult(if (hasShared) AstroShareFileResult.Shared else AstroShareFileResult.Cancelled)
    }

    override fun onCancel(dialog: DialogInterface) {
        finish()
        super.onCancel(dialog)
    }

    override fun onDestroyView() {
        isViewAlive = false
        super.onDestroyView()
    }

    private fun deliverResult(result: AstroShareFileResult) {
        if (!delivered.compareAndSet(false, true)) return
        val callback = pending?.onResult
        pending = null
        callback?.invoke(result)
        dismissAllowingStateLoss()
    }

    private fun dpF(value: Float): Float = value * resources.displayMetrics.density

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private class Payload(
        val file: File,
        val mimeType: String,
        val texts: AstroFilePreviewTexts,
        val style: AstroFilePreviewStyle,
        val onResult: (AstroShareFileResult) -> Unit,
    )

    companion object {
        const val TAG = "AstroFilePreviewFragment"
        private const val STATE_HAS_SHARED = "astro_file_preview_has_shared"

        private const val HEADER_HEIGHT_DP = 48
        private const val CLOSE_BUTTON_DP = 40
        private const val CLOSE_ICON_DP = 14
        private const val BUTTON_HEIGHT_DP = 40
        private const val SHARE_ICON_DP = 16
        private const val BUTTON_MIN_WIDTH_DP = 150
        private const val BUTTON_SIDE_PADDING_DP = 24
        private const val ICON_STROKE_DP = 1.5f

        /** Same radius as the web's buttons, so the share button matches the one the user just tapped. */
        private const val BUTTON_RADIUS_DP = 8
        private const val PAGE_MARGIN_DP = 16
        private const val PAGE_RADIUS_DP = 4
        private const val SEPARATOR_HEIGHT_PX = 1
        private const val RIPPLE_ALPHA = 0x33

        /** Receipts are one or two pages; the cap only guards against unexpectedly long documents. */
        private const val MAX_PAGES = 20

        /** Documents up to this many pages render at [HIGH_RESOLUTION_SCALE] for sharp zooming. */
        private const val HIGH_RESOLUTION_MAX_PAGES = 3
        private const val HIGH_RESOLUTION_SCALE = 2f

        /** Above this luminance the background counts as light and system bar icons turn dark. */
        private const val LIGHT_BACKGROUND_LUMINANCE = 0.5

        private var pending: Payload? = null

        /**
         * Creates a new [AstroFilePreviewFragment] for [file] and registers [onResult] as the
         * one-shot delivery callback. Show it via `fragmentManager.show(fragment, TAG)`.
         */
        fun newInstance(
            file: File,
            mimeType: String,
            texts: AstroFilePreviewTexts,
            style: AstroFilePreviewStyle,
            onResult: (AstroShareFileResult) -> Unit,
        ): AstroFilePreviewFragment {
            pending = Payload(file, mimeType, texts, style, onResult)
            return AstroFilePreviewFragment()
        }
    }
}

/** A two-stroke "close" cross, drawn so the screen needs no icon resource. */
private class CloseIconDrawable(@ColorInt color: Int, strokeWidth: Float, private val size: Int) : Drawable() {
    private val paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.strokeWidth = strokeWidth
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
    override fun getIntrinsicWidth(): Int = size

    override fun getIntrinsicHeight(): Int = size

    override fun draw(canvas: Canvas) {
        val inset = paint.strokeWidth / 2
        val left = bounds.left + inset
        val top = bounds.top + inset
        val right = bounds.right - inset
        val bottom = bounds.bottom - inset
        canvas.drawLine(left, top, right, bottom, paint)
        canvas.drawLine(right, top, left, bottom, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** The Android "share" glyph: three dots joined by two lines. */
private class ShareIconDrawable(@ColorInt color: Int, strokeWidth: Float) : Drawable() {
    private val line =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.strokeWidth = strokeWidth
            style = Paint.Style.STROKE
        }
    private val dot =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.FILL
        }

    override fun draw(canvas: Canvas) {
        val width = bounds.width().toFloat()
        val height = bounds.height().toFloat()
        val radius = width * 0.14f
        val leftX = bounds.left + width * 0.22f
        val rightX = bounds.left + width * 0.78f
        val middleY = bounds.top + height * 0.5f
        val topY = bounds.top + height * 0.2f
        val bottomY = bounds.top + height * 0.8f
        canvas.drawLine(leftX, middleY, rightX, topY, line)
        canvas.drawLine(leftX, middleY, rightX, bottomY, line)
        canvas.drawCircle(leftX, middleY, radius, dot)
        canvas.drawCircle(rightX, topY, radius, dot)
        canvas.drawCircle(rightX, bottomY, radius, dot)
    }

    override fun setAlpha(alpha: Int) {
        line.alpha = alpha
        dot.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        line.colorFilter = colorFilter
        dot.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
