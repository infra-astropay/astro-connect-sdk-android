package com.astropay.connect.views

import android.annotation.SuppressLint
import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.OverScroller
import kotlin.math.min

/**
 * Container that lets its single child be scrolled, flung and pinch-zoomed.
 *
 * The child is measured at the container's width with an unbounded height (like a vertical
 * `ScrollView`) and transformed with scale/translation from its top-left corner. Pinch zooms
 * around the fingers' focus point, double tap toggles between fit and [DOUBLE_TAP_SCALE], and the
 * offsets are clamped so the content never leaves the viewport.
 *
 * Not part of the public SDK surface — never exposed to host app partners.
 */
internal class AstroZoomableContainer(context: Context) : FrameLayout(context) {

    private var scale = MIN_SCALE
    private var offsetX = 0f
    private var offsetY = 0f
    private val scroller = OverScroller(context)

    private val content: View?
        get() = if (childCount > 0) getChildAt(0) else null

    private val scaleDetector =
        ScaleGestureDetector(
            context,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    zoomTo(scale * detector.scaleFactor, detector.focusX, detector.focusY)
                    return true
                }
            },
        )

    private val gestureDetector =
        GestureDetector(
            context,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent): Boolean {
                    scroller.forceFinished(true)
                    return true
                }

                override fun onScroll(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    distanceX: Float,
                    distanceY: Float,
                ): Boolean {
                    offsetX -= distanceX
                    offsetY -= distanceY
                    clampAndApply()
                    return true
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float,
                ): Boolean {
                    val child = content ?: return false
                    scroller.fling(
                        offsetX.toInt(),
                        offsetY.toInt(),
                        velocityX.toInt(),
                        velocityY.toInt(),
                        minOffsetX(child).toInt(),
                        0,
                        minOffsetY(child).toInt(),
                        0,
                    )
                    postInvalidateOnAnimation()
                    return true
                }

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    zoomTo(if (scale > MIN_SCALE) MIN_SCALE else DOUBLE_TAP_SCALE, e.x, e.y)
                    return true
                }
            },
        )

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        content?.measure(
            MeasureSpec.makeMeasureSpec(measuredWidth, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
        )
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val child = content ?: return
        child.layout(0, 0, child.measuredWidth, child.measuredHeight)
        clampAndApply()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) {
            gestureDetector.onTouchEvent(event)
        }
        return true
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            offsetX = scroller.currX.toFloat()
            offsetY = scroller.currY.toFloat()
            clampAndApply()
            postInvalidateOnAnimation()
        }
    }

    /** Zooms to [target] keeping the content point under ([focusX], [focusY]) fixed on screen. */
    private fun zoomTo(target: Float, focusX: Float, focusY: Float) {
        val newScale = target.coerceIn(MIN_SCALE, MAX_SCALE)
        val factor = newScale / scale
        offsetX = focusX - factor * (focusX - offsetX)
        offsetY = focusY - factor * (focusY - offsetY)
        scale = newScale
        clampAndApply()
    }

    private fun minOffsetX(child: View): Float = min(0f, width - child.width * scale)

    private fun minOffsetY(child: View): Float = min(0f, height - child.height * scale)

    private fun clampAndApply() {
        val child = content ?: return
        offsetX = offsetX.coerceIn(minOffsetX(child), 0f)
        offsetY = offsetY.coerceIn(minOffsetY(child), 0f)
        child.pivotX = 0f
        child.pivotY = 0f
        child.scaleX = scale
        child.scaleY = scale
        child.translationX = offsetX
        child.translationY = offsetY
    }

    private companion object {
        const val MIN_SCALE = 1f
        const val MAX_SCALE = 5f
        const val DOUBLE_TAP_SCALE = 2.5f
    }
}
