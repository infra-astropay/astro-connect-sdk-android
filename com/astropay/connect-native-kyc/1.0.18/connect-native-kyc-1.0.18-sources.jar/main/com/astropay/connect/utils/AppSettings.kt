package com.astropay.connect.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.astropay.connect.core.AstroLogger

/**
 * Opens the host app's own page in the system settings, where the user can grant a permission
 * the system no longer prompts for.
 */
internal object AppSettings {

    /** The intent for the host app's settings page. Exposed for tests. */
    fun intent(context: Context): Intent =
        Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Returns whether the settings page could be opened. */
    fun open(context: Context): Boolean =
        try {
            context.startActivity(intent(context))
            true
        } catch (e: ActivityNotFoundException) {
            AstroLogger.logDebug("App settings could not be opened: ${e.message}")
            false
        }
}
