package com.astropay.connect.core

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import androidx.annotation.ColorInt
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.astropay.connect.views.AstroFilePreviewFragment
import java.io.File
import java.io.IOException
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** How the SDK hands a shared file to the user. Unknown wire values fall back to [SHARE]. */
internal enum class AstroShareFileMode {
    /** Opens the system share sheet directly. */
    SHARE,

    /** Shows the SDK's own preview screen, which can also open the share sheet. */
    PREVIEW,
    ;

    companion object {
        fun fromWire(value: String): AstroShareFileMode =
            if (value.equals("preview", ignoreCase = true)) PREVIEW else SHARE
    }
}

/** Localized strings for the preview screen, sent by the web layer. */
internal data class AstroFilePreviewTexts(
    val title: String = "",
    val shareButton: String = DEFAULT_SHARE_BUTTON,
    /** Accessibility label of the close button. */
    val closeButton: String = DEFAULT_CLOSE_BUTTON,
) {
    companion object {
        // The web sends these already localized; the English defaults only cover a web that sends none.
        const val DEFAULT_SHARE_BUTTON = "Share"
        const val DEFAULT_CLOSE_BUTTON = "Close"
    }
}

/**
 * Internal request to share a remote file, sent by the web layer via
 * `window.AstroPayBridge.shareFile()`. Never exposed to host app partners.
 */
internal data class AstroShareFileRequest(
    val url: String,
    val fileName: String,
    val mimeType: String,
    val mode: AstroShareFileMode = AstroShareFileMode.SHARE,
    val texts: AstroFilePreviewTexts = AstroFilePreviewTexts(),
    /** Colors of the preview's share button as resolved by the web (`#RRGGBB`); blank when absent. */
    val buttonBackground: String = "",
    val buttonText: String = "",
)

/**
 * Internal outcome of a `shareFile` request. In `share` mode Android's chooser does not report
 * whether the user picked a target, so [Shared] means the chooser was presented and [Cancelled] is
 * never emitted. In `preview` mode [Shared] means the chooser was opened at least once from the
 * preview and [Cancelled] means the preview was closed without sharing.
 */
internal sealed class AstroShareFileResult {
    object Shared : AstroShareFileResult()

    object Cancelled : AstroShareFileResult()

    data class Error(val code: AstroShareFileError) : AstroShareFileResult()
}

/** Internal `shareFile` error codes. The string [value] is the wire format sent to the web layer. */
internal enum class AstroShareFileError(val value: String) {
    /** The URL is missing, not absolute or not HTTPS. */
    INVALID_REQUEST("INVALID_REQUEST"),

    /** The file could not be downloaded (network error or non-2xx response). */
    DOWNLOAD_FAILED("DOWNLOAD_FAILED"),

    /** Any other failure, e.g. no activity able to handle the share intent or an unrenderable PDF. */
    UNKNOWN("UNKNOWN"),
}

/** Encodes a result as the JSON payload expected by the web `shareFileResultCallback`. */
internal fun AstroShareFileResult.encodeForBridge(): String = when (this) {
    is AstroShareFileResult.Shared ->
        org.json.JSONObject().put("status", "SHARED").toString()
    is AstroShareFileResult.Cancelled ->
        org.json.JSONObject().put("status", "CANCELLED").toString()
    is AstroShareFileResult.Error ->
        org.json.JSONObject().put("status", "ERROR").put("code", code.value).toString()
}

/**
 * Colors of the preview screen, resolved from the partner's `style` / `styleOverrides` with a
 * theme-aware fallback when the partner configures none.
 */
internal data class AstroFilePreviewStyle(
    @ColorInt val background: Int,
    @ColorInt val content: Int,
    @ColorInt val primary: Int,
    @ColorInt val buttonBackground: Int = primary,
    @ColorInt val buttonText: Int = readableTextColor(buttonBackground),
) {
    /**
     * The backdrop behind the document pages: the background nudged towards the content color, so a
     * white page reads as a sheet of paper in light mode and stays distinct in dark mode.
     */
    @get:ColorInt
    val canvas: Int
        get() = blend(background, content, CANVAS_BLEND)

    /** Hairline between the header, the document and the bottom bar. */
    @get:ColorInt
    val separator: Int
        get() = (content and 0x00FFFFFF) or (SEPARATOR_ALPHA shl 24)

    /**
     * Returns a copy whose share button takes the colors the web resolved for its own primary
     * button, so both look the same. A missing or malformed color keeps the fallback: the partner's
     * primary color, and a text color that reads on the background.
     */
    fun withButtonColors(background: String, text: String): AstroFilePreviewStyle {
        val resolvedBackground = parseHexColor(background) ?: primary
        return copy(
            buttonBackground = resolvedBackground,
            buttonText = parseHexColor(text) ?: readableTextColor(resolvedBackground),
        )
    }

    companion object {
        private const val READABLE_DARK_TEXT = 0xFF1C1C1E.toInt()
        private const val READABLE_LIGHT_TEXT = 0xFFFFFFFF.toInt()
        private const val LIGHT_COLOR_LUMINANCE = 0.6
        private const val CANVAS_BLEND = 0.06
        private const val SEPARATOR_ALPHA = 0x1F

        /** Mixes [amount] of [other] into [base]; the result is opaque. */
        fun blend(@ColorInt base: Int, @ColorInt other: Int, amount: Double): Int {
            fun channel(shift: Int): Int {
                val from = (base shr shift) and 0xFF
                val to = (other shr shift) and 0xFF
                return (from + (to - from) * amount).toInt().coerceIn(0, 0xFF)
            }
            return (0xFF shl 24) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
        }
        private val HEX_COLOR_PATTERN = Regex("^#[0-9a-fA-F]{6}$")

        /** Parses an opaque `#RRGGBB` color; anything else is null. */
        fun parseHexColor(raw: String): Int? =
            raw.trim().takeIf { HEX_COLOR_PATTERN.matches(it) }
                ?.let { (0xFF000000L or it.substring(1).toLong(16)).toInt() }

        /** White on a dark color, near-black on a light one. */
        fun readableTextColor(@ColorInt color: Int): Int {
            val red = (color shr 16) and 0xFF
            val green = (color shr 8) and 0xFF
            val blue = color and 0xFF
            val luminance = (0.299 * red + 0.587 * green + 0.114 * blue) / 255.0
            return if (luminance > LIGHT_COLOR_LUMINANCE) READABLE_DARK_TEXT else READABLE_LIGHT_TEXT
        }

        private const val LIGHT_BACKGROUND = 0xFFFFFFFF.toInt()
        private const val LIGHT_CONTENT = 0xFF1C1C1E.toInt()
        private const val LIGHT_PRIMARY = 0xFF1C1C1E.toInt()
        private const val DARK_BACKGROUND = 0xFF121212.toInt()
        private const val DARK_CONTENT = 0xFFFFFFFF.toInt()
        private const val DARK_PRIMARY = 0xFF3A3A3C.toInt()

        fun from(configuration: AstroConfiguration, context: Context): AstroFilePreviewStyle {
            val isDark =
                when (configuration.theme) {
                    AstroTheme.DARK -> true
                    AstroTheme.LIGHT -> false
                    AstroTheme.SYSTEM ->
                        (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                            Configuration.UI_MODE_NIGHT_YES
                }
            val style = configuration.style
            val overrides = configuration.styleOverrides
            return AstroFilePreviewStyle(
                background = resolveNativeBackgroundColor(style, overrides)
                    ?: if (isDark) DARK_BACKGROUND else LIGHT_BACKGROUND,
                content = resolveNativeContentColor(style, overrides)
                    ?: if (isDark) DARK_CONTENT else LIGHT_CONTENT,
                primary = resolveNativePrimaryColor(style, overrides)
                    ?: if (isDark) DARK_PRIMARY else LIGHT_PRIMARY,
            )
        }
    }
}

/**
 * Dedicated [FileProvider] subclass so the SDK's provider never collides with the host app's own
 * `androidx.core.content.FileProvider` entry during manifest merging.
 */
internal class AstroConnectFileProvider : FileProvider()

/**
 * Downloads a remote file into the SDK's cache folder and hands it to the user, either through the
 * system share sheet or through the SDK's preview screen.
 */
internal object AstroFileSharer {
    /** Must match the `cache-path` declared in `res/xml/astro_connect_file_paths.xml`. */
    private const val SHARE_DIR = "astroconnect_share"
    private const val AUTHORITY_SUFFIX = ".astroconnect.fileprovider"
    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 30_000
    private const val DEFAULT_MIME_TYPE = "application/octet-stream"

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Downloads [request] off the main thread, then presents the preview (in `preview` mode, when an
     * activity can host it) or the chooser. [onResult] is always invoked exactly once, on the main
     * thread.
     *
     * @param activity Hosts the preview and opens the chooser in the host task; `null` falls back to
     *   the chooser from [context].
     */
    fun share(
        context: Context,
        activity: FragmentActivity?,
        request: AstroShareFileRequest,
        previewStyle: AstroFilePreviewStyle,
        onResult: (AstroShareFileResult) -> Unit,
    ) {
        val url = parseHttpsUrl(request.url)
        if (url == null) {
            onResult(AstroShareFileResult.Error(AstroShareFileError.INVALID_REQUEST))
            return
        }

        val appContext = context.applicationContext
        Thread {
            val file = try {
                download(appContext, url, sanitizeFileName(request.fileName, url))
            } catch (e: Exception) {
                AstroLogger.logDebug("shareFile: download failed — ${e.message}")
                mainHandler.post { onResult(AstroShareFileResult.Error(AstroShareFileError.DOWNLOAD_FAILED)) }
                return@Thread
            }

            mainHandler.post {
                val mimeType = request.mimeType.ifBlank { DEFAULT_MIME_TYPE }
                val style = previewStyle.withButtonColors(request.buttonBackground, request.buttonText)
                if (request.mode == AstroShareFileMode.PREVIEW && activity != null && showPreview(activity, file, mimeType, request, style, onResult)) {
                    return@post
                }
                val shared = startChooser(activity ?: context, file, mimeType)
                onResult(if (shared) AstroShareFileResult.Shared else AstroShareFileResult.Error(AstroShareFileError.UNKNOWN))
            }
        }.start()
    }

    /**
     * Opens the system chooser for [file]. Returns `false` when no activity can handle it.
     * Also used by the preview screen's share button.
     */
    fun startChooser(context: Context, file: File, mimeType: String): Boolean =
        try {
            context.startActivity(buildChooser(context, file, mimeType))
            true
        } catch (e: Exception) {
            AstroLogger.logDebug("shareFile: could not present chooser — ${e.message}")
            false
        }

    /** Returns `false` when the preview cannot be shown, so the caller falls back to the chooser. */
    private fun showPreview(
        activity: FragmentActivity,
        file: File,
        mimeType: String,
        request: AstroShareFileRequest,
        previewStyle: AstroFilePreviewStyle,
        onResult: (AstroShareFileResult) -> Unit,
    ): Boolean {
        val fragmentManager = activity.supportFragmentManager
        if (activity.isFinishing || fragmentManager.isStateSaved) return false
        return try {
            AstroFilePreviewFragment
                .newInstance(file, mimeType, request.texts, previewStyle, onResult)
                .show(fragmentManager, AstroFilePreviewFragment.TAG)
            true
        } catch (e: Exception) {
            AstroLogger.logDebug("shareFile: could not present preview — ${e.message}")
            false
        }
    }

    internal fun parseHttpsUrl(raw: String): URL? {
        val url = runCatching { URL(raw) }.getOrNull() ?: return null
        return if (url.protocol.equals("https", ignoreCase = true) && !url.host.isNullOrEmpty()) url else null
    }

    /** Keeps only the last path component so a crafted name cannot escape the share folder. */
    internal fun sanitizeFileName(name: String, url: URL): String {
        val candidate = name.ifBlank { url.path.substringAfterLast('/') }
        val lastComponent = File(candidate).name
        return if (lastComponent.isBlank() || lastComponent == "." || lastComponent == "..") "file" else lastComponent
    }

    /**
     * Downloads into a fresh share folder. The previous share's file is deleted here because the
     * chooser gives no signal for when the target app has finished reading it.
     */
    private fun download(context: Context, url: URL, fileName: String): File {
        val folder = File(context.cacheDir, SHARE_DIR)
        folder.deleteRecursively()
        if (!folder.mkdirs() && !folder.isDirectory) {
            throw IOException("Could not create share folder")
        }
        val target = File(folder, fileName)

        val connection = url.openConnection() as? HttpsURLConnection
            ?: throw IOException("Not an HTTPS connection")
        try {
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.instanceFollowRedirects = true
            val status = connection.responseCode
            if (status !in 200..299) {
                throw IOException("HTTP $status")
            }
            connection.inputStream.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
        } finally {
            connection.disconnect()
        }
        return target
    }

    private fun buildChooser(context: Context, file: File, mimeType: String): Intent {
        val appContext = context.applicationContext
        val contentUri = FileProvider.getUriForFile(appContext, appContext.packageName + AUTHORITY_SUFFIX, file)
        val sendIntent =
            Intent(Intent.ACTION_SEND).apply {
                type = mimeType.ifBlank { DEFAULT_MIME_TYPE }
                putExtra(Intent.EXTRA_STREAM, contentUri)
                // ClipData carries the read grant through the chooser to the picked target.
                clipData = ClipData.newRawUri(file.name, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        return Intent.createChooser(sendIntent, null).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (context !is Activity) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }
}
