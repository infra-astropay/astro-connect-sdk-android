package com.astropay.connect.views

import android.webkit.PermissionRequest
import com.astropay.connect.core.AstroLogger

/**
 * Keeps every WebView [PermissionRequest] that waits for the OS permission dialog.
 *
 * A page can ask again while the dialog is open. Each request must be granted or denied exactly
 * once, or its `getUserMedia` call never settles, so no request may replace another and the
 * dialog is launched only once while one is in flight. Main thread only.
 */
internal class PendingWebPermissionRequests {
    private val pending = mutableListOf<PermissionRequest>()
    private var isLaunchInFlight = false

    /**
     * Adds [request] and calls [launch] unless a dialog is already open.
     *
     * @param isDialogAlreadyOpen `true` when another flow has the same dialog open and its result
     *   will reach [answerAll].
     */
    fun add(
        request: PermissionRequest,
        isDialogAlreadyOpen: Boolean,
        launch: () -> Unit,
    ) {
        if (request !in pending) pending.add(request)
        if (isLaunchInFlight || isDialogAlreadyOpen) return
        isLaunchInFlight = true
        try {
            launch()
        } catch (error: RuntimeException) {
            // No dialog means no result: answer now instead of leaving the requests pending.
            AstroLogger.logDebug("WebView permission: could not open the OS dialog: ${error.message}")
            denyAll()
        }
    }

    /** Answers every pending request through [answer] once the OS result is known. */
    fun answerAll(answer: (PermissionRequest) -> Unit) {
        isLaunchInFlight = false
        val requests = pending.toList()
        pending.clear()
        requests.forEach { request ->
            try {
                answer(request)
            } catch (error: RuntimeException) {
                // One request that cannot be answered must not leave the others pending.
                AstroLogger.logDebug("WebView permission: could not answer a request: ${error.message}")
            }
        }
    }

    /** Denies every pending request, e.g. when the view is disposed. */
    fun denyAll() = answerAll { request -> request.deny() }

    /** Drops a request the WebView cancelled; it must not be answered any more. */
    fun remove(request: PermissionRequest) {
        pending.remove(request)
    }
}
